// NetComm1.h : main header file for the NETCOMM1 application
//

#if !defined(AFX_NETCOMM1_H__3F02F098_7712_4F7A_9F61_62C1C8A63713__INCLUDED_)
#define AFX_NETCOMM1_H__3F02F098_7712_4F7A_9F61_62C1C8A63713__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#define MAX_SEND_LENGTH  2048
#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CNetComm1App:
// See NetComm1.cpp for the implementation of this class
//

class CNetComm1App : public CWinApp
{
public:
	CNetComm1App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNetComm1App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CNetComm1App)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NETCOMM1_H__3F02F098_7712_4F7A_9F61_62C1C8A63713__INCLUDED_)
