// NetComm1View.cpp : implementation of the CNetComm1View class
//

#include "stdafx.h"
#include "NetComm1.h"

#include "NetComm1Doc.h"
#include "NetComm1View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNetComm1View

IMPLEMENT_DYNCREATE(CNetComm1View, CView)

BEGIN_MESSAGE_MAP(CNetComm1View, CView)
	//{{AFX_MSG_MAP(CNetComm1View)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNetComm1View construction/destruction

CNetComm1View::CNetComm1View()
{
	// TODO: add construction code here

}

CNetComm1View::~CNetComm1View()
{
}

BOOL CNetComm1View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CNetComm1View drawing

void CNetComm1View::OnDraw(CDC* pDC)
{
	CNetComm1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CNetComm1View printing

BOOL CNetComm1View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CNetComm1View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CNetComm1View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CNetComm1View diagnostics

#ifdef _DEBUG
void CNetComm1View::AssertValid() const
{
	CView::AssertValid();
}

void CNetComm1View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CNetComm1Doc* CNetComm1View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CNetComm1Doc)));
	return (CNetComm1Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CNetComm1View message handlers
