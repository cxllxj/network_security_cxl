// NetComm1Doc.cpp : implementation of the CNetComm1Doc class
//

#include "stdafx.h"
#include "NetComm1.h"

#include "NetComm1Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNetComm1Doc

IMPLEMENT_DYNCREATE(CNetComm1Doc, CDocument)

BEGIN_MESSAGE_MAP(CNetComm1Doc, CDocument)
	//{{AFX_MSG_MAP(CNetComm1Doc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNetComm1Doc construction/destruction

CNetComm1Doc::CNetComm1Doc()
{
	// TODO: add one-time construction code here

}

CNetComm1Doc::~CNetComm1Doc()
{
}

BOOL CNetComm1Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CNetComm1Doc serialization

void CNetComm1Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CNetComm1Doc diagnostics

#ifdef _DEBUG
void CNetComm1Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CNetComm1Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CNetComm1Doc commands
