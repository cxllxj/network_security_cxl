// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "NetComm1.h"

#include "MainFrm.h"
#include "WINSOCK2.h"
#include "SetupDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_SERVER_OPEN, OnServerOpen)
	ON_COMMAND(ID_CLIENT_OPEN, OnClientOpen)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here

	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnServerOpen() 
{
	// TODO: Add your command handler code here
	CString receivestring;
//	CString sendstring="ihgfedcba";
	char *receivebuffer;
	CString strDisplay;
	HWND hWndMain;
	WORD VersionReqd;
	struct sockaddr_in ReceiveAddress;
	int size;
	int errors;
	unsigned int WSA_SERVER;
	WSADATA myWSAData;
	SOCKET lpSocket1,lpSocket;

    CSetupDlg dlg2;
	if(IDOK==dlg2.DoModal())
	{
		m_inputIPsvr=dlg2.m_strIP;
		m_inputPortsvr=dlg2.m_port;
		m_inputLensvr=dlg2.m_len;
	}
	receivebuffer=(char *)malloc(m_inputLensvr+1);

    ReceiveAddress.sin_family=AF_INET;
    ReceiveAddress.sin_port=htons(m_inputPortsvr);
	ReceiveAddress.sin_addr.s_addr=INADDR_ANY;

   
    VersionReqd=MAKEWORD(2,0);

	if(WSAStartup(VersionReqd,&myWSAData)!=0)
	    MessageBox("WSA STARTUP error.",NULL,MB_OK);
        
	

    lpSocket1=socket(AF_INET,SOCK_STREAM,0);
	if(lpSocket1==INVALID_SOCKET)
		MessageBox("Create socket error.",NULL,MB_OK);


	errors=bind(lpSocket1,(struct sockaddr *)&ReceiveAddress,sizeof(ReceiveAddress));
	if(errors==SOCKET_ERROR)
	{
	    MessageBox("Bind socket error.",NULL,MB_OK);
		
	
	}
    

	if(listen(lpSocket1,5)!=0)
        MessageBox("Listen socket error.",NULL,MB_OK);
	   
	   int sec_begin;
	   CString time_begin;
	   time_t timep;
	   struct tm *p;
	   int sec_end;
	   CString time_used;
	   time_t timep_end;
	   struct tm *p_end;
//	   MessageBox(time_begin,NULL,MB_OK);

	while(1)
	{
	   size=sizeof(ReceiveAddress);
	   lpSocket=accept(lpSocket1,(struct sockaddr *)&ReceiveAddress,&size);
	   if(lpSocket<0)
          MessageBox("Accept send connect error.",NULL,MB_OK);

	   
       time(&timep);
	   p=localtime(&timep);
	   sec_begin=p->tm_hour*3600+p->tm_min*60+p->tm_sec;
	   time_begin.Format("%d",sec_begin);

       int i=recv(lpSocket,receivebuffer,m_inputLensvr+1,0);
	   receivestring=receivebuffer;

 //      send(lpSocket,sendstring,10,0);
	   if(i==m_inputLensvr+1)
	   {
		   if(i>21)
		   {
				strDisplay.Format("recv %d bytes succ!",i-1);
				MessageBox(strDisplay,NULL,MB_OK);
		   }
		   else
				MessageBox(receivestring,NULL,MB_OK);
	   }
	   else
			MessageBox("Recieve error!",NULL,MB_OK);
	   closesocket(lpSocket);
       break;
//	   if(WSAAsyncSelect(lpSocket,hWndMain,WSA_SERVER,FD_READ|FD_CLOSE|FD_CONNECT)!=0)
 //        MessageBox("Notify error.",NULL,MB_OK);

	}

	   
	   time(&timep_end);
	   p_end=localtime(&timep_end);
	   sec_end=p_end->tm_hour*3600+p_end->tm_min*60+p_end->tm_sec;
	   time_used.Format("TCP connection use time:  %d second",sec_end-sec_begin);
	   MessageBox(time_used,NULL,MB_OK);

   closesocket(lpSocket1);
   WSACleanup();
	
}

void CMainFrame::OnClientOpen() 
{
	// TODO: Add your command handler code here
//	CString sendstring="abcdefghi";
	CSetupDlg dlg1;
	if(IDOK==dlg1.DoModal())
	{
		m_inputIP=dlg1.m_strIP;
		m_inputPort=dlg1.m_port;
		m_inputLen=dlg1.m_len;
	}
		
	CString sendstring="";
	
	for(int i=0;i<m_inputLen;i++)
		sendstring+="a";

//	CString receivestring;
//	char receivebuffer[10];
	
	HWND hWndMain;
	WORD val1;
	struct sockaddr_in lpAddress;

	
	int connectResult;
	unsigned int WSA_CLIENT;
	WSADATA val2;
	SOCKET s;


    lpAddress.sin_family=AF_INET;
    lpAddress.sin_port=htons(m_inputPort);
	lpAddress.sin_addr.s_addr=inet_addr(m_inputIP);
	val1=MAKEWORD(2,0);

	if(WSAStartup(val1,&val2)!=0)
	    MessageBox("WSA STARTUP error.",NULL,MB_OK);

	s=socket(AF_INET,SOCK_STREAM,0);
	if(s==INVALID_SOCKET)
		MessageBox("Create socket error.",NULL,MB_OK);

	connectResult=connect(s,(const struct sockaddr FAR *)&lpAddress,sizeof(lpAddress));
    if(connectResult!=0)
        MessageBox("connect error.",NULL,MB_OK);
    else
        MessageBox("connect to server SUCCESS.",NULL,MB_OK);
	//   if(WSAAsyncSelect(s,hWndMain,WSA_CLIENT,FD_READ|FD_CLOSE|FD_CONNECT)!=0)
  //      MessageBox("WSAAsyncSelect error.",NULL,MB_OK);

	send(s,sendstring,m_inputLen+1,0);

//	recv(s,receivebuffer,10,0);
//	receivestring=receivebuffer;
//	MessageBox(receivestring,NULL,MB_OK);

	closesocket(s);
 
	WSACleanup();

 
   

}
