#include "/usr/src/linux-2.4/include/asm/unistd.h"
#include "macro.h"
#include "ini.h"
#include "com.h"
#include "packetproc.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#include <ctype.h>
#include <string.h>
#include <errno.h>

#include "../PolicySYNC.h"

_syscall3(int, rule, char* ,buf, int, buflen, char*, access);

extern CCom Com;

InPolicySYNC g_InPoliSync;



/**************************************************************************************
                               ���ܣ� ת���ֽ�
                               ���:  ds
                                      ss   
                                      
                               ���Σ� 0    �ɹ�
                                      -1   ʧ��
**************************************************************************************/

int ChangeByte(unsigned char * ds,const unsigned char * ss)
{
	int b = 0;
	int temp[2] = {0};
	int i,j,k;
	for(i = 0,j = 0; j<6 ; j++)
	{
		for(k = 0; k<2 ; k++,i++){
			if(isdigit(ss[i]))
				temp[k] = ss[i]-'0';
			else
				temp[k] = (toupper(ss[i])-'A')+10;
			
		}	
		b = temp[0]*16 + temp[1];
		ds[j] = b;
	}
	return 0;
}

/**************************************************************************************
                               ���ܣ� ת���ֽ�
                               ���:  ds
                                      ss   
                                      
                               ���Σ� 0    �ɹ�
                                      -1   ʧ��
**************************************************************************************/
int ChangeByte1(unsigned char *ds , const unsigned char * ss)
{
	int b = 0;
	int temp = 0;
	int i,j;
	j = 0;
	for(i = 0;i < 8 && j < 16; i++)
	{
		b = ss[i];
		temp = b/16;
		if(temp > 9)
			ds[j] = temp - 10 + 'a';
		else
		    ds[j] = temp + '0';
		j++;
		temp = b % 16;
		if(temp > 9)
			ds[j] = temp -10 + 'a';
		else 
			ds[j] = temp + '0';
		j++;
	}
	return 0;
}
/**************************************************************************************
                               ���ܣ� ��ʼ������
                               ���:  ds
                                      ss   
                                      
                               ���Σ� 0    �ɹ�
                                      -1   ʧ��
**************************************************************************************/		
int InitList(char *FileName)
{
	POLICY_INFO Policy;
	CIniFile IniFile;
	int Sum = 0;
	char Line[LINE_MAX_LEN] = {0};
	unsigned char MacSrc[LINE_MAX_LEN] = {0};
    unsigned char MacDst[LINE_MAX_LEN] = {0};
    char Cmd = 0;
    int Ret = 0;
    
	//��ʼ���ں˲�������
	if(Ret = rule(NULL,0,"c") < 0)return -1;

	//��ʼ������������������
	if( g_InPoliSync.MakeData((char *)&Policy,0,"c")<0 )return -2;
	if( g_InPoliSync.SendBuf()<0 )return -3;
	
	Sum = IniFile.GetSum(FileName);
	DEBUG_PUT2("InitList �� sum = %d\n",Sum);
    IniFile.Open(FileName);
    for(int i = 1; i <= Sum; i++)
    {
		memset(Line,0,LINE_MAX_LEN);
		IniFile.GetLine(i,Line);
		DEBUG_PUT2("%s",Line);
		sscanf(Line,"%s %s %d %d %d %d\n",MacSrc,MacDst,&Policy.IP_saddr,
										&Policy.IP_daddr,&Policy.D_Port,&Policy.BannedFlag);
		
		ChangeByte(Policy.M_saddr,MacSrc);
		ChangeByte(Policy.M_daddr,MacDst);
		
		for(int i=0;i<6;i++)
		{
			DEBUG_PUT2("%02x",Policy.M_saddr[i]);	
		}
		
		
		DEBUG_PUT("\n");
		for(int i=0;i<6;i++)
		{
			DEBUG_PUT2("%02x",Policy.M_daddr[i]);	
		}
	    DEBUG_PUT("\n");
	    DEBUG_PUT5("%d %d %d %d\n",Policy.IP_saddr,Policy.IP_daddr,Policy.D_Port,Policy.BannedFlag);
	    //д�ں�
	    Cmd = 'a';
    	if(Ret = rule((char *)&Policy,sizeof(POLICY_INFO),(char *)&Cmd) < 0)
    	{
    		DEBUG_PUT2("----------InitList �� error1 %d\n",Ret);
    		return -6;
    	}
    	else
    	{
    		DEBUG_PUT("----------InitList �� success2\n");
	    	//֪ͨ��������һ���²���
	    	Ret = g_InPoliSync.MakeData((char *)&Policy,sizeof(POLICY_INFO),(char *)&Cmd);
	    	if(Ret<0)
	    	{
	    		DEBUG_PUT2("----------InitList to OutNet �� error3 %d\n",Ret);
	    		return -7;
	    	}
	    	else 
	    	{
	    		Ret = g_InPoliSync.SendBuf();
	    		if(Ret<0)
	    		{
	    			DEBUG_PUT2("----------InitList to OutNet �� error4 %d\n",Ret);
	    			return -8;
	    		}
	    		else DEBUG_PUT2("----------InitList to OutNet �� success5 %d\n",Ret);
	    	}
	    	//
   		}
	    		
	 }
    IniFile.Close();

	return 0;
}	
/**************************************************************************************
                               ���ܣ� ������������
                               ���:  Buf
                                      BufLen   
                                      
                               ���Σ� 0    �ɹ�
                                      -1   ʧ��
                               ���ܣ� ���ݿͻ��������룬���²���
                                                        �����û���Ϣ
                                                        ���ϵͳ״̬
**************************************************************************************/
void Process(char *Buf, int BufLen)
{
	
	CIniFile IniFile;
    POLICY_INFO Policy;
    MAP_INFO MapFile;
        
    unsigned char MacSrc[LINE_MAX_LEN] = {0};
    unsigned char MacDst[LINE_MAX_LEN] = {0};
    
    USER_INFO   UserInfo;  
    HOST_INFO   LogSvr;
    
    int RetLen=0;
    int Id = 0; 
    char Flag = 0;
    char Line[LINE_MAX_LEN] = {0};
    char NewFile[LINE_MAX_LEN] = {0};
   	int Ret = 0;
   	int Sum = 0;
   	int LineLen = 0;
   	int i = 0;
   	int ret = 0;
   	FILE * fp = NULL;
   	int timeout = 10;
   	unsigned char disa[25] = {0};
    unsigned char name[21] = {0};
    unsigned char rank[2] = {0};
    unsigned char time[11] = {0};
    char fileName[17] = {0};
    char Cmd = 0;
   	switch(Buf[0])
   	{
   		case POLICY_FLAG:
			switch(Buf[1])
		    {
    			//����һ����Ϣ
    			case INSERT_FLAG:
    				//memcpy(&Policy,Buf+2,BufLen-2);
    				memcpy(MacSrc,Buf+2,12);
    				ChangeByte(Policy.M_saddr,MacSrc);
    				    				
    				memcpy(MacDst,Buf+14,12);
    				ChangeByte(Policy.M_daddr,MacDst);
    				
    				memcpy(&Policy.IP_saddr,Buf+26,4);
    				memcpy(&Policy.IP_daddr,Buf+30,4);
    				memcpy(&Policy.D_Port,Buf+34,4);
    				memcpy(&Policy.BannedFlag,Buf+38,4);
    				//������˳��ת��Ϊ�����ֽ�˳��
    				Policy.D_Port = htons(Policy.D_Port);
    				//д�����ļ�
    				DEBUG_PUT7("%s %s %d %d %d %d\n",MacSrc,MacDst,Policy.IP_saddr,
    													Policy.IP_daddr,Policy.D_Port,Policy.BannedFlag);
    				memset(Line,0,LINE_MAX_LEN);
    				sprintf(Line,"%s %s %d %d %d %d\n",MacSrc,MacDst,Policy.IP_saddr,
    													Policy.IP_daddr,Policy.D_Port,Policy.BannedFlag);
    				
    					//���������ں˲��Ա�
    					Cmd = 'a';
    					if(Ret = rule((char *)&Policy,sizeof(POLICY_INFO),(char *)&Cmd) < 0)
    					{
    						DEBUG_PUT2("----------packetproc  add rule to kernel�� error %d\n",Ret); 
    						Flag = FAIL_FLAG; 	
    					}
    					else
    					{
    						DEBUG_PUT("----------packetproc add rule to kernel �� success%d\n");
    						////���������ں˲��Ա�
	    					Ret = g_InPoliSync.MakeData((char *)&Policy,sizeof(POLICY_INFO),(char *)&Cmd);
	    					if(Ret<0)
					    	{
					    		DEBUG_PUT2("----------packetproc add rule to OutNet �� fail #%d\n",Ret);
					    		Flag = FAIL_FLAG;
					    	} 
					    	else
	    					{
	    						Ret = g_InPoliSync.SendBuf();
	    						if(Ret<0)
	    						{
	    							DEBUG_PUT2("----------packetproc add rule to OutNet �� fail #%d\n",Ret);
	    							Flag = FAIL_FLAG;
	    						}
	    						else
	    						{
	    							DEBUG_PUT("----------packetproc add rule to OutNet �� success\n");
	    							//д�����ļ�
	    							if((Ret = IniFile.WriteFile(POLICY_TABLE_NAME,Line,0))<0)
	    							{
    									DEBUG_PUT("packetproc : write policy_table error\n");
    									Flag = FAIL_FLAG;
    								}
    								else
    								{
    									DEBUG_PUT("packetproc : write policy_table success\n");
    									Flag = SUCCESS_FLAG;
    								}
	    						}
					    	}
    					}
    			   				
    				break;
    			//ɾ��һ����Ϣ�����к���Ϊɾ����ʶ
    			case DELETE_FLAG:
    				if(BufLen!= 6)
    				{
    					DEBUG_PUT("ɾ����Ϣ���ȴ���\n");
    					Flag = FAIL_FLAG;
    					break;
    				}
    				memcpy(&Id, Buf+2,BufLen-2);
    				
					DEBUG_PUT2("packetproc : THE ID is %d\n",Id);    				

    					//ɾ�������ں˲��Ա�
    					Cmd = 'd';
    					if(Ret = rule((char *)&Id,sizeof(int),(char *)&Cmd) < 0)
    					{
    						DEBUG_PUT2("----------packetproc  del rule to kernel�� error %d\n",Ret); 
    						Flag = FAIL_FLAG;
    					}
    					else
    					{
    						DEBUG_PUT("----------packetproc del rule to kernel �� success%d\n");
    						//ɾ���������Ա�
	    					Ret = g_InPoliSync.MakeData((char *)&Id,sizeof(int),(char *)&Cmd);
	    					if(Ret<0)
	    					{
	    						DEBUG_PUT2("----------packetproc del rule to OutNet �� fail #%d\n",Ret);
					    		Flag = FAIL_FLAG;
					    	}
					    	else
					    	{
	    						Ret = g_InPoliSync.SendBuf();
	    						if(Ret<0)
	    						{
	    							DEBUG_PUT2("----------packetproc del rule to OutNet �� fail #%d\n",Ret);
	    							Flag = FAIL_FLAG;
	    						}
	    						else
	    						{
	    							DEBUG_PUT("----------packetproc del rule to OutNet �� success\n");
	    							Flag = SUCCESS_FLAG;
	    							//�Ĳ����ļ�
	    							if((Ret = IniFile.DeleteLine(POLICY_TABLE_NAME,Id)) < 0)
    								{
    									DEBUG_PUT("packetproc : delete policy_table error\n");
    									Flag = FAIL_FLAG;
    								}
    								else
    								{
    									Flag = SUCCESS_FLAG;
    									DEBUG_PUT("packetproc : delete policy_table success\n");
    								}
	    						}
					    	}
    					}	
    				break;
    				
    			//��ѯ��Ϣ
    			case QUERY_FLAG:
    				//���ж������ļ�
    				Sum = IniFile.GetSum(POLICY_TABLE_NAME);
    				if(Sum == 0){
    					DEBUG_PUT("packetproc : the file is null\n");
    					Flag = END_FLAG;
    					break;
    				}
    				IniFile.Open(POLICY_TABLE_NAME);
    				for(i = 1; i <= Sum; i++)
    				{
    					memset(Line,0,LINE_MAX_LEN);
    					memset(MacSrc,0,LINE_MAX_LEN);
    					memset(MacDst,0,LINE_MAX_LEN);
    					IniFile.GetLine(i,Line);
    					sscanf(Line,"%s %s %d %d %d %d\n",MacSrc,MacDst,&Policy.IP_saddr,
    													&Policy.IP_daddr,&Policy.D_Port,&Policy.BannedFlag);
    					
    					Policy.D_Port = ntohs(Policy.D_Port);
    					DEBUG_PUT2("%s\n",Line);
    					memset(Line,0,LINE_MAX_LEN);
    					memcpy(Line,MacSrc,12);
    					memcpy(Line+12,MacDst,12);
    					memcpy(Line+24,&Policy.IP_saddr,4);
    					memcpy(Line+28,&Policy.IP_daddr,4);
    					memcpy(Line+32,&Policy.D_Port,4);
    					memcpy(Line+36,&Policy.BannedFlag,4);
    					//�������ֽ�˳��ת��Ϊ����˳��
    					
 //   					DEBUG_PUT2("port is %d\n",Policy.D_Port);
    					LineLen=40;
    					
    					Com.Write(Line,LineLen);
    					memset(Line,0,LINE_MAX_LEN);
    					ret = Com.Readv(Line,1,&timeout); //���տͻ��˵�s
    					if (ret != 1)
    					{
    						DEBUG_PUT("packetproc : ���ڳ�ʱ\n");
    						Flag = FAIL_FLAG;
    						break;
    					}
    					if(i == Sum)
    						Flag = END_FLAG;   
    					
    					DEBUG_PUT2("packetproc : recv reply ��%c\n",Line[0]);
    				}
    				IniFile.Close();
    	//			Flag = END_FLAG;
    		   		break;	
    	   	}
    	   	
    	     		
    		//֪ͨ�ͻ��˳ɹ�����ʶ
    		Com.Write((char *)&Flag, 1);
			break;
    	
	    case USER_FLAG:
    		switch(Buf[1])
		    {
    			//����һ����Ϣ
    			case INSERT_FLAG:
    			    memset(&UserInfo,0,sizeof(UserInfo));
    				memcpy(UserInfo.Disa,Buf+2,8);
    				memset(Line,0,LINE_MAX_LEN);
    				
    				memset(disa,0,25);
					ChangeByte1(disa,(unsigned char *)UserInfo.Disa);
    				
    				DEBUG_PUT2("%s\n",disa);
    				if((ret = access((char*)disa,F_OK))== 0){
    					DEBUG_PUT("user has existst\n");
    					Flag = EXIST_FLAG;
    					break;
    				}
    				int nameLen; 
    				int temp ;
    				nameLen = (int)Buf[10];
    				if(nameLen==0||nameLen>20){
    					DEBUG_PUT("nameLen is error\n");
    					Flag = FAIL_FLAG;
    					break;
    				}
    				DEBUG_PUT2("nameLen is %d\n",nameLen);
    				memcpy(name, Buf+11,nameLen);
    				temp = 11 + nameLen;
    				DEBUG_PUT2("%s\n",name);
    				memcpy(rank, Buf+temp,1);
    				DEBUG_PUT2("%s\n",rank);
    				temp += 1;
    				memcpy(time , Buf+temp,10);
    				DEBUG_PUT2("%s\n",time);
    				sprintf(Line, "%s %s %s %s\n",disa,name,rank,time);
    				if((Ret = IniFile.WriteFile(USER_TABLE_NAME,Line,1))<0)
    				{
    					DEBUG_PUT("write user_table error\n");
    					Flag = FAIL_FLAG;	
    				}
    				else
    				{
    					DEBUG_PUT("write user_table sucess\n");
    					Flag = SUCCESS_FLAG;		
    				}
 //   				exit(-1);
					break;
				//����֤����Ϣ
				case CERT_FLAG:
					memset(Line,0,LINE_MAX_LEN);
					if(strncmp(UserInfo.Disa,Buf+2,8))
					{
						DEBUG_PUT("Disaid has changed\n");
    					Flag = FAIL_FLAG;
						break;
					}
					
					
					//memcpy(fileName,UserInfo.Disa,8);
					memset(fileName,0,17);
					ChangeByte1((unsigned char*)fileName,(unsigned char *)UserInfo.Disa);
					DEBUG_PUT2("fileName is %s \n",fileName);
					if(BufLen < 1000)
					{
						DEBUG_PUT("cert length error\n");
						Flag = FAIL_FLAG;
						break;
					}
					if((ret = access(fileName,F_OK))< 0)
				//    if(1)
					{
						fp = fopen(fileName,"w+");
						if(!fp){
							DEBUG_PUT("create file fail\n");
							Flag = FAIL_FLAG;
							break;
						}
						DEBUG_PUT2("begin write the cert, certlen is %d\n",BufLen-10);
						for(int i = 0; i<10; i++)
							DEBUG_PUT2("%d|",*(Buf+10+i));
						DEBUG_PUT("\n");
						if((ret = fwrite(Buf+10,BufLen-10,1,fp))!=1)
						//if((ret = fwrite(Buf+10,10,1,fp))!=1)
						{
							DEBUG_PUT("write file fail\n");
							Flag = FAIL_FLAG;
							fclose(fp);
							break;
						}else {
							DEBUG_PUT("write file success\n");
							fclose(fp);
							Flag = SUCCESS_FLAG;
						}
					}else{
						DEBUG_PUT("the cert has existed\n");
						Flag = EXIST_FLAG;
						break;
					}
					break;
    			//ɾ��һ����Ϣ����Disaid��Ϊɾ����ʶ
    			case DELETE_FLAG:
    				char disaId[22];
    				memset(disaId,0,22);
    				if(BufLen!= 18)
    				{
    					DEBUG_PUT("ɾ����Ϣ���ȴ���\n");
    					Flag = FAIL_FLAG;
    					break;
    				}
    				
    				memcpy(disaId, Buf+2,BufLen-2);
    				//memset(disa,0,25);
					//ChangeByte1(disa,(unsigned char *)disaId);
					DEBUG_PUT2("THE ID is %s\n",disaId);    				
					if((Ret = IniFile.DeleteLine((char*)disaId,1,USER_TABLE_NAME)) < 0)
    				{
    					DEBUG_PUT("delete user id error\n");
    					Flag = FAIL_FLAG;
    					break;	
    				}
    				else
    				{
    					
    					DEBUG_PUT("delete user id success\n");
    					memset(fileName,0,17);
						//ChangeByte1((unsigned char*)fileName,(unsigned char *)disaId);
						memcpy(fileName,disaId,16);
    					if((ret = access(fileName,F_OK))< 0)
    					{
    						DEBUG_PUT("cert not exitst\n");
    						Flag = FAIL_FLAG;
    						break;
    					}else{
    						remove(fileName);
    					    Flag = SUCCESS_FLAG;
    					}
    							
    				}
    				break;
    			//��ѯ��Ϣ
    			case QUERY_FLAG:
    				//���ж��û��ļ�
    L:				Sum = IniFile.GetSum(USER_TABLE_NAME);
    				
    				
    				if(Sum == 0){
    					DEBUG_PUT("the file is null\n");
    					Flag = END_FLAG;
    					break;
    				}
    				IniFile.Open(USER_TABLE_NAME);
    				for(i = 1; i <= Sum; i++)
    				{
    						
    					memset(Line,0,LINE_MAX_LEN);
    					IniFile.GetLine(i,Line);
    					memset(disa,0,25);
    					memset(name,0,21);
    					memset(rank,0,2);
    					memset(time,0,11);
    					sscanf(Line,"%s %s %s %s\n",disa,name,
    												rank,time);
    				
    					DEBUG_PUT2("name is %s\n" , name);
    					
    					if(access((char*)disa,F_OK)< 0){
    						
    						IniFile.Close();
    						if(IniFile.DeleteLine((char*)disa,1,USER_TABLE_NAME) < 0)
    						{
    							DEBUG_PUT2("delete user id %s error\n",disa);
    						}
    						if(i == Sum){
    							//DEBUG_PUT("the file is null\n");
    							Flag = END_FLAG;
    							IniFile.Open(USER_TABLE_NAME);
    							break;
    						}
    						
    						goto L;
    					}
    					
    					int temp;
    					int nameLen;
    					unsigned char chLen;
    					char temp1[2] ;
    					nameLen = strlen((char*)name);
    					chLen = nameLen;
    					DEBUG_PUT2("chLen is %d\n",chLen);
    					DEBUG_PUT2("%s",Line);
    					memset(Line,0,LINE_MAX_LEN);
    					memcpy(Line,disa,16);
    					Line[16] = chLen;
    					memcpy(Line+17,name,nameLen);
    					temp = 17 + nameLen;
    					memcpy(Line+temp,rank,1);
    					temp += 1;
    					memcpy(Line+temp,time,10);
    					temp += 10;
    					LineLen=temp;
    					chLen = temp;
    					DEBUG_PUT2("totol len is %d\n",temp);
    					Com.Write((char*)&chLen,1);
    					
    					ret = Com.Readv(temp1,1,&timeout); //���տͻ��˵�s
    					if(temp1[0]!= 's'){
    						DEBUG_PUT("�ͻ��˻�Ӧ����\n");
    						Flag = FAIL_FLAG;
    						break;
    					}	
    					if (ret != 1)
    					{
    						DEBUG_PUT("���ڳ�ʱ\n");
    						Flag = FAIL_FLAG;
    						break;
    					}
    					
    					Com.Write(Line,LineLen);
    					memset(Line,0,LINE_MAX_LEN);
    					ret = Com.Readv(Line,1,&timeout); //���տͻ��˵�s
    					if (ret != 1)
    					{
    						DEBUG_PUT("���ڳ�ʱ\n");
    						Flag = FAIL_FLAG;
    						break;
    					}
    					if (Line[0]!= 's')
    					{
    						DEBUG_PUT("��Ӧ����\n");
    						Flag = FAIL_FLAG;
    						break;
    					}	
    					if(i == Sum)
    				    	Flag = END_FLAG; 
    					
    					DEBUG_PUT2("%c\n",Line[0]);
    				}
    				IniFile.Close();
    				
    		   		break;	
    	   	}
    	   	//֪ͨ�ͻ��˳ɹ���ʶ
    	   	Com.Write((char *)&Flag, 1);
    //	   	DEBUG_PUT2("Flag is %c\n",Flag);
    //	   	exit(-1);
			break;
    	case LOG_FLAG:
    		//���ļ��������ͻ���
    		switch(Buf[1])
   			{
   				case INSERT_FLAG://log_conf
   					//strcpy(Direct,"/conf");
					/*RetLen =Com.Write("s",1);//���ͻ��˷���s
   					memset(Buf,0,DATA_MAX_LEN);
	    		    			    		
					RetLen = Com.Readv(Buf,data_len,&timeout);
					DEBUG_PUT2("DATA_LEN=%d\n",data_len);
					DEBUG_PUT2("RetLen=%d\n",RetLen);
					if(RetLen!=data_len)
					{
						DEBUG_PUT("���ڳ�ʱ\n");
						Com.Write("F",1);
						break;
					}*/
					//sprintf(NewFile,"%s%s%s%s",WORK_DIR,Direct,"/",LOGSVR_FILE);
					strcpy(NewFile,LOGSVR_FILE);
					/*if((ret = access(NewFile,F_OK))< 0)
			
					{*/
						fp = fopen(NewFile,"w+");
						if(!fp){
							DEBUG_PUT("create file fail\n");
							Flag = FAIL_FLAG;
							break;
						}
						memset(Line,0,LINE_MAX_LEN);
					memcpy(MacSrc,Buf+2,12);
					ChangeByte(LogSvr.Host_mac,MacSrc);
					memcpy(&LogSvr.Host_ip,Buf+14,4);
					
					sprintf(Line,"%s %d\n",MacSrc,LogSvr.Host_ip);
					if (fputs(Line,fp)<0)
    				{
    					DEBUG_PUT("write log_conf error\n");
    					Flag = FAIL_FLAG;	
    				}
    				else
    				{
    					DEBUG_PUT("write log_conf sucess\n");
    					Flag = SUCCESS_FLAG;		
    				}
    				fclose(fp);
					break;
				case QUERY_FLAG:
					//strcpy(Direct,"/conf");
					//sprintf(NewFile,"%s%s%s%s",WORK_DIR,Direct,"/",LOGSVR_FILE);
					strcpy(NewFile,LOGSVR_FILE);
					IniFile.Open(NewFile);
					memset(Line,0,LINE_MAX_LEN);
    				IniFile.GetLine(1,Line);
    				memset(MacSrc,0,LINE_MAX_LEN);
    				sscanf(Line,"%s %d\n",MacSrc,&LogSvr.Host_ip);
    				
    				memset(Buf,0,LINE_MAX_LEN);		
    				memcpy(Buf,MacSrc,12);
    				
    				memcpy(Buf+12,&LogSvr.Host_ip,4);
    				Com.Write(Buf,16);
    				IniFile.Close();
    				break;
				default:
					break;
				}//end switch(Buf[1]) of log
			Com.Write((char *)&Flag, 1);	
   			
    		break;
    	case MONITOR_FLAG:
    		//����ͳ����Ϣ
    		break;	
    	//writen by zj
    	case CHEAT_FLAG:
    		switch(Buf[1])
    		{
    			case INSERT_FLAG:
    				memcpy(MacSrc,Buf+2,12);
    				ChangeByte(MapFile.Original_mac,MacSrc);
    				    				
    				memcpy(MacDst,Buf+14,12);
    				ChangeByte(MapFile.Map_mac,MacDst);
    				
    				memcpy(&MapFile.Original_ip,Buf+26,4);
    				memcpy(&MapFile.Map_ip,Buf+30,4);
    				
    				
    				//дӳ���ļ�
    				printf("%s %s %d %d\n",MacSrc,MacDst,MapFile.Original_ip,MapFile.Map_ip);
    													
    				memset(Line,0,LINE_MAX_LEN);
    				sprintf(Line,"%s %s %d %d\n",MacSrc,MacDst,MapFile.Original_ip,MapFile.Map_ip);
    				/*
    					//���������ں˲��Ա�
    					Cmd = 'a';
    					if(Ret = rule((char *)&Policy,sizeof(POLICY_INFO),(char *)&Cmd) < 0)
    					{
    						DEBUG_PUT2("----------packetproc  add rule to kernel�� error %d\n",Ret); 
    						Flag = FAIL_FLAG; 	
    					}
    					else
    					{
    						DEBUG_PUT("----------packetproc add rule to kernel �� success%d\n");
    						////���������ں˲��Ա�
	    					Ret = g_InPoliSync.MakeData((char *)&Policy,sizeof(POLICY_INFO),(char *)&Cmd);
	    					if(Ret<0)
					    	{
					    		DEBUG_PUT2("----------packetproc add rule to OutNet �� fail #%d\n",Ret);
					    		Flag = FAIL_FLAG;
					    	} 
					    	else
	    					{
	    						Ret = g_InPoliSync.SendBuf();
	    						if(Ret<0)
	    						{
	    							DEBUG_PUT2("----------packetproc add rule to OutNet �� fail #%d\n",Ret);
	    							Flag = FAIL_FLAG;
	    						}
	    						else
	    						{
	    							DEBUG_PUT("----------packetproc add rule to OutNet �� success\n");*/
	    							//д�����ļ�
	    							if((Ret = IniFile.WriteFile(MAP_TABLE_NAME,Line,2))<0)
	    							{
    									DEBUG_PUT("packetproc : write map_table error\n");
    									Flag = FAIL_FLAG;
    								}
    								else
    								{
    									DEBUG_PUT("packetproc : write map_table success\n");
    									Flag = SUCCESS_FLAG;
    								}
	    						/*}
					    	}
    					}*/
    			   				
    				break;
    			//ɾ��һ����Ϣ�����к���Ϊɾ����ʶ
    			case DELETE_FLAG:
    				if(BufLen!= 6)
    				{
    					DEBUG_PUT("ɾ����Ϣ���ȴ���\n");
    					Flag = FAIL_FLAG;
    					break;
    				}
    				memcpy(&Id, Buf+2,BufLen-2);
    				
					DEBUG_PUT2("packetproc : THE ID is %d\n",Id);    				
					/*
    					//ɾ�������ں˲��Ա�
    					Cmd = 'd';
    					if(Ret = rule((char *)&Id,sizeof(int),(char *)&Cmd) < 0)
    					{
    						DEBUG_PUT2("----------packetproc  del rule to kernel�� error %d\n",Ret); 
    						Flag = FAIL_FLAG;
    					}
    					else
    					{
    						DEBUG_PUT("----------packetproc del rule to kernel �� success%d\n");
    						//ɾ���������Ա�
	    					Ret = g_InPoliSync.MakeData((char *)&Id,sizeof(int),(char *)&Cmd);
	    					if(Ret<0)
	    					{
	    						DEBUG_PUT2("----------packetproc del rule to OutNet �� fail #%d\n",Ret);
					    		Flag = FAIL_FLAG;
					    	}
					    	else
					    	{
	    						Ret = g_InPoliSync.SendBuf();
	    						if(Ret<0)
	    						{
	    							DEBUG_PUT2("----------packetproc del rule to OutNet �� fail #%d\n",Ret);
	    							Flag = FAIL_FLAG;
	    						}
	    						else
	    						{
	    							DEBUG_PUT("----------packetproc del rule to OutNet �� success\n");
	    							Flag = SUCCESS_FLAG;*/
	    							//�Ĳ����ļ�
	    							if((Ret = IniFile.DeleteLine(MAP_TABLE_NAME,Id)) < 0)
    								{
    									DEBUG_PUT("packetproc : delete policy_table error\n");
    									Flag = FAIL_FLAG;
    								}
    								else
    								{
    									Flag = SUCCESS_FLAG;
    									DEBUG_PUT("packetproc : delete policy_table success\n");
    								}
	    						/*}
					    	}
    					}*/	
    				break;
    				
    			//��ѯ��Ϣ
    			case QUERY_FLAG:
    				//���ж������ļ�
    				Sum = IniFile.GetSum(MAP_TABLE_NAME);
    				if(Sum == 0){
    					DEBUG_PUT("packetproc : the file is null\n");
    					Flag = END_FLAG;
    					break;
    				}
    				IniFile.Open(MAP_TABLE_NAME);
    				for(i = 1; i <= Sum; i++)
    				{
    					memset(Line,0,LINE_MAX_LEN);
    					memset(MacSrc,0,LINE_MAX_LEN);
    					memset(MacDst,0,LINE_MAX_LEN);
    					IniFile.GetLine(i,Line);
    					sscanf(Line,"%s %s %d %d\n",MacSrc,MacDst,&MapFile.Original_ip,&MapFile.Map_ip);
    					
    					
    					DEBUG_PUT2("%s\n",Line);
    					memset(Line,0,LINE_MAX_LEN);
    					memcpy(Line,MacSrc,12);
    					memcpy(Line+12,MacDst,12);
    					memcpy(Line+24,&MapFile.Original_ip,4);
    					memcpy(Line+28,&MapFile.Map_ip,4);
    					
    					//�������ֽ�˳��ת��Ϊ����˳��
    					
 //   					DEBUG_PUT2("port is %d\n",Policy.D_Port);
    					LineLen=32;
    					
    					Com.Write(Line,LineLen);
    					memset(Line,0,LINE_MAX_LEN);
    					ret = Com.Readv(Line,1,&timeout); //���տͻ��˵�s
    					if (ret != 1)
    					{
    						DEBUG_PUT("packetproc : ���ڳ�ʱ\n");
    						Flag = FAIL_FLAG;
    						break;
    					}
    					if(i == Sum)
    						Flag = END_FLAG;   
    					
    					DEBUG_PUT2("packetproc : recv reply ��%c\n",Line[0]);
    				}
    				IniFile.Close();
    	//			Flag = END_FLAG;
    		   		break;	
    	   	}
    	   	
    	     		
    		//֪ͨ�ͻ��˳ɹ�����ʶ
    		Com.Write((char *)&Flag, 1);
			break;
		//writen by zj ended
    	default:
    		break;
    }
	return;
}

/**************************************************************************************
                               ���ܣ� ������������
                               ���:  Buf
                               �Ž��޸�     
                                      
                               ���Σ� 0    �ɹ�
                                      -1   ʧ��
                               ���ܣ� ���ݿͻ��������룬���²���
                                                        �����û���Ϣ
                                                        ���ϵͳ״̬
**************************************************************************************/
void zjProcess(char *Buf)
{
	/*CIniFile IniFile;
    POLICYINFO PolicyFile;
    USER_INFO   UserInfo,ManagerInfo;
    char fileName[17] = {"manager.ini"};
    switch(Buf[0])
   	{
   		case POLICY_FLAG:
   			DEBUG_PUT("HELLO");
   			break;
   		case LOGIN_FLAG:
   			if((ret = access(fileName,F_OK))< 0)
   				Flag=END_FLAG;
   			Com.write((char *)&Flag, 1);
   			break;
   	}
   	return;*/
}	
 
