/////////////////////////////////////////////////////////////////////////////
// Name:        iobase.cpp
// Purpose:
// Author:      Joachim Buermann
// Id:          $Id: iobase.cpp,v 1.2 2001/05/07 20:26:56 jo Exp $
// Copyright:   (c) 2001 Joachim Buermann
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#include "iobase.h"

/*
  Readv() calls the member function Read() repeatedly, til all
  demand bytes were received. To avoid an endless loop, you
  can refer an integer, which was set unequal zero after a
  specific time. (See the timer class)
 */
int wxIOBase::Readv(char* buf,size_t len,int* timeout_flag)
{
    size_t toread = len;
    size_t n = 0;
    char *cp = buf;

    while(toread > 0) {
	if(timeout_flag && (*timeout_flag > 0)) {
	    return (len - toread);
	}
	if((n = Read(cp,toread)) < 0) {
	    // an error occurs
	    return (len - toread);
	}
	toread -= n;
	cp += n;
    }
    // ok, all bytes received
    return(len - toread);
};

/*
  Similar to Readv(). Writev() calls Write() repeatedly till
  all bytes are written.
 */
int wxIOBase::Writev(char* buf,size_t len,int* timeout_flag)
{
    size_t towrite = len;
    size_t n = 0;
    char *cp = buf;

    while(towrite > 0) {
	if(timeout_flag && (*timeout_flag > 0)) {
	    return (len - towrite);
	}
	if((n = Write(cp,towrite)) < 0) {
	    // an error occurs
	    return (len - towrite);
	}
	towrite -= n;
	cp += n;
    }
    return(len);
};

