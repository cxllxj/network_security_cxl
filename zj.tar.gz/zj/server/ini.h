#ifndef  _INI_H
#define  _INI_H 


#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "macro.h"


class CIniFile
{       public:
	        CIniFile();
			~CIniFile();
			int QueryFile(const char* key,int key_pos,const char * fileName,char* values = NULL);
//			int ReadFile(char ** lines,int * lineCount);
			int DeleteLine(char *FileName,int lineCount);
			int DeleteLine(const char* key, int key_pos,char * fileName);
			int Open(const char *fileName);
			void Close(void);
			int WriteFile(const char * fileName, const char* line_buf, int flag);
			int GetSum(char *FileName); 
			int GetLine(int LineNo,char* Values);
		private:
			char m_buf[LINE_MAX_LEN];
			FILE *m_fp;
			char m_fileName[NAME_MAX_LEN];
			int m_lineCount;
			int m_LineSum;
			
};
#endif 
/*--------------------------------------------------------------------------------------------*/
