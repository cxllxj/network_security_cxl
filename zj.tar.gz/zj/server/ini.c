#include "ini.h"
#include "macro.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>

/*------------------------------------------------------------------------------*/
CIniFile::CIniFile()
{
	m_lineCount = 0;  
	m_LineSum = 0;
	m_fp = NULL;
	
	memset(m_buf,0,LINE_MAX_LEN);
	memset(m_fileName,0,NAME_MAX_LEN);
}
/*------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------*/
CIniFile::~CIniFile()
{
}
/*------------------------------------------------------------------------------*/
int CIniFile::Open(const char *fileName)
{
	m_fp = fopen(fileName, "r+");
	if(m_fp == NULL)
	{
		DEBUG_PUT2("the %s file can not open\n",fileName);
		return -1;	
	}
	memcpy(m_fileName,fileName,strlen(fileName));
	return 0;
	
}

/*------------------------------------------------------------------------------*/
void CIniFile::Close(void)
{
	
	
	if(m_fp != NULL)
	{
		fclose(m_fp);	
	}
	m_fp = NULL;
}
	

/*---------------------------------------------------------------------------------------*/
/**************************************************************************************
                               ���ܣ� ����ֵ
                               ���:  key       �ؼ���
                                      key_pos   �ؼ���λ��
                                      values    һ�м�¼
                               ���Σ� 0    �ɹ�
                                      -1   ʧ��
**************************************************************************************/
int CIniFile::QueryFile(const char* key,int key_pos,const char * fileName,char* values)
{
	char cmp[KEY_MAX_LEN] = {0};
	char* temp = NULL;
	char buf[LINE_MAX_LEN] = {0};
	
	int ret = 0, len = 0;
	int pos = 0;
	Open(fileName);
	len = strlen(key);
	if(len == 0){
		DEBUG_PUT("The key is null\n");
		return -1;
	}
	if(len > KEY_MAX_LEN)
	{
		DEBUG_PUT("The key is too long\n");
		Close();
		return -1;
	}
	DEBUG_PUT3("The key len is %d,the key is %s\n",len,key);
	memcpy(cmp,key,len);
    memset(m_buf,0,LINE_MAX_LEN);
    m_lineCount = 0;
	while(fgets(m_buf,LINE_MAX_LEN,m_fp))
	{
	    m_lineCount++;
		memcpy(buf,m_buf,strlen(m_buf));
		strtok(m_buf,"\n");
		temp = strtok(m_buf," ");
		for(pos = 1;pos < key_pos&&temp;pos++)
		{
			temp = strtok(NULL," ");
		}
		if(!temp){
			printf("pos is error\n");
			//rewind(m_fp);
			Close();
			return -1;
		}
			
		if(strncmp(temp,cmp,len)==0){
			if (values){
				memcpy(values,buf,strlen(buf));
			}
		//	rewind(m_fp);
		    Close();
			return 0;
		}
		
	}
//	rewind(m_fp);
	Close();
	return -1;
}

/*---------------------------------------------------------------------------------------*/
/**************************************************************************************
                               ���ܣ� ɾ��һ�м�¼
                               ���:  key       �ؼ���
                                      key_pos   �ؼ���λ��
                               ���Σ� 0    �ɹ�
                                      -1   ʧ��
**************************************************************************************/	
		
int CIniFile::DeleteLine(const char* key, int key_pos,char * fileName)
{
	int ret = -1  ;
	
	
	ret = QueryFile(key,key_pos,fileName);
	if(ret < 0)
	{
		DEBUG_PUT("key is not find in the file\n");
//		rewind(m_fp);
		return -1;
	}
	ret = DeleteLine(fileName,m_lineCount);
	if ( ret < 0){
		DEBUG_PUT("delete fail\n");
		return -1;
	}
	return 0;
}

/*---------------------------------------------------------------------------------------*/
/**************************************************************************************
                               ���ܣ� ɾ��һ�м�¼
                               ���:  lineCount       ����
                               ���Σ� 0    �ɹ�
                                      -1   ʧ��
**************************************************************************************/	
int CIniFile::DeleteLine(char *FileName, int lineCount)	
{
	FILE * fp = NULL;
	int i = 0;
	int ret = 0;
	int lines = 0;
	lines = GetSum(FileName);
	DEBUG_PUT2("lines = %d\n",lines);
	if(lineCount > lines)
	{
		DEBUG_PUT("ID error\n");
		return -1;
	}
	Open(FileName);
	if(access("temp.ini",F_OK)==0)
	{
		remove("temp.ini");
	}
	if((ret = rename(m_fileName,"temp.ini"))<0)
	{
		DEBUG_PUT("rename error\n");
		Close();
		return -1;
	}
	
	if((ret = access(m_fileName,F_OK))< 0)
	{
		fp = fopen(m_fileName,"w+");
		
		if(!fp){
			DEBUG_PUT("create file fail\n");
			return -1;
		}
		
		for ( i = 0; i < lineCount -1; i ++) {
			if(fgets(m_buf,LINE_MAX_LEN,m_fp)){
				if(fputs(m_buf,fp)== EOF){
					DEBUG_PUT("write file error\n");
					fclose(fp);
					remove(m_fileName);
					rename("temp.ini",m_fileName);
					Close();
					return -1;
				}
			}
		}
		fgets(m_buf,LINE_MAX_LEN,m_fp);
		while(fgets(m_buf,LINE_MAX_LEN,m_fp)){
			if(fputs(m_buf,fp)== EOF){
				DEBUG_PUT("write file error\n");
				fclose(fp);
				remove(m_fileName);
				rename("temp.ini",m_fileName);
				Close();
				return -1;
			}
		}
		if(ferror(m_fp)){
			DEBUG_PUT("read file error\n");
			return -1;
		}
		fclose(fp);
	}
	else{
		DEBUG_PUT("error\n");
		return -1;
	}
	//m_LineSum--;
	Close();
	remove("temp.ini");
	
	//Open(m_fileName);
	return 0;
}
		
/*---------------------------------------------------------------------------------------*/
/**************************************************************************************
                               ���ܣ� д��ֵ
                               ���:  fileName       �ļ���
                                      line_buf       һ�м�¼
                                      flag			 ��־(0:���Ա�;1:�û���;2:ӳ���)
                               ���Σ� 0    �ɹ�
                                      -1   ʧ��
**************************************************************************************/		
int CIniFile::WriteFile(const char * fileName, const char* line_buf, int flag)
{
	FILE * fp =NULL;
	char * temp = NULL;
	int ret = 0, item = 0, i = 0;
	char buf1[LINE_MAX_LEN] = {0}; 
	
	fp = fopen(fileName,"a+");
	
	memcpy(buf1,line_buf,strlen(line_buf));	
	
	if(!strtok(buf1,"\n")){
		DEBUG_PUT("line buf format error\n");
		return -1;
	}
	
	temp = strtok(buf1," ");
	i++;
	while((temp = strtok(NULL," ")))
	{
		i++;
	}
	
	if(flag == 0)
	{
		//printf("%d\n",i);
		if(i!= 6){
			DEBUG_PUT("line buf format error\n");
			return -1;
		}
		fputs(line_buf,fp);
			
	}
	else if (flag==1){
		if(i != 4){
			DEBUG_PUT("line buf format error\n");
			return -1;
		}
		fputs(line_buf,fp);
	}
	else{
		if (i!=4){
			DEBUG_PUT("line buf format error\n");
			return -1;
		}
		fputs(line_buf,fp);
	}
	//m_LineSum++;
	fclose(fp);
	
	return 0;
}

/**************************************************************************************
                               ���ܣ� д��ֵ
                               ���:  
                               ���Σ� ����
                                      
**************************************************************************************/	
int CIniFile::GetSum(char *FileName)
{
	
	Open(FileName);
	m_LineSum = 0;
	while(fgets(m_buf,LINE_MAX_LEN,m_fp))
	{
		if(strlen(m_buf)> POLICY_MIN_LEN)
			m_LineSum++;
	}
	Close();
	return m_LineSum;	
}

/**************************************************************************************
                               ���ܣ� ����ֵ
                               ���:  key       �ؼ���
                                      key_pos   �ؼ���λ��
                                      values    һ�м�¼
                               ���Σ� 0    �ɹ�
                                      -1   ʧ��
**************************************************************************************/
int CIniFile::GetLine(int LineNo,char* Values)
{
	int Flag = -1;
	m_lineCount = 0;
	while(fgets(m_buf,LINE_MAX_LEN,m_fp))
	{
	    m_lineCount++;
	    if(m_lineCount == LineNo)
	    {
			memcpy(Values,m_buf,strlen(m_buf));
			Flag = 0;
		}
	}	
	rewind(m_fp);
	m_lineCount = 0;
	return Flag;
}
