#ifndef  SWLG_COM_H__
#define  SWLG_COM_H__

    /*********************************************************************************

                            com.h for linux version 1.0

                            coded by wangxuan on 10/17/2002

    *********************************************************************************/

    
#include <stdio.h>


#include "getopt.h"
#include "serport.h"


    
class CCom 
{
	public:
		CCom();
		~CCom();
		int Readv(char* buf,int len,int* timeout_flag);
		int  Open(char *ComName);
		void Close(void);
		int  Read(char *Buf,int BufLen = 1024);
		int  Write(char *Buf, char BufLen);    
   	      	    	
    private:
    	wxSerialPort m_Com;
		wxSerialPort_DCS m_Dcs;
		
				
};

#endif


