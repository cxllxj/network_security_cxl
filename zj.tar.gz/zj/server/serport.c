/////////////////////////////////////////////////////////////////////////////
// Name:        linux/serport.cpp
// Purpose:
// Author:      Joachim Buermann
// Id:          $Id: serport.cpp,v 1.4 2001/05/07 20:29:00 jo Exp $
// Copyright:   (c) 2001 Joachim Buermann
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#include "serport.h"

#include <fcntl.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <termios.h>
#include <unistd.h>

wxSerialPort::wxSerialPort() :
    wxSerialPort_x()
{
};

wxSerialPort::~wxSerialPort()
{
    Close();
};

speed_t wxSerialPort::AdaptBaudrate(wxBaud baud)
{
    switch(baud) {
    case wxBAUD_150: return B150;
    case wxBAUD_300: return B300;
    case wxBAUD_600: return B600;
    case wxBAUD_1200: return B1200;
    case wxBAUD_2400: return B2400;
    case wxBAUD_4800: return B4800;
    case wxBAUD_9600: return B9600;
    case wxBAUD_38400: return B38400;
    case wxBAUD_57600: return B57600;
    case wxBAUD_115200: return B115200;
    default: return B19200;
    }
};

int wxSerialPort::CloseDevice()
{
    // recovery original settings
    tcsetattr(fd,TCSANOW,&save_t);
    // and close device
    return close(fd);
};

int wxSerialPort::ChangeLineState(wxSerialLineState flags)
{
    return ioctl(fd,TIOCMSET,&flags);
};

int wxSerialPort::ClrLineState(wxSerialLineState flags)
{
    return ioctl(fd,TIOCMBIC,&flags);
};

int wxSerialPort::GetLineState(wxSerialLineState* flags)
{
    return ioctl(fd,TIOCMGET,flags);
};

int wxSerialPort::GetSettingsAsString(char* str, size_t size)
{
    const char ac[5] = {'N','O','E','M','S'};
    return snprintf(str,size,"%i%c%i %i %s",
		    m_dcs.stopbits,
		    ac[m_dcs.parity],
		    m_dcs.wordlen,
		    m_dcs.baud,
		    m_devname);
};

int wxSerialPort::OpenDevice(const char* devname, void* dcs)
{
    // if dcs isn't NULL, type cast
    if(dcs) m_dcs = *(wxSerialPort_DCS*)dcs;
    // open serial comport device for reading and writing,
    // don't wait (O_NONBLOCK)
    fd = open(devname, O_RDWR | O_NOCTTY | O_NONBLOCK);
    if(fd >= 0) {
	tcgetattr(fd,&t);
	save_t = t;

	// save the device name
	strncpy(m_devname,(char*)devname,sizeof(m_devname));
	// we write an eos to avoid a buffer overflow
	m_devname[sizeof(m_devname)-1] = '\0';

	// fill the internal terios struct
	// default input/output speed is 19200 baud
	cfsetispeed(&t,AdaptBaudrate(m_dcs.baud));
	cfsetospeed(&t,AdaptBaudrate(m_dcs.baud));
	// parity settings
	if(m_dcs.parity == wxPARITY_NONE) 
	    t.c_cflag &= ~PARENB;
	else {
	    t.c_cflag |= PARENB;
	    if(m_dcs.parity == wxPARITY_ODD)
		t.c_cflag |= PARODD;
	    else
		t.c_cflag &= ~PARODD;
	}
	// stopbits
	if(m_dcs.stopbits == 2)
	    t.c_cflag |= CSTOPB;
	else
	    t.c_cflag &= ~CSTOPB;
	// wordlen
	t.c_cflag &= ~CSIZE;
	if(m_dcs.wordlen == 7)
	    t.c_cflag |= CS7;
	else
	    t.c_cflag |= CS8;
	// rts/cts
	if(m_dcs.rtscts == false)
	    t.c_cflag &= ~CRTSCTS;
	else
	    t.c_cflag |= CRTSCTS;

	t.c_lflag &= ~(ICANON | ECHO | ISIG | IEXTEN);
	t.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);
	t.c_iflag |= IGNPAR;
	t.c_oflag &= ~OPOST;
	// look out!
	// MIN = 1 means, in TIME (1/10 secs) defined timeout
	// will be started AFTER receiving the first byte
	// so we must set MIN = 0. (timeout starts immediately, abort
	// also without readed byte)
	t.c_cc[VMIN] = 0;
	// timeout in 1/10 secs
	// no timeout for non blocked transfer
	t.c_cc[VMIN] = 0;
	// write the settings
	tcsetattr(fd,TCSANOW,&t);
	// it's careless, but in the moment we don't test
	// the return of tcsetattr (normally there is no error)
    }
    return fd;
};

int wxSerialPort::Read(char* buf,size_t len)
{
    // on linux, only a C read() call is necessary
    return read(fd,buf,len);
};

int wxSerialPort::SendBreak(int duration)
{
    // the parameter is equal with linux
    return tcsendbreak(fd,duration);
};

int wxSerialPort::SetBaudRate(wxBaud baudrate)
{
    speed_t baud = AdaptBaudrate(baudrate);
    // setting the input baudrate
    if(cfsetispeed(&t,baud) < 0) {
	return -1;
    }
    // setting the output baudrate
    if(cfsetospeed(&t,baud) < 0) {
	return -1;
    }
    // take over
    m_dcs.baud = baudrate;
    return tcsetattr(fd,TCSANOW,&t);    
};

int wxSerialPort::SetLineState(wxSerialLineState flags)
{
    return ioctl(fd,TIOCMBIS,&flags);
};

int wxSerialPort::Write(char* buf,size_t len)
{
    // on linux only a C write() call is necessary
    return write(fd,buf,len);
};

