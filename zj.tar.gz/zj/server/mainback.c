/******************************************************************
** �ļ���: main.c
** Copyright (c) 2002 ά����˾����������
** ������:  ���@
** ����:   2002/10/18
** �޸���:
** �� ��:
** �� ��:   ��ȫ�������� ���ԣ�201������ 203������
**
** �� ��:  V1.0
***************************************************************/
#include "macro.h"
#include "shipside.h"
#include "global.h"
#include "capture.h"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

#include <sys/time.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/un.h>


int main(int argc ,char *argv[])
{
	int   ComFd = 0;
	int   CapFd = 0;
	int   MaxFd = 0;
	int   Ret = 0;
	int   RetLen = 0;
	fd_set FdSet;
    char devicename_rec[32]; 
	char Buf[LINE_MAX_LEN] = {0};
	FILE *fp;
	char TmpData[LINE_MAX_LEN] = {0};
	unsigned char data[data_packet_len]={0}; 
	int netid=0x03,i=0,count_rec=0,j=0; 
	CCapture cap;
	CCabinPacket CabinPacket;
	
	//��ץ���˿�
	
	if ((CapFd = cap.OpenNetworkType(netid,0))< 0) 
	{ 
		DEBUG_PUT2("Can not open net_dectype %d \n",netid); 
		return -1; 
	}
	else
	{
		DEBUG_PUT2("Can open net_dectype %d \n",CapFd); 
	} 
	
    
    
   	//�������ּ���
	ComFd = g_ShipSide.Open(COM1);
	if(ComFd < 0)
	{
		DEBUG_PUT2("ShipSide StartServer error %s\n",strerror(errno));
		exit(1);
	}
	else
	{
		DEBUG_PUT2("ShipSide Listen %d\n",ComFd);
	}
   			
	
	for(;;)
	{
   		FD_ZERO(&FdSet);
   		FD_SET(ComFd, &FdSet);
   		FD_SET(CapFd, &FdSet);
   		   		
		MaxFd = ((ComFd > CapFd) ? ComFd : CapFd) +1;	
		//MaxFd = ComFd + 1;
		DEBUG_PUT2("max listen %d\n",MaxFd);
		
		Ret = select(MaxFd + 1, &FdSet, NULL, NULL, NULL);
	    if(Ret <= 0)
	    {
	    	DEBUG_PUT2(" ----------------select : %s --------------\n",strerror(errno));
	    	break;
	    }
	    
	    //���ֵ����������ֶ�д���ݴ���
	    if(FD_ISSET(ComFd, &FdSet))
	    {
			
			Ret = g_ShipSide.ProcessCabin(INNER_PROXY_FLAG);
			if(Ret < 0)
	    	{
	    	 	DEBUG_PUT("Com process error ---\n");
	    	 	break; 
	    	}
	    }
	    
	    //ץ��
	    
	    if(FD_ISSET(CapFd, &FdSet))
	    {
			if ((Ret = cap.ReadFromNetwork(devicename_rec,(char*)data,data_packet_len))>0)
			{ 
				printf("Received Packet count = %d\n",++count_rec) ;
				printf("Packet size is %d\n",Ret);
				for (i=0; i<Ret; i++) 
				{
					printf("%2x|",data[i]); 
				}
				printf("\n");  
				CabinPacket.SetValue(data,Ret);
				//g_ShipQueue.push(CabinPacket);
				//CabinPacket.Free();
				
				fp = fopen("ether.txt","w+");
				CabinPacket.PrintInfo(fp);
				fclose(fp);
				CabinPacket.Free();
				
				fp = fopen("ether.txt","r+");
				fgets(TmpData,LINE_MAX_LEN,fp);
				sscanf(TmpData,"%d",&Ret);
				memset(data,0,data_packet_len);
				fread((char *)data,Ret,1,fp);
				fclose(fp);
				for (i=0; i<Ret; i++) 
				{
					printf("%2x|",data[i]); 
				}
				
				break;
			} 
	    }
	    
	}
	//������������Ӧ�������
}







