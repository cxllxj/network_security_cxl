/******************************************************************
** �ļ���: main.c
** Copyright (c) 2002 ά����˾����������
** ������:  ���@
** ����:   2002/10/18
** �޸���:
** �� ��:
** �� ��:   ��ȫ�������� ���ԣ�201������ 203������
**
** �� ��:  V1.0
***************************************************************/
#include "macro.h"
#include "com.h"
#include "packetproc.h"

#include "/usr/src/linux-2.4/include/asm/unistd.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

#include <sys/time.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/un.h>
#include "ini.h"
#include "../PolicySYNC.h"


_syscall3(int,senddata,unsigned char *,buf,int,length,char *,devname)

CCom Com;
int SENDDATA(unsigned char * buf,int length,char *devname)
{
	return senddata(buf,length,devname);
}

extern InPolicySYNC g_InPoliSync;



int main(int argc ,char *argv[])
{
	int   ComFd = 0;
	int   MaxFd = 0;
	int   Ret = 0;
	int   RetLen = 0;
	int   bufLen = 0;
	char  Buf[DATA_MAX_LEN] = {0};
	int   timeout = 10;

	fd_set FdSet;
	
   	//��ʼ����������
	InitList(POLICY_TABLE_NAME);
	//��������ϵͳ����
	ComFd = Com.Open(COM1);
	
	if(ComFd < 0)
	{
		DEBUG_PUT2("MonitorMain��Com Open error %s\n",strerror(errno));
		exit(1);
	}
	else
	{
		DEBUG_PUT2("MonitorMain��Com Listen %d\n",ComFd);
	}
   			
	
	for(;;)
	{
   		FD_ZERO(&FdSet);
   		FD_SET(ComFd, &FdSet);
   				
		MaxFd = ComFd + 1;
		DEBUG_PUT2("MonitorMain�� max listen %d\n",MaxFd);
		
		Ret = select(MaxFd + 1, &FdSet, NULL, NULL, NULL);
	    if(Ret <= 0)
	    {
	    	DEBUG_PUT2(" ----------------select : %s --------------\n",strerror(errno));
	    	break;
	    }
	    
	    //����ϵͳ����������Ӧ���ݴ���
	    if(FD_ISSET(ComFd, &FdSet))
	    {
	    	
	    	memset(Buf,0,DATA_MAX_LEN);
	    	RetLen = Com.Read(Buf,DATA_MAX_LEN);
	    	printf("-------------------%d\n",RetLen);
	    	
	    	//writen by cz
	    	if(RetLen == 2)
	    	{
	    		bufLen = (unsigned char)Buf[0]*256 + (unsigned char)Buf[1];
	    		DEBUG_PUT2("bufLen is %d\n",bufLen);
	    		Buf[0] = 's';
	    		RetLen = Com.Write(Buf,1);
	    		memset(Buf,0,DATA_MAX_LEN);
	    		
	    			    		
				RetLen = Com.Readv(Buf,bufLen,&timeout);
				//RetLen = Com.Readv(Buf,bufLen,NULL);
				if(RetLen!=bufLen)
				{
					DEBUG_PUT("���ڳ�ʱ\n");
					Com.Write("F",1);
					continue;
				}
			//	continue;
				DEBUG_PUT2("recv buf is %s \n",Buf);
				DEBUG_PUT2("RetLen = %d\n",RetLen);
				Process((char *)Buf,RetLen);
				//FD_CLR(ComFd,&FdSet);
				//break;
			}
			else
			{ 
				if(RetLen ==3)
				{
					DEBUG_PUT2("recv buf is %s \n",Buf);
					DEBUG_PUT2("RetLen = %d\n",RetLen);
					Process((char *)Buf,RetLen);
				}
				if(RetLen ==4)
				{
					if(!memcmp(Buf,SHUT,4)){
						//֪ͨ�����ػ�
						if(g_InPoliSync.MakeData(NULL, 0,"s")<0)
						{
							DEBUG_PUT("shutdown : g_InPoliSync.MakeData(NULL, 0,s) failed.\n");
							Com.Write("F",1);
						}else if( g_InPoliSync.SendBuf()<0 )
								{
									DEBUG_PUT("shutdown : g_InPoliSync.SendBuf() failed.\n");
									Com.Write("F",1);
								}
								else 
								{
									Com.Write("S",1);
									if(execl("/sbin/shutdown","shutdown","-h","now",(char*)0)<0)
										{
											perror("error");
										//	Com.Write("F",1);
											//exit(-1);
										}
								}
					}
					if(!memcmp(Buf,REBOOT,4)){
						//֪ͨ��������
						if(g_InPoliSync.MakeData(NULL, 0,"r")<0)
						{
							DEBUG_PUT("reboot : g_InPoliSync.MakeData(NULL, 0,r) failed.\n");
							Com.Write("F",1);
						}else if( g_InPoliSync.SendBuf()<0 )
								{
									DEBUG_PUT("reboot : g_InPoliSync.SendBuf() failed.\n");
									Com.Write("F",1);
								}
								else 
								{
									Com.Write("S",1);
									if(execl("/sbin/reboot","reboot",(char*)0)<0)
										{
											perror("error");
										//	Com.Write("F",1);
											//exit(-1);
										}
								}
					}
						
				}
						
			}	
			
	    }
	}
	Com.Close();
	//����
	
	//writen by cz
	/* writen by zj
	if(RetLen == 4)
	{
		zjProcess((char *)Buf);
	}
	else
	{
		DEBUG_PUT2("LENGTH<>4");
	}*/
	//writen by zj
}







