#ifndef __PACKET_PROCESS_H__
#define __PACKET_PROCESS_H__

#include "macro.h"
#include <stdio.h>
#include <stdlib.h>
#include <stack.h>
#include <sys/socket.h> 
#include <sys/ioctl.h> 
#include <asm/sockios.h> 
#include <net/if.h> 
#include <netinet/in.h> 
 
typedef struct PolicyInfo{
 		unsigned char  M_saddr[6];
        unsigned char  M_daddr[6];
        int  IP_saddr;
        int  IP_daddr;
        int   D_Port;
        int   BannedFlag;
	}POLICY_INFO;
	
//add zj
typedef struct Policy{
		int Rank;
		int Delay_time;
		int Save_time;
	}POLICYINFO;
	
typedef struct Map{
		unsigned char Original_mac[6];
		unsigned char Map_mac[6];
		int Original_ip;
		int Map_ip;
	}MAP_INFO;

typedef struct HostInfo{
	int Host_ip;
	int Host_mask;
	int Host_port;
	unsigned char Host_mac[6];
	}HOST_INFO;
	
//add zj	
	
typedef struct UserInfo{
       char  Disa[8];
       char  Name[8];
      // time_t RegTime;
       char  Rank[1];
       char  Time[10];
        
	}USER_INFO;
 
void Process(char *Buf, int BufLen);
int InitList(char *FileName);
int ChangeByte(unsigned char * ds,const unsigned char * ss);
int ChangeByte1(unsigned char *ds , const unsigned char * ss);
//zj
void zjProcess(char *Buf);
//zj

#endif
