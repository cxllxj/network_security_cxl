#ifndef __MACRO_H__
#define __MACRO_H__

	#define __DEBUG_MODE__ 1
	#ifdef  __DEBUG_MODE__
      
        #define DEBUG_PUT(x) \
            printf(x)
        #define DEBUG_PUT2(x,y) \
            printf(x,y)
        #define DEBUG_PUT3(x,y,z) \
            printf(x,y,z)
        #define DEBUG_PUT4(x,y,z,a) \
            printf(x,y,z,a)
        #define DEBUG_PUT5(x,y,z,a,b) \
            printf(x,y,z,a,b)
        #define DEBUG_PUT6(x,y,z,a,b,c) \
            printf(x,y,z,a,b,c)
        #define DEBUG_PUT7(x,y,z,a,b,c,d) \
            printf(x,y,z,a,b,c,d)
	#else
        #define DEBUG_PUT(x)
        #define DEBUG_PUT2(x,y)
        #define DEBUG_PUT3(x,y,z)
        #define DEBUG_PUT4(x,y,z,a)
        #define DEBUG_PUT5(x,y,z,a,b)
        #define DEBUG_PUT6(x,y,z,a,b,c)
        #define DEBUG_PUT7(x,y,z,a,b,c,d)
	#endif
        
	
			
	
		
	//���ݱ��ĳ��Ⱥ�
	#define PACKET_HEAD_NUM       10
	#define LINE_MAX_LEN          256
	#define FILE_MAX_LEN          256
	#define DATA_MAX_LEN          (1024*3)
	#define PACKET_MAX_LEN        (1024*1024)
	#define MAX_PORT_NUMBER       65535
	#define KEY_MAX_LEN				128
	#define NAME_MAX_LEN				64
	
	#define LOG_FLAG 		'L'
	#define MONITOR_FLAG 	'M'
	#define POLICY_FLAG     'P'
	#define USER_FLAG    	'U'

//added by zj
	#define SYS_FLAG		'S'
	#define MANAGER_FLAG    'M'
	#define LOGIN_FLAG		'J'
	#define CHEAT_FLAG		'F'
	#define MAP_TABLE_NAME		"map.ini"
	#define LOGSVR_FILE		"log.ini"
//added by zj
		
	#define INSERT_FLAG  	'I'
	#define DELETE_FLAG		'D' 
	#define	QUERY_FLAG		'Q'
	#define CERT_FLAG		'C'
	
	#define SUCCESS_FLAG    'S'
	#define FAIL_FLAG 		'F'
	#define END_FLAG		'E'
	#define EXIST_FLAG      'X'
	
	#define SHUT			"shut"		//�ػ�����
	#define REBOOT			"rebt"		//��������
	
	#define COM1                "/dev/ttyS0"
	#define POLICY_TABLE_NAME   "b.ini"
	#define USER_TABLE_NAME     "c.ini"
	#define POLICY_MIN_LEN	12
#endif
