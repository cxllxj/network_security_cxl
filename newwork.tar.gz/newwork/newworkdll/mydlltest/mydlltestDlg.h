// mydlltestDlg.h : header file
//

#if !defined(AFX_MYDLLTESTDLG_H__1F5193AC_0969_4B19_A6C3_754F64AFFC8E__INCLUDED_)
#define AFX_MYDLLTESTDLG_H__1F5193AC_0969_4B19_A6C3_754F64AFFC8E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMydlltestDlg dialog

class CMydlltestDlg : public CDialog
{
// Construction
public:
	CMydlltestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMydlltestDlg)
	enum { IDD = IDD_MYDLLTEST_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMydlltestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMydlltestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBUTTONAdd();
	afx_msg void OnBUTTONDel();
	afx_msg void OnBUTTONQue1();
	afx_msg void OnBUTTONQue2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYDLLTESTDLG_H__1F5193AC_0969_4B19_A6C3_754F64AFFC8E__INCLUDED_)
