#include     <stdio.h>      /*��׼�����������*/
#include     <stdlib.h>     /*��׼�����ⶨ��*/
#include     <unistd.h>     /*Unix ��׼��������*/
#include     <sys/types.h>  
#include     <sys/stat.h>   
#include     <fcntl.h>      /*�ļ����ƶ���*/
#include     <termios.h>    /*PPSIX �ն˿��ƶ���*/
#include     <errno.h>      /*����Ŷ���*/
#include     <sys/time.h>
#include     <unistd.h>
#define BUFFER_LENGTH  20

struct PolicyInfo
{
	unsigned char M_saddr[6];
	unsigned char M_daddr[6];
	int IP_saddr;
	int IP_daddr;
	int D_Port;
	int BannedFlag;
	unsigned int src_ip_map;
	unsigned int dst_ip_map;
};

/**
*@brief  ���ô���ͨ������
*@param  fd     ���� int  �򿪴��ڵ��ļ����
*@param  speed  ���� int  �����ٶ�
*@return  void
*/
int speed_arr[] = { B38400, B19200, B9600, B4800, B2400, B1200, B300,
					B38400, B19200, B9600, B4800, B2400, B1200, B300, };
int name_arr[] = {38400,  19200,  9600,  4800,  2400,  1200,  300, 38400,  
					19200,  9600, 4800, 2400, 1200,  300, };
void set_speed(int fd, int speed){
	int   i; 
	int   status; 
	struct termios   Opt;
	tcgetattr(fd, &Opt); 
	for ( i= 0;  i < sizeof(speed_arr) / sizeof(int);  i++) { 
		if  (speed == name_arr[i]) {     
			tcflush(fd, TCIOFLUSH);     
			cfsetispeed(&Opt, speed_arr[i]);  
			cfsetospeed(&Opt, speed_arr[i]);   
			status = tcsetattr(fd, TCSANOW, &Opt);  
			if  (status != 0) {        
				perror("tcsetattr fd0");  
				return;     
			}    
			tcflush(fd,TCIOFLUSH);   
		}  
	}
}


/**
*@brief   ���ô�������λ��ֹͣλ��Ч��λ
*@param  fd     ����  int  �򿪵Ĵ����ļ����
*@param  databits ����  int ����λ   ȡֵ Ϊ 7 ����8
*@param  stopbits ����  int ֹͣλ   ȡֵΪ 1 ����2
*@param  parity  ����  int  Ч������ ȡֵΪN,E,O,,S
*/
int set_Parity(int fd,int databits,int stopbits,int parity)
{ 
	struct termios options; 
	if  ( tcgetattr( fd,&options)  !=  0) { 
		perror("SetupSerial 1");     
		return -1;  
	}
	options.c_cflag &= ~CSIZE; 
	switch (databits) /*��������λ��*/
	{   
	case 7:		
		options.c_cflag |= CS7; 
		break;
	case 8:     
		options.c_cflag |= CS8;
		break;   
	default:    
		fprintf(stderr,"Unsupported data size\n"); return -1;  
	}
switch (parity) 
{   
	case 'n':
	case 'N':    
		options.c_cflag &= ~PARENB;   /* Clear parity enable */
		options.c_iflag &= ~INPCK;     /* Enable parity checking */ 
		break;  
	case 'o':   
	case 'O':     
		options.c_cflag |= (PARODD | PARENB); /* ����Ϊ��Ч��*/  
		options.c_iflag |= INPCK;             /* Disnable parity checking */ 
		break;  
	case 'e':  
	case 'E':   
		options.c_cflag |= PARENB;     /* Enable parity */    
		options.c_cflag &= ~PARODD;   /* ת��ΪżЧ��*/     
		options.c_iflag |= INPCK;       /* Disnable parity checking */
		break;
	case 'S': 
	case 's':  /*as no parity*/   
	    options.c_cflag &= ~PARENB;
		options.c_cflag &= ~CSTOPB;break;  
	default:   
		fprintf(stderr,"Unsupported parity\n");    
		return -1;  
	}  
/* ����ֹͣλ*/  
switch (stopbits)
{   
	case 1:    
		options.c_cflag &= ~CSTOPB;  
		break;  
	case 2:    
		options.c_cflag |= CSTOPB;  
	   break;
	default:    
		 fprintf(stderr,"Unsupported stop bits\n");  
		 return -1; 
} 
/* Set input parity option */ 
if (parity != 'n')   
	options.c_iflag |= INPCK; 
options.c_lflag &=~(ICANON | ECHO |ECHOE |ISIG);
options.c_oflag &=~OPOST;
tcflush(fd,TCIFLUSH);
options.c_cc[VTIME] = 150; /* ���ó�ʱ15 seconds*/   
options.c_cc[VMIN] = 0; /* Update the options and do it NOW */
if (tcsetattr(fd,TCSANOW,&options) != 0)   
{ 
	perror("SetupSerial 3");   
	return -1;  
} 
return 0;  
}



/**********************************************************************����˵����ʹ�ô��ڶ����Եģ����͵��������ַ���
����û�з����ַ����������ţ����Խ��յ��󣬺�������˽������š��Ҳ���ʹ�õ��ǵ�Ƭ���������ݵ��ڶ������ڣ�����ͨ����
**********************************************************************/
#define FALSE  -1
#define TRUE   0
/*********************************************************************/
int OpenDev(char *Dev)
{
	int	fd = open( Dev, O_RDWR );         //| O_NOCTTY | O_NDELAY	
	if (-1 == fd)	
	{ 			
		perror("Can't Open Serial Port");
		return -1;		
	}	
	else	
		printf("Open Serial success!\n");
		return fd;
}
struct PolicyInfo * ReturnPolicy()
{

	int buflen;
	struct PolicyInfo *return_policy= NULL;
	return_policy=(struct PolicyInfo *)malloc(sizeof(struct PolicyInfo));
	return_policy->M_saddr[0]=0x88;
	return_policy->M_saddr[1]=0x88;
	return_policy->M_saddr[2]=0x88;
	return_policy->M_saddr[3]=0x88;
	return_policy->M_saddr[4]=0x88;
	return_policy->M_saddr[5]=0x88;
	return_policy->M_daddr[0]=0x88;
	return_policy->M_daddr[1]=0x88;
	return_policy->M_daddr[2]=0x88;
	return_policy->M_daddr[3]=0x88;
	return_policy->M_daddr[4]=0x88;
	return_policy->M_daddr[5]=0x88;
	
	return_policy->IP_saddr=htonl(12345678);
	return_policy->IP_daddr=htonl(87654321);
	return_policy->D_Port=htonl(1024);
	return_policy->BannedFlag=htonl(1);
	return_policy->src_ip_map=htonl(92345678);
	return_policy->dst_ip_map=htonl(97654321);
	buflen=sizeof(struct PolicyInfo);
	

	return return_policy;
}

int main(int argc, char **argv){
	/*int ij;
		char str_ij[36];
	*/
	
	
	
	int i,j;
	int fd;
	int packet_seq=1;
	int total_length=0;
	int nread,nwrite,receiveLength,total=0;
	
	char tag[2];
	char *dev  = "/dev/ttyS1"; //���ڶ�
	char response[2]="OK";
	char add_policy_result[2]="SU";
	char del_policy_result[2]="SU";
	unsigned short return_policy_num=18; //����������
	
	unsigned short sendLength=25;
	unsigned short sendLength2,del_id_number,search_id_number;
	char readLen[2],readBegin;
	char *buff_read,*buff_store;
	char *buff_write=(char *)malloc(sendLength);
	struct PolicyInfo *add_policy= NULL;
	unsigned short return_policy_length,return_policy_length2;
	char *return_policy_buf;
	struct PolicyInfo *return_policy= NULL;
	
	
	
	fd = OpenDev(dev);
	set_speed(fd,9600);
	if (set_Parity(fd,8,1,'N') == FALSE)  {
		printf("Set Parity Error\n");
		exit (0);
	}
#if 0 
  	for(i=0;i<5;i++)
  		buff_write[i]='a';
  	
  	nwrite=write(fd,buff_write,5);
	if(nwrite==5)
		printf("Send to serial success!\n");
#endif
//----------------------cxl-----------------------------------------
while(1)
{
//----------------------receive "begin"----------------------------
	while(1) 
	{
	nread=read(fd,&readBegin,1);
	printf("nread=%d\n",nread);
	total+=nread;
	if(total=1)
		break;
	
	}
	printf("Receive begin=%c\n",readBegin);	
	nwrite=write(fd,response,2);
	if(nwrite==2)
		printf("Send begin--response OK succ!\n");
//---------------------receive length-------------------------------
	total=0;
	while(1) 
	{
	nread=read(fd,readLen,2);
	printf("nread=%d\n",nread);
	total+=nread;
	if(total=2)
		{ 
			receiveLength= *(unsigned short *)readLen;
			receiveLength=ntohs(receiveLength);
			printf("receiveLength=%d\n",receiveLength);
			break;
		}
	
	}
	buff_read=(char *)malloc(receiveLength);
	buff_store=(char *)malloc(receiveLength);	
	nwrite=write(fd,response,2);
	if(nwrite==2)
		printf("Send length--response OK succ!\n");
	printf("response=%c%c\n",response[0],response[1]);
//----------------------receive "tag"----------------------------
	total=0;
	while(1) 
	{
	nread=read(fd,tag,2);
	printf("nread=%d\n",nread);
	total+=nread;
	if(total=2)
		break;
	
	}
	printf("Received tag=%c%c\n",tag[0],tag[1]);
	nwrite=write(fd,response,2);
	if(nwrite==2)
		printf("Send tag--response OK succ!\n");
//---------------------receive "value" and transfer to buff_store----------------------------
	total_length=0;
	packet_seq=1;
	while(1)
	{
	  if((nread = read(fd, buff_read, receiveLength))>0);
	   {
	        if(nread==0)
		{	
		  printf("Serial timeout.\n");
	          exit(0);
	        }	  
		printf("\nRead packet %d Len= %d \n",packet_seq++,nread);
		for(j=0;j<nread;j++)
			buff_store[j+total_length]=buff_read[j];
	        total_length+=nread;
	        if(total_length==receiveLength)
		{	
		   printf("Recieve value %d success!\n",total_length);
		   
	        	   
		//buff_read[total_length] = '\0';   
		   if((tag[1]=='a') && (total_length<40))
		   {
			printf("total_length=%d\n",total_length);
			add_policy=(struct PolicyInfo *)malloc(sizeof(struct PolicyInfo));
			memcpy(add_policy,(struct PolicyInfo *)buff_store,total_length);
			
			printf("add_policy->M_saddr[0]=%x\n",add_policy->M_saddr[0]);
			printf("add_policy->IP_saddr=%d\n",ntohl(add_policy->IP_saddr));
			printf("add_policy->IP_daddr=%d\n",ntohl(add_policy->IP_daddr));
			printf("add_policy->D_Port=%d\n",ntohl(add_policy->D_Port));
			printf("add_policy->BannedFlag=%d\n",ntohl(add_policy->BannedFlag));
			printf("add_policy->src_ip_map=%d\n",ntohl(add_policy->src_ip_map));
			printf("add_policy->dst_ip_map=%d\n",ntohl(add_policy->dst_ip_map));
			
		   }
		   if(tag[1]=='d')
		   {
		   	memcpy(&del_id_number,buff_store,total_length);
		   	del_id_number=ntohs(del_id_number);
		   	printf("del_id_number=%d\n",del_id_number);
		    }
		   if(tag[1]=='c')
		   {
		   	printf("Receive tag&value=%c %c%c%c\n",tag[1],buff_store[0],buff_store[1],buff_store[2]);
		    }
		   if(tag[1]=='e')
		   {
		   	memcpy(&search_id_number,buff_store,total_length);
		   	search_id_number=ntohs(search_id_number);
		   	printf("search_id_number=%d\n",search_id_number);
		    }
		   	 
		   	
		   break;
		}
	   }
	}
	if(tag[1]!='e')
	{		
		nwrite=write(fd,response,2);
		if(nwrite==2)
		  printf("Send value--response OK succ!\n");
	}	
//----------------call "system call",return the result--------------------------
        if(tag[1]=='e')
        {
        	return_policy_length=sizeof(struct PolicyInfo);
        	return_policy=ReturnPolicy();
        	return_policy_buf=(char *)malloc(return_policy_length);
        	memcpy(return_policy_buf,return_policy,return_policy_length);
        	
        	
        	return_policy_length2=htons(return_policy_length);
        	nwrite=write(fd,&return_policy_length2,2);
		if(nwrite==2)
		  printf("Send return policy length OK succ!\n");
		
		/*
		for(ij=0;ij<36;ij++)
		   str_ij[ij]='C';
		nwrite=write(fd,str_ij,36);
		if(nwrite==36)
		  printf("Send 36 OK succ!\n");
		  */
		
		nwrite=write(fd,return_policy_buf,return_policy_length);
		if(nwrite==36)
		  printf("Send return policy OK succ!\n");
		 
	}
			
        	
        sleep(1);
        if(tag[1]=='a')
        {
        	nwrite=write(fd,add_policy_result,2);
		if(nwrite==2)
		  printf("Send add_policy_result OK succ!\n");
	}
	if(tag[1]=='d')
        {
        	nwrite=write(fd,del_policy_result,2);
		if(nwrite==2)
		  printf("Send del_policy_result OK succ!\n");
	}
	if(tag[1]=='c')
	{
		return_policy_num=htons(return_policy_num);
		nwrite=write(fd,&return_policy_num,2);
		if(nwrite==2)
		  printf("Send return_policy_num OK succ!\n");
	}
    /*
    	if(tag=="a")
    		rule(buff_store,recieveLength,"a"); 
    	if(tag=="d")
    		rule(buff_store,2,"d");
    	
    	if(tag=="c")
    		rule(buff_store,2,"c");
    	if(tag=="e")
    		rule(buff_store,2,"e");
    		
    	if(system-call succ)
    	{
    		nwrite=write(fd,response,2);
		if(nwrite==2)
		  printf("Send "system call"--response OK succ!\n");	
	}
	else
	{
		response[0]='F';
		response[1]='A';
		nwrite=write(fd,response,2);
		if(nwrite==2)
		  printf("Send "system call"--response FA fail!\n");	
	}
    
    */	
}
//----------------------cxl-----------------------------------------
	
	

		
		
	close(fd);  
	return 0;
}
