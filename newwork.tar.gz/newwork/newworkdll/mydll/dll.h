extern "C" __declspec(dllexport) void rule(char x);

struct PolicyInfo
{
	unsigned char M_saddr[6];
	unsigned char M_daddr[6];
	int IP_saddr;
	int IP_daddr;
	int D_Port;
	int BannedFlag;
	unsigned int src_ip_map;
	unsigned int dst_ip_map;
};