#include "app_rule.h"
#include <stdio.h>
//�ַ����鵽16���������ת��
int  str_to_mac(const char *stringmac, u_char *mac_addr)
{
	u_int ipaddr=0,k=0;
	int i;
	assert(stringmac!=NULL);
	assert(mac_addr!=NULL);
	
	memset(mac_addr,0x00,6);

	for(i=0;stringmac[i]>=0x30 && stringmac[i]<='f' && i<12;i++){
		if(stringmac[i]>='0' && stringmac[i]<='9')
			k = stringmac[i]-'0';
		if(stringmac[i]>='a' && stringmac[i]<='f')
			k = stringmac[i]-'a'+10;
		if(stringmac[i]>='a' && stringmac[i]<='f')
			k = stringmac[i]-'a'+10;
			
		mac_addr[i/2]=(	mac_addr[i/2]<<4)+k;

	}
	if(i<11){printf("   ====failed!===");
		return -1;}
		
	return 0;
}

//ͨ�������ļ���ӳ���ļ���ʼ������
int init_rule(char *rule_file,char *map_file)
{
	FILE *fprule=NULL;
	FILE *fpmap=NULL;
	int buflen6;
	char buf6[36];
	int k=0;
	int ip=0;
	int mapped_ip=0;
	char rule_file_record[100],map_file_record[100]; 
	char *p=NULL;
	char *q=NULL;
	char s1[12],d1[12];
	struct PolicyInfo *pi;
	
	pi = (struct PolicyInfo*)malloc(sizeof(struct PolicyInfo) );
	if(NULL==pi)
		return -1;
		
	fprule=fopen(rule_file,"r");
	if(fprule==NULL){
		printf("Open rule file failed!\n");
		return -1;
	}
	

	
	fgets(rule_file_record,100,fprule);
	while(1)
	{
		//Read Rules File
		p=fgets(rule_file_record,100,fprule);
		if(NULL==p)
			break;
		if(*p=='#')
			break;
		
		
		sscanf(rule_file_record,"%s %s %d %d %d %d",s1,d1,
						&(pi->IP_saddr),&(pi->IP_daddr),
						&(pi->D_Port),&(pi->BannedFlag));
						

		str_to_mac(s1, pi->M_saddr);
		str_to_mac(d1, pi->M_daddr);
		
		memset(rule_file_record,0x00,100);
		
		fpmap=fopen(map_file,"r");
		if(fpmap==NULL){
			printf("Open map file failed!\n");	
			return -1;
		}
		//Read Mapping file
		fgets(map_file_record,100,fpmap);
		while(1)
		{
			q=fgets(map_file_record,100,fpmap);
			if(NULL==q)
				break;
			if(*q=='#')
				break;
			sscanf(map_file_record,"%d %d",&ip,&mapped_ip);
			if(pi->IP_saddr==ip)
				pi->src_ip_map=mapped_ip;
			if(pi->IP_daddr==ip)
				pi->dst_ip_map=mapped_ip;
		}
		fclose(fpmap);
		buflen6=sizeof(struct PolicyInfo);
		memcpy(buf6,pi,buflen6);
		//transfer a rule to kernel
		if(rule(buf6,buflen6,"a")!=0)
		{
			fclose(fprule);   
			free(pi);
			pi=NULL;
			return -1;
		}
	}
	

	fclose(fprule);
	free(pi);
	pi=NULL;
	return 0;
}
