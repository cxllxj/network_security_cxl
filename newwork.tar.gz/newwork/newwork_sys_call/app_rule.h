#ifndef APP_RULE_H
#define APP_RULE_H

#include <stdio.h>
#include <stdlib.h>
#include <linux/unistd.h>
#include <assert.h>


struct PolicyInfo
{
        unsigned char  M_saddr[6];
        unsigned char  M_daddr[6];
        int   IP_saddr;
        int   IP_daddr;
        int   D_Port;
        int   BannedFlag;
        u_int src_ip_map;
        u_int dst_ip_map;
};

int  str_to_mac(const char *stringmac, u_char *mac_addr);

int init_rule(char *rule_file,char *map_file);

//_syscall3(int,rule,char*,buf,int,buflen,char*,access);

#endif //APP_RULE_H
