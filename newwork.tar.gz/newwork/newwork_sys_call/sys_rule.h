/*++

Copyright (c) 1992  �Ϻ���������
 
Module Name:
 
	sys_rule.h

Abstract:

	�������Ե�ϵͳͳ���ã�ʼ��ʼ�������ӡ�ɾ������

Author:

	��С��   July 28, 2003
	
Environment:

	It is included by sys.c in Kernel Mode.

Revision History:


--*/
#ifndef SYS_RULE_H
#define SYS_RULE_H

#include <linux/locks.h>

#define DEBUG_SESSION  //ֻ�ڵ���ʱʹ��

#define MAX_RULE_NUM 40  //����������
struct RuleNode* g_rule_head = NULL;
struct RuleNode* g_rule_tail = NULL;

unsigned int g_ruleNum = 0;
rwlock_t g_rule_lock = RW_LOCK_UNLOCKED;


//������Ϣ�ṹ
struct PolicyInfo
{
        unsigned char  M_saddr[6];
        unsigned char  M_daddr[6];
        int   IP_saddr;
        int   IP_daddr;
        int   D_Port;
        int   BannedFlag;
        u_int src_ip_map;
        u_int dst_ip_map;
};
//������Ϣ�����ڵ�
struct RuleNode
{
	struct PolicyInfo data;
	struct RuleNode * next;
};

/*		 	
struct session_status {

	struct PolicyInfo session_value;
        struct session_status *next;
        
	u_int index;
	u_short		src_real_port;		
	u_short		dst_real_port;		
	struct timeval start_time;		
	struct timeval reach_time;		

	int frame_num;			
	int frame_reject_num;			
	int TCP_status;			
	u_int	seqnum;
	int	timeout;		
	u_int	retrans_num;		
} ;

struct session_status *g_session_head=NULL;
struct session_status *g_session_tail=NULL;
*/

//�ͷŹ��������ͻỰ����
int free_chain()
{
 	struct RuleNode* curr_node,*temp1;
	curr_node=g_rule_head;
	temp1=curr_node;
	while(temp1!=NULL)
	{
		curr_node=temp1;
		temp1=temp1->next;
		kfree(curr_node);
	
	}
	g_rule_head=NULL;
	g_rule_tail=NULL;
/*	
	struct session_status *curr_session,*temp2;
	curr_session=g_session_head;
	temp2=curr_session;
	while(temp2!=NULL)
	{
		curr_session=temp2;
		temp2=temp2->next;
		kfree(curr_session);
	
	}
	g_session_head=NULL;
	g_session_tail=NULL;
	*/
	return 0;

}

//��ӡ���������ͻỰ����
int print_chain()
{
	struct RuleNode* curr_node;
	int 	sip,dip,i;
	
	curr_node=g_rule_head;
	
	i=0;
	printk("[KERNEL]=============Current Rules============\n");
	while(curr_node!=NULL)
	{
		sip = curr_node->data.IP_saddr;
		dip = curr_node->data.IP_daddr;
		i++;
		
		printk("[KERNEL]--No.%d-- %d.%d.%d.%d==>%d.%d.%d.%d \n",i,
			(sip>>24)&0xff,(sip>>16)&0xff,(sip>>8)&0xff,sip&0xff,
			(dip>>24)&0xff,(dip>>16)&0xff,(dip>>8)&0xff,dip&0xff);
					
		curr_node=curr_node->next;
	}
        /*	
	printk("[KERNEL]===========Current Session Table===========\n");
	struct session_status *curr_session;
	curr_session=g_session_head;
	while(curr_session!=NULL)
	{
		sip = curr_session->session_value.IP_saddr;
		dip = curr_session->session_value.IP_daddr;
		printk("[KERNEL] Index=%d Real IP: %d.%d.%d.%d==>%d.%d.%d.%d \n",curr_session->index,
			(sip>>24)&0xff,(sip>>16)&0xff,(sip>>8)&0xff,sip&0xff,
			(dip>>24)&0xff,(dip>>16)&0xff,(dip>>8)&0xff,dip&0xff);
		printk("         PORT: %d -->%d, Packet: %d, TimeOut: %ds \n",
			curr_session->src_real_port,curr_session->dst_real_port,
			curr_session->frame_num,curr_session->timeout);
			
		curr_session=curr_session->next;
	}
	*/
	return 0;
			
}


//ɾ���Ự�����еĽڵ�
/*
int delete_node(struct session_status *current_session)
{
	struct session_status *prev_session=NULL;

	if(current_session==g_session_head)
		//ɾ��ͷ�ڵ�current_session	
		g_session_head=current_session->next;
	else {
		//��ȡҪɾ���Ľڵ��ǰ��ڵ�prev_session
		prev_session=g_session_head;
		while((prev_session->next!=current_session)
		    &&(prev_session->next!=NULL) )
			prev_session=prev_session->next;
		
		if(prev_session->next == NULL)
			return -1;
		
		prev_session->next=current_session->next;
		
		if(prev_session->next==NULL)
			g_session_tail = prev_session;
		
	}
	kfree(current_session);
	return 0;
		
}
*/

//�Ƚϲ�����Ϣ
int compare(struct PolicyInfo *p1,struct PolicyInfo *p2)
{
	int i;
	for(i=0;i<6;i++)
	{
		if(p1->M_saddr[i]!=p2->M_saddr[i])
			return -1;

	}
	
	for(i=0;i<6;i++)
	{
		if(p1->M_daddr[i]!=p2->M_daddr[i])
			return -1;

	}
	
	if(p1->IP_saddr != p2->IP_saddr)
		return -1;
	if(p1->IP_daddr != p2->IP_daddr)
		return -1;
	if(p1->D_Port != p2->D_Port)
		return -1;	
	if(p1->BannedFlag != p2->BannedFlag)
		return -1;
	if(p1->src_ip_map != p2->src_ip_map)
		return -1;
	if(p1->dst_ip_map != p2->dst_ip_map)
		return -1;
	
	return 0;
}


//�Ƚϲ�ɾ���Ự�����Ľڵ�
/*
int del_session_node(struct RuleNode* delNode)
{
	int ret=-1;
	struct session_status *current_session=g_session_head;
	struct session_status *temp = NULL;

	while(current_session!=NULL)
	{
		ret=compare(&(current_session->session_value),&delNode->data);
		temp = current_session->next;
		if(ret==0){
			ret=delete_node(current_session);
		
		}
		current_session = temp;	
	}


        return ret;
}

*/


int add_rule(char* buf, int buflen)
//Function:����һ�����ԡ���Ϊ���Է��㣬�˴��Ѹ���Session�� ��ʵ��ʹ���в��ø���Session��)
//Parameters:
//	buf: 	[in]�����ӵĲ������ݵ�ָ�룬�����ݸ�ʽΪstruct PolicyInfo
//	buflen:	[in]Ϊstruct PolicyInfo���ֽڳ���
//Return Value:
//	return 0 when seuccess
{
	struct RuleNode* newNode = NULL;
	//��μ��
	if( (buf==NULL) || (buflen!=sizeof(struct PolicyInfo)) )
	{
		printk("parameter error.\n");
		return -1;
	}
	if(g_ruleNum>MAX_RULE_NUM)
	{
		printk("too many rules,can't add rule.\n");
		return -1;
	}
	//�����ڴ�
	newNode = kmalloc( sizeof(struct RuleNode), GFP_KERNEL );
	
	if (newNode == NULL)
	{
		printk("can not allocate memory.\n");
		return -1002;
	}
	if (   copy_from_user( (char*)(&(newNode->data)), buf, sizeof(struct PolicyInfo) )   )
	{
		
		kfree(newNode);
		newNode = NULL;
		return -1003;
	}
	
	
	
	//����Ԫ�ص���β
	if( g_rule_head == NULL )
	{
		newNode->next = NULL;
		write_lock(&g_rule_lock);
		g_rule_head = g_rule_tail = newNode;
		write_unlock(&g_rule_lock);
	}else {
		write_lock(&g_rule_lock);
		g_rule_tail->next = newNode;
		newNode->next = NULL;
		g_rule_tail = newNode;
		write_unlock(&g_rule_lock);
	}
	
	g_ruleNum++;
	
#ifdef DEBUG_SESSION	
//�˶δ�������ʽӦ���в���ʹ��
	struct session_status *current_session=NULL;
	current_session = kmalloc( sizeof(struct session_status), GFP_KERNEL );
	
	if (current_session== NULL)
	{
		printk("can not allocate memory.\n");
		return -2;
	}
	memset(current_session,0,sizeof(struct session_status));
	memcpy(&current_session->session_value,&newNode->data,sizeof(struct PolicyInfo));
	
	if(g_session_head==NULL)
	{
		current_session->next=NULL;
		write_lock(&g_rule_lock);
		g_session_head = current_session;
		g_session_tail = current_session;
		write_unlock(&g_rule_lock);
	} else {
		write_lock(&g_rule_lock);
		
		g_session_tail->next = current_session;
		current_session->next = NULL;
		g_session_tail = current_session;
		
		write_unlock(&g_rule_lock);
	}
	
	current_session = g_session_head;
	while(current_session!=NULL){
	
		current_session = current_session->next;
	}
#endif //DEBUG_SESSION

	return 0;
}


//ɾ�����Խڵ��Լ��Ự�ڵ�
int del_rule(char* buf, int buflen)
{
	unsigned int * num = (unsigned int*)buf;
	struct RuleNode* myNode = g_rule_head;
	struct RuleNode* myNode2 = NULL;
	int i = 0;
	//��μ��
	if( (buf==NULL) || (buflen<sizeof(unsigned int)) )
	{ 
		printk("parametet error.\n"); 
		return -1; 
	}
	
	if( (*num<1) || (*num>g_ruleNum) )
	{
		printk("delete error.\n");
		return -1;
	}

	if(*num==1)//����һ����Ҫɾ���Ĳ���
	{ 
		
		myNode = g_rule_head;
		//write_lock(&g_rule_lock);
		g_rule_head = g_rule_head->next;
		if(myNode->next==NULL)
			g_rule_tail = g_rule_head;
		//write_unlock(&g_rule_lock);
		//del_session_node(myNode);
		kfree(myNode);
		myNode = NULL;
	}
	else
	{
		myNode = g_rule_head;
		
		for(i=0;i<(*num-2);i++)
		{
			myNode = myNode->next;
		}
		//write_lock(&g_rule_lock);
		
		myNode2 = myNode->next;
		myNode->next = myNode2->next;
		if(myNode->next==NULL)
			g_rule_tail = myNode;
		//write_unlock(&g_rule_lock);
		//del_session_node(myNode2);
		kfree(myNode2); 
		myNode2 = NULL;
	}
	
	g_ruleNum--;
	return 0;
}
/*
int get_session(char* buf, int buflen)
{
	int number,i;
//	memcpy(&number,buf,4);
	copy_from_user(&number,buf,4);
	printk("number=%d\n",number);	
	
	struct session_status *curr_session = NULL;
	if(number<1)
		return -1001;
	if(g_session_head==NULL)
		return -1002;
	curr_session=g_session_head;
	if(number>1)
	{
		for(i=1;i<number;i++)
		{
//			if(curr_session==NULL)
//				return -1001;
			curr_session=curr_session->next;
			if(curr_session==NULL)
				return -1002;
		}
	}
//	memcpy(buf+4,curr_session,sizeof(struct session_status));
	copy_to_user(buf+4,curr_session,sizeof(struct session_status));
	
	return 0;
}
*/
//ϵͳ����
asmlinkage int sys_rule( char* buf, int buflen, char* access )
{
	int ret = -1;
	if( access==NULL )
	{		
		printk("parameter error.\n");
		return -1000;
	}
	switch(access[0])
	{
		/*
		case 's':
			if(buflen<=0 || buf==NULL)
				return -1000;
			ret=get_session(buf,buflen);
			break;
			*/
		case 'a':
			if(buflen<=0 || buf==NULL)
				return -1000;
			ret = add_rule(buf, buflen);	
			break;
		case 'd':	
			if(buflen<=0 || buf==NULL)
				return -1000;
			ret = del_rule(buf, buflen);	
			break;
		case 'p':	
			ret = print_chain();            
			break;	
		case 'f':       
			ret = free_chain();               
			break;   
		default:	
			ret = -1001;
	}
	return ret;
}

#endif //SYS_RULE_H
////////////////////////////////////////////////////////////////////////////////////////////


