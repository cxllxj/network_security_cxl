#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "app_rule.h"

//������Ϣ�ṹ
/*
struct session_status
{
	struct PolicyInfo session_value;
	struct session_status *next;

	u_int index;
	u_short src_real_port;
	u_short dst_real_port;
	struct timeval start_time;
	struct timeval reach_time;

	int frame_num;
	int frame_reject_num;
	int TCP_status;
	u_int seqnum;
	int timeout;
	u_int retrans_num;
};
struct session_status_num
{
	int number;
	struct session_status s_status;
};
*/
//��ȡһ�����Ե�����
struct PolicyInfo *get_buf()
{

	int buflen;
	struct PolicyInfo *add_policy= NULL;
	add_policy=(struct PolicyInfo *)malloc(sizeof(struct PolicyInfo));
	add_policy->M_saddr[0]=0x88;
	add_policy->M_saddr[1]=0x88;
	add_policy->M_saddr[2]=0x88;
	add_policy->M_saddr[3]=0x88;
	add_policy->M_saddr[4]=0x88;
	add_policy->M_saddr[5]=0x88;
	add_policy->M_daddr[0]=0x88;
	add_policy->M_daddr[1]=0x88;
	add_policy->M_daddr[2]=0x88;
	add_policy->M_daddr[3]=0x88;
	add_policy->M_daddr[4]=0x88;
	add_policy->M_daddr[5]=0x88;
	
	add_policy->IP_saddr=12345678;
	add_policy->IP_daddr=87654321;
	add_policy->D_Port=1024;
	add_policy->BannedFlag=1;
	add_policy->src_ip_map=92345678;
	add_policy->dst_ip_map=97654321;
	buflen=sizeof(struct PolicyInfo);
	

	return add_policy;

}

_syscall3(int,rule,char*,buf,int,buflen,char*,access)

int main()
{
        int ret;
	int i;
	int sip,dip;
	int buflen=36;
	char choice[64];
	char buf[36]=" ";
	int buflen5;
	char buf5[4];
	choice[0]='c';
	unsigned long del_buf_id;
	struct PolicyInfo * addnode=NULL;
//	struct session_status_num *ptr_session_num=NULL;
	for(;;) {
		
	switch(choice[0])
	{
		
		/*
		case 's' :
			ptr_session_num=(struct session_status_num *)malloc(sizeof(struct session_status_num));
			memset(ptr_session_num,0,sizeof(struct session_status_num));
			for(i=1;;i++){
			ptr_session_num->number=i;
			
			ret=rule((char*)ptr_session_num,sizeof(struct session_status_num),"s");
			if(ret<0)
			{	
				printf("Input number of session error!\n");
				break;
			}
			if(ret==-1002)
			{
				printf("Session is empty!\n");
				break;
			}
			sip=ptr_session_num->s_status.session_value.IP_saddr;
			dip=ptr_session_num->s_status.session_value.IP_daddr;
			printf("SIP=%d.%d.%d.%d\n",(sip>>24)&0xff,
					(sip>>16)&0xff,
					(sip>>8)&0xff,sip&0xff);
			printf("DIP=%d.%d.%d.%d\n",(dip>>24)&0xff,
					(dip>>16)&0xff,
					(dip>>8)&0xff,dip&0xff);
			}
			free(ptr_session_num);

		break;
		*/
		case 'i':
			init_rule("rules.txt","mapping_file.txt");
			break;
		case 'a':
	
			addnode = get_buf();
			rule((char*)addnode,sizeof(struct PolicyInfo),"a"); 
			free(addnode);
			addnode = NULL;
		        break;	
		case 'd':
			//buf5[0]=2;  //delete the second record 
			//buf5[1]=0;
			//buf5[2]=0;
			//buf5[3]=0;
			//buflen5=4;
			del_buf_id=2;//delete the second record
			memcpy(buf5,del_buf_id,4);
			rule(buf5,buflen5,"d");
			break;
		case 'p':
			rule(buf,buflen,"p");
		     	break;	
		case 'f':
			rule(buf,buflen,"f"); 
		      	break;
		case 'q':
			return 0;	

		default:
			printf("Input choice error!\n");
			break;
	}	
		//printf("\n[s]  get session.\n");
		printf("[i]  initialize policy.\n");
		printf("[a]  add a policy.\n");
		printf("[d]  delete a policy.\n");
		printf("[p]  print policy chain.\n");
		printf("[f]  free policy chain.\n");
		printf("[q]  Quit.\n");
		printf("Please choice number:");
			
	
		scanf("%s",choice);
					
	}
	return 0;	
	
}

