    today=new Date();                                                                                                  
    var hours = today.getHours();                                                                                                  
    var minutes = today.getMinutes();                                                                                                  
    var seconds = today.getSeconds();                                                                                                  
    var timeValue = "<FONT COLOR=red>" + ((hours >12) ? hours -12 :hours); timeValue += ((minutes < 10) ? "<BLINK><FONT COLOR=red>:</FONT></BLINK>0" : "<BLINK><FONT COLOR=red>:</FONT></BLINK>") + minutes+"</FONT>";                                                                                                  
    function initArray(){                                                                                                  
    this.length=initArray.arguments.length                                                                                                  
    for(var i=0;i<this.length;i++)                                                                                                  
    this[i+1]=initArray.arguments[i] }                                                                                                  
    var d=new initArray("<font color=RED>������</font>","����һ","���ڶ�","������","������","������","<font color=GREEN>������</font></font>");                                                                                                  
 document.write(today.getYear(),"��",today.getMonth()+1,"��",today.getDate(),"��"," ",d[today.getDay()+1]);