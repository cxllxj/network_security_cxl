#include <windows.h>
#include <stdio.h>

void sample_function ( char* s, int size )
{
	char buffer[10];
	printf ( " Hello World! " );
	memcpy ( buffer, s ,size);
}

void main()
{
	char buf[60];
	int i;
	for (i=10; i<70; i++)
	{
		buf[i-10] = (char)i;
	}
	sample_function( buf,60);
}
