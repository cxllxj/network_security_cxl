// RandomKey.h : main header file for the RANDOMKEY application
//

#if !defined(AFX_RANDOMKEY_H__5304E8D6_AFCE_466A_9B7F_9156D82EB224__INCLUDED_)
#define AFX_RANDOMKEY_H__5304E8D6_AFCE_466A_9B7F_9156D82EB224__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CRandomKeyApp:
// See RandomKey.cpp for the implementation of this class
//

class CRandomKeyApp : public CWinApp
{
public:
	CRandomKeyApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRandomKeyApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CRandomKeyApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RANDOMKEY_H__5304E8D6_AFCE_466A_9B7F_9156D82EB224__INCLUDED_)
