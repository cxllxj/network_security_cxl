// A5EncryptionDlg.h : header file
//

#if !defined(AFX_A5ENCRYPTIONDLG_H__04887AAA_7B00_4D86_BE4E_68F762EF50AC__INCLUDED_)
#define AFX_A5ENCRYPTIONDLG_H__04887AAA_7B00_4D86_BE4E_68F762EF50AC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CA5EncryptionDlg dialog
#define DCLARE_A5
typedef struct {
	unsigned long r1,r2,r3;
} a5_ctx;
//��ԿԤ�ú���
extern "C" void a5_key(a5_ctx *c,char *k);
//���ܺ���
extern "C" void a5_encrypt(a5_ctx *c,char *data, int len);
//���ܺ���
extern "C" void a5_decrypt(a5_ctx *c,char *data, int len);

void Hex_Char(unsigned char *bufin,unsigned char *bufout,int  len);
void Char_Hex(unsigned char *bufin,unsigned char *bufout,int  len);

class CA5EncryptionDlg : public CDialog
{
// Construction
public:
	CA5EncryptionDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CA5EncryptionDlg)
	enum { IDD = IDD_A5ENCRYPTION_DIALOG };
	CString	m_key;
	CString	m_plain;
	CString	m_decrypt;
	CString	m_cipher;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CA5EncryptionDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CA5EncryptionDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnEncrypt();
	afx_msg void OnDecrypt();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_A5ENCRYPTIONDLG_H__04887AAA_7B00_4D86_BE4E_68F762EF50AC__INCLUDED_)
