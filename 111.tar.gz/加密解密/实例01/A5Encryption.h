// A5Encryption.h : main header file for the A5ENCRYPTION application
//

#if !defined(AFX_A5ENCRYPTION_H__B29F7816_56C3_4230_8E5D_8D930DF12C01__INCLUDED_)
#define AFX_A5ENCRYPTION_H__B29F7816_56C3_4230_8E5D_8D930DF12C01__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CA5EncryptionApp:
// See A5Encryption.cpp for the implementation of this class
//

class CA5EncryptionApp : public CWinApp
{
public:
	CA5EncryptionApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CA5EncryptionApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CA5EncryptionApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_A5ENCRYPTION_H__B29F7816_56C3_4230_8E5D_8D930DF12C01__INCLUDED_)
