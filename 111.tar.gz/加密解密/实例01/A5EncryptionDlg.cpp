// A5EncryptionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "A5Encryption.h"
#include "A5EncryptionDlg.h"
#include "a5.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CA5EncryptionDlg dialog

CA5EncryptionDlg::CA5EncryptionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CA5EncryptionDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CA5EncryptionDlg)
	m_key = _T("");
	m_plain = _T("");
	m_decrypt = _T("");
	m_cipher = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CA5EncryptionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CA5EncryptionDlg)
	DDX_Text(pDX, IDC_KEY, m_key);
	DDX_Text(pDX, IDC_PLAINTEXT, m_plain);
	DDX_Text(pDX, IDC_DECRYPTTEXT, m_decrypt);
	DDX_Text(pDX, IDC_CIPHERTEXT, m_cipher);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CA5EncryptionDlg, CDialog)
	//{{AFX_MSG_MAP(CA5EncryptionDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_ENCRYPT, OnEncrypt)
	ON_BN_CLICKED(IDC_DECRYPT, OnDecrypt)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CA5EncryptionDlg message handlers

BOOL CA5EncryptionDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CA5EncryptionDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CA5EncryptionDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CA5EncryptionDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CA5EncryptionDlg::OnEncrypt() 
{
	a5_ctx c;
	unsigned char data[101]={0};
	unsigned char key[9]={0};
	unsigned char out[101]={0};
	int i,len;
	
	UpdateData(TRUE);
	Char_Hex((unsigned char*)m_key.GetBuffer(16),key,m_key.GetLength ()/2);
	Char_Hex((unsigned char*)m_plain.GetBuffer (400),data,m_plain.GetLength ()/2);
	len=m_plain.GetLength ()/2;

	a5_key(&c,(char*)key);
	a5_encrypt(&c,(char*)data,len);
	Hex_Char(data,out,len);
	strcpy(m_cipher.GetBuffer (400),(char*)out);
	UpdateData(FALSE);
}

void CA5EncryptionDlg::OnDecrypt() 
{
	a5_ctx c;
	unsigned char data[101]={0};
	unsigned char key[9]={0};
	unsigned char out[101]={0};
	int i,len;
	
	UpdateData(TRUE);
	Char_Hex((unsigned char*)m_key.GetBuffer(16),key,m_key.GetLength ()/2);
	Char_Hex((unsigned char*)m_cipher.GetBuffer (400),data,m_cipher.GetLength ()/2);
	len=m_cipher.GetLength ()/2;

	a5_key(&c,(char*)key);
	a5_decrypt(&c,(char*)data,1);
	a5_decrypt(&c,(char*)(data+1),99);
	Hex_Char(data,out,len);
	strcpy(m_decrypt.GetBuffer (400),(char*)out);
	UpdateData(FALSE);
}

void Char_Hex(unsigned char *bufin,unsigned char *bufout,int  len)
{
	int j=0;
	unsigned char temp1=0;
	unsigned char temp2=0;

	for(int i=0;i<len;i++)
	{
		temp1=bufin[j];
		temp2=bufin[j+1];
		if(temp1>=48&&temp1<=57)
			temp1-=48;
		else if(temp1>=97&&temp1<=102)
			temp1-=87;
		else if(temp1>=65 &&temp1<=70)
			temp1-=55;
		if(temp2>=48&&temp2<=57)
			temp2-=48;
		else if(temp2>=97&&temp2<=102)
			temp2-=87;
		else if(temp2>=65 &&temp2<=70)
			temp2-=55;
		bufout[i]=(temp1<<4)|temp2;
		j++;
		j++;
	}
}

void Hex_Char(unsigned char *bufin,unsigned char *bufout,int  len)
{
	int j=0;
	unsigned char temp1=0;
	unsigned char temp2=0;
	for(int i=0;i<len;i++)
	{
		temp1=bufin[i]&0x0F;
		temp2=bufin[i]>>4;
		if(temp1>=0&&temp1<=9)
			temp1+=48;
		else
			temp1+=87;
		if(temp2>=0&&temp2<=9)
			temp2+=48;
		else
			temp2+=87;
		bufout[j]=temp2;
		bufout[j+1]=temp1;
		j++;
		j++;
	}
}

