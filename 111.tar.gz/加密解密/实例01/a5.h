#ifndef DCLARE_A5
typedef struct {
	unsigned long r1,r2,r3;
} a5_ctx;
#endif

static int threshold(unsigned int r1,unsigned int r2,unsigned int r3);
unsigned long clock_r1(int ctl,unsigned long r1);
unsigned long clock_r2(int ctl,unsigned long r2);
unsigned long clock_r3(int ctl,unsigned long r3);
int keystream(unsigned char *key,unsigned long frame,unsigned char *alice,unsigned char *bob);
int a5_step(a5_ctx *c);

extern void a5_key(a5_ctx *c,char *k);

extern void a5_encrypt(a5_ctx *c, char *data, int len);

extern void a5_decrypt(a5_ctx *c, char *data, int len);