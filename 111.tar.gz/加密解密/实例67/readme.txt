Advanced Excel 2000 Password Recovery
=====================================
(c) 2001 ElcomSoft Co.Ltd.


* System requirements
* Overview
* Registration
* History
* Contact information


System requirements
-------------------

- Pentium or higher CPU
- 8 megabytes RAM
- Windows 95, Windows 98, Windows ME, Windows NT, Windows 2000
  or Windows XP operating system
- less than 2 megabytes of space on hard disk


Overview
--------

A program to recover lost or forgotten passwords to
files/documents created in Microsoft Excel: password to open,
password to modify, passwords to workbook and individual sheets.
Most passwords are recovered instantly; "password to open" for
Excel 97/2000/XP documents, however, is very strong and requires
brute-force and dictionary attacks (plese look at the
help file for details), which are effective for short (up
to 7-8 chars) or simple passwords only.

If you want to recover passwords to file/documents created
in other MS Office components (Word, Outlook, Outlook
Express, VBA, user-level security in Access) and other
Microsoft software (such as Project, Backup, Mail, Schedule+),
please look at Advanced Office 2000 Password Recovery which
is available at:

http://www.elcomsoft.com/ao2000pr.html


Registration
------------

Unregistered (trial version) has some limitations; fully
registered version costs $30 (personal license) or $60
(business license). See "order.txt" for more details.


History
-------

See "whatsnew.txt".


Contact information
-------------------

Please send your suggestions and bug reports to
support@elcomsoft.com (don't forget to mention what version
of AE2000R you're using). The most current version of AE2000PR
is always available at:

http://www.elcomsoft.com/ae2000pr.html

Other password recovery products (for ZIP, ARJ, RAR and ACE
archives; all Microsoft Office components and some other
Microsoft software; Lotus Organizer, Lotus 1-2-3, Lotus WordPro,
Lotus Approach; Corel Paradox, WordPerfect and QuattroPro; Symentec
ACT!, Intuit Quicken and QuickBooks; Adobe Acrobat PDF; instant
messengers; email clients) are available at:

http://www.elcomsoft.com/prs.html
