// DESEncryptionDlg.h : header file
//

#if !defined(AFX_DESENCRYPTIONDLG_H__E4C739EA_0C71_488D_A5C0_63AD2D5719E7__INCLUDED_)
#define AFX_DESENCRYPTIONDLG_H__E4C739EA_0C71_488D_A5C0_63AD2D5719E7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CDESEncryptionDlg dialog
//�����Ϊ8�ֽڣ�keyΪ8�ֽ�
extern "C" void my_des(unsigned char *inblock, unsigned char *outblock,unsigned char *m_key,short edf);
void Hex_Char(unsigned char *bufin,unsigned char *bufout,int  len);
void Char_Hex(unsigned char *bufin,unsigned char *bufout,int  len);

class CDESEncryptionDlg : public CDialog
{
// Construction
public:
	CDESEncryptionDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDESEncryptionDlg)
	enum { IDD = IDD_DESENCRYPTION_DIALOG };
	CString	m_key;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDESEncryptionDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDESEncryptionDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnEncrypt();
	afx_msg void OnDecrypt();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DESENCRYPTIONDLG_H__E4C739EA_0C71_488D_A5C0_63AD2D5719E7__INCLUDED_)
