// 3DESEncryptionDlg.h : header file
//

#if !defined(AFX_3DESENCRYPTIONDLG_H__B8A0A782_41E8_42C5_9675_3C8A605AD4FF__INCLUDED_)
#define AFX_3DESENCRYPTIONDLG_H__B8A0A782_41E8_42C5_9675_3C8A605AD4FF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMy3DESEncryptionDlg dialog
extern "C" void my_des(unsigned char *inblock, unsigned char *outblock,unsigned char *m_key,short edf);
void Hex_Char(unsigned char *bufin,unsigned char *bufout,int  len);
void Char_Hex(unsigned char *bufin,unsigned char *bufout,int  len);

void my_cbc3des(unsigned char *inblock, int len, unsigned char *outblock, unsigned char *m_key, short edf);
void my_3des(unsigned char *inblock, unsigned char *outblock, unsigned char *m_key, short edf);
class CMy3DESEncryptionDlg : public CDialog
{
// Construction
public:
	CMy3DESEncryptionDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMy3DESEncryptionDlg)
	enum { IDD = IDD_MY3DESENCRYPTION_DIALOG };
	CString	m_key;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMy3DESEncryptionDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMy3DESEncryptionDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnEncrypt();
	afx_msg void OnDecrypt();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_3DESENCRYPTIONDLG_H__B8A0A782_41E8_42C5_9675_3C8A605AD4FF__INCLUDED_)
