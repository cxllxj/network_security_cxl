// 3DESEncryptionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "3DESEncryption.h"
#include "3DESEncryptionDlg.h"
#include "d3des.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy3DESEncryptionDlg dialog

CMy3DESEncryptionDlg::CMy3DESEncryptionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMy3DESEncryptionDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMy3DESEncryptionDlg)
	m_key = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMy3DESEncryptionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMy3DESEncryptionDlg)
	DDX_Text(pDX, IDC_KEY, m_key);
	DDV_MaxChars(pDX, m_key, 32);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMy3DESEncryptionDlg, CDialog)
	//{{AFX_MSG_MAP(CMy3DESEncryptionDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_ENCRYPT, OnEncrypt)
	ON_BN_CLICKED(IDC_DECRYPT, OnDecrypt)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy3DESEncryptionDlg message handlers

BOOL CMy3DESEncryptionDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMy3DESEncryptionDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMy3DESEncryptionDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMy3DESEncryptionDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMy3DESEncryptionDlg::OnEncrypt() 
{
	unsigned char key[17]={0},input[10*1024]={0},output[10*1024]={0};
	CString filename,distname;
	CFile pfile,lfile;
	int len;

	UpdateData(TRUE);
	if(m_key.GetLength ()!=32)
		AfxMessageBox("��Կ���Ȳ���16�ֽ�!");
	Char_Hex((unsigned char*)m_key.GetBuffer (33),key,16);

	CFileDialog pfdlg(TRUE,NULL,NULL,OFN_READONLY,"File(*.*)|*.*");
	if(pfdlg.DoModal ()==IDCANCEL)
		return;
	filename=pfdlg.GetPathName ();
	distname=filename.Left (filename.Find (pfdlg.GetFileName ()));
	distname+="cipher.";
	distname+=pfdlg.GetFileExt ();
	pfile.Open (filename,CFile::modeReadWrite);
	lfile.Open (distname,CFile::modeCreate|CFile::modeReadWrite);
	pfile.Read (input,pfile.GetLength ());
	len=8-pfile.GetLength ()%8;
	my_cbc3des(input,pfile.GetLength (),output,key,EN0);
	lfile.Write (output,pfile.GetLength ()+len);
	itoa(len,(char*)input,10);
	lfile.Write (input,1);
	pfile.Close ();
	lfile.Close ();
}

void CMy3DESEncryptionDlg::OnDecrypt() 
{
	unsigned char key[17]={0},input[10*1024]={0},output[10*1024]={0};
	CString filename,distname;
	CFile pfile,lfile;
	int len;

	UpdateData(TRUE);
	if(m_key.GetLength ()!=32)
		AfxMessageBox("��Կ���Ȳ���16�ֽ�!");
	Char_Hex((unsigned char*)m_key.GetBuffer (17),key,16);
	CFileDialog pfdlg(TRUE,NULL,NULL,OFN_READONLY,"File(*.*)|*.*");
	if(pfdlg.DoModal ()==IDCANCEL)
		return;
	filename=pfdlg.GetPathName ();
	distname=filename.Left (filename.Find (pfdlg.GetFileName ()));
	distname+="plain.";
	distname+=pfdlg.GetFileExt ();
	pfile.Open (filename,CFile::modeReadWrite);
	lfile.Open (distname,CFile::modeCreate|CFile::modeReadWrite);

	pfile.Read (input,pfile.GetLength ()-1);
	my_cbc3des(input,pfile.GetLength ()-1,output,key,DE1);
	pfile.Read (input,1);
	input[1]=0x00;
	len=atoi((char*)input);
	lfile.Write (output,pfile.GetLength ()-1-len);
	pfile.Close ();
	lfile.Close ();
}

void my_cbc3des(unsigned char *inblock, int len, unsigned char *outblock, unsigned char *m_key, short edf)
{
	unsigned char vector[9]={0};
	unsigned char temp[9]={0};
	int blocknum;
	int i,j;

	blocknum=len/8;
	if((len%8)!=0)
		blocknum++;

	memset(vector,0x00,8);
	if(edf == EN0)
	{
		for(i=0;i<blocknum;i++)
		{
			for(j=0;j<8;j++)
				vector[j]^=inblock[i*8+j];
			my_3des(vector,temp,m_key,EN0);
			memcpy(&outblock[i*8],temp,8);
			memcpy(vector,temp,8);
		}
	}
	if(edf == DE1)
	{
		for(i=0;i<blocknum;i++)
		{
			my_3des(&inblock[i*8],temp,m_key,DE1);
			for(j=0;j<8;j++)
				vector[j]^=temp[j];
			memcpy(&outblock[i*8],vector,8);
			memcpy(vector,&inblock[i*8],8);
		}
	}
}

void my_3des(unsigned char *inblock, unsigned char *outblock, unsigned char *m_key, short edf)
{
	unsigned char k1[9]={0},k2[9]={0};
	unsigned char temp1[9]={0},temp2[9]={0};

	memcpy(k1,m_key,8);
	memcpy(k2,m_key+8,8);

	my_des(inblock,temp1,k1,edf);
	my_des(temp1,temp2,k2,!edf);
	my_des(temp2,outblock,k1,edf);
}

void Char_Hex(unsigned char *bufin,unsigned char *bufout,int  len)
{
	int j=0;
	unsigned char temp1=0;
	unsigned char temp2=0;

	for(int i=0;i<len;i++)
	{
		temp1=bufin[j];
		temp2=bufin[j+1];
		if(temp1>=48&&temp1<=57)
			temp1-=48;
		else if(temp1>=97&&temp1<=102)
			temp1-=87;
		else if(temp1>=65 &&temp1<=70)
			temp1-=55;
		if(temp2>=48&&temp2<=57)
			temp2-=48;
		else if(temp2>=97&&temp2<=102)
			temp2-=87;
		else if(temp2>=65 &&temp2<=70)
			temp2-=55;
		bufout[i]=(temp1<<4)|temp2;
		j++;
		j++;
	}
}

void Hex_Char(unsigned char *bufin,unsigned char *bufout,int  len)
{
	int j=0;
	unsigned char temp1=0;
	unsigned char temp2=0;
	for(int i=0;i<len;i++)
	{
		temp1=bufin[i]&0x0F;
		temp2=bufin[i]>>4;
		if(temp1>=0&&temp1<=9)
			temp1+=48;
		else
			temp1+=87;
		if(temp2>=0&&temp2<=9)
			temp2+=48;
		else
			temp2+=87;
		bufout[j]=temp2;
		bufout[j+1]=temp1;
		j++;
		j++;
	}
}
