///////////////////////////////////////////////////////////////////////////////////////
//�ӿڶ��壺
//int add_rule(char* buf, int buflen)
//int del_rule(char* buf, int buflen)
//int clear_rule()
//
//
//
//
//
//
///////////////////////////////////////////////////////////////////////////////////////


#define MAX_RULE_NUM 40  //����������
struct RuleNode* g_rule_head = NULL;
struct RuleNode* g_rule_tail = NULL;



#include <linux/locks.h>
unsigned int g_ruleNum = 0;
rwlock_t g_rule_lock = RW_LOCK_UNLOCKED;

struct session_status {
//	struct rule_record_node session_value;	/*��ǰ�Ự�ĸ�ֵ����IP��port,mac��*/
	struct PolicyInfo session_value;
        struct session_status *next;
        
	u_int index;
	u_short		src_real_port;		/*��������������ʵ��Դ�˿ں�*/
	u_short		dst_real_port;		/*��������������ʵ��Ŀ�Ķ˿ں�*/
	struct timeval start_time;		/* �Ự��ʼʱ�� */
	struct timeval reach_time;		/* ���������ʱ�� */
//	u_short src_port;
//	u_int	src_ip;
//	u_char   src_mac[6];
//	u_short  dst_port;
//	u_int    dst_ip;
//	u_char   dst_mac[6];
	int frame_num;			/* �ûỰ�ڼ�ͨ���ı������� */
	int frame_reject_num;			/* �ûỰ�ڼ�ܾ��ı������� */
	int TCP_status;			/* SYN or FIN or other status */
	u_int	seqnum;
	int	timeout;		//��ʱ������
	u_int	retrans_num;		//��16λ��Ϊ���䷽�򣻵�16λ��Ϊ�ش��İ�������
} ;		 	/* �Ự״̬ */

//������Ϣ�ṹ
struct PolicyInfo
{
        unsigned char  M_saddr[6];
        unsigned char  M_daddr[6];
        int   IP_saddr;
        int   IP_daddr;
        int   D_Port;
        int   BannedFlag;
        u_int src_ip_map;
        u_int dst_ip_map;
};
//������Ϣ�����ڵ�
struct RuleNode
{
	struct PolicyInfo data;
	struct RuleNode * next;
};

//extern struct session_status *g_session_head=NULL;
//extern struct session_status *g_session_tail=NULL;
struct session_status *g_session_head=NULL;
struct session_status *g_session_tail=NULL;

int print_chain()
{
	struct RuleNode* curr_node;
	curr_node=g_rule_head;
	if(curr_node!=NULL)
	{
		printf("curr_node->data.IP_saddr=%d\n",curr_node->data.IP_saddr);		
		curr_node=curr_node->next;
	}
	
	
	struct session_status *curr_session;
	curr_session=g_session_head;
	if(curr_session!=NULL)
	{
		printf("curr_session->data.IP_saddr=%d\n",curr_session->session_value.IP_saddr);		
		curr_session=curr_session->next;
	}
	
	return 0;
			
}
int delete_node(current_session)
{
	struct session_status *prev_session=NULL;
	//ɾ��ͷ�ڵ�current_session
	if(current_session==g_session_head)
		g_session_head=current_session->next;
	else {
		//��ȡҪɾ���Ľڵ��ǰ��ڵ�prev_session
		prev_session=g_session_head;
		while(prev_session->next!=current_session)
			prev_session=prev_session->next;
		//���м�ɾ���ڵ�current_session	
		if(current_session->next!=NULL)
			prev_session->next=current_session->next;
		//��β��ɾ���ڵ�current_session	
		else
			prev_session->next=NULL;
	  		
	}
	free(current_session);
	return 0;
		
}
int compare(struct PolicyInfo *p1,struct PolicyInfo *p2)
{
	int i;
	for(i=0;i<6;i++)
	{
		if(p1->M_saddr[i]!=p2->M_saddr[i])
		{
			
			return -1;
		}
	}
	
	for(i=0;i<6;i++)
	{
		if(p1->M_daddr[i]!=p2->M_daddr[i])
		{
			
			return -1;
		}
	}
	
	if(p1->IP_saddr != p2->IP_saddr)
		return -1;
	if(p1->IP_daddr != p2->IP_daddr)
		return -1;
	if(p1->D_Port != p2->D_Port)
		return -1;	
	if(p1->BannedFlag != p2->BannedFlag)
		return -1;
	if(p1->src_ip_map != p2->src_ip_map)
		return -1;
	if(p1->dst_ip_map != p2->dst_ip_map)
		return -1;
	
	
	return 0;
		
		
		
}

int del_session_node(struct RuleNode* delNode)
{
	int ret=-1;
	struct session_status *current_session=g_session_head;
	while(current_session!=NULL)
	{
		ret=compare(&current_session.session_value,&delNode->data);
		if(ret==0)
			break;
		current_session=current_session->next;	
	}
	ret=delete_node(current_session);

        return ret;
}


//////////////////////////////////////////////////////////////////////////////////////
//���Ӳ��Բ��ø���Session��///////////////////////////////////////////////
int add_rule(char* buf, int buflen)
{
	struct RuleNode* newNode = NULL;
	//��μ��
	if( (buf==NULL) || (buflen!=sizeof(struct PolicyInfo)) )
	{
		printf("parameter error.\n");
		return -1;
	}
	if(g_ruleNum>MAX_RULE_NUM)
	{
		printf("too many rules,can't add rule.\n");
		return -1;
	}
	//�����ڴ�
	//newNode = kmalloc( sizeof(struct RuleNode), GFP_KERNEL );
	newNode = malloc( sizeof(struct RuleNode));
	if (newNode == NULL)
	{
		printf("can not allocate memory.\n");
		return -2;
	}
	//if (   copy_from_user( (char*)(&(newNode->data)), buf, sizeof(struct PolicyInfo) )   )
	if (   strcpy( (char*)(&(newNode->data)), buf)   )
	{
		free(newNode);
		newNode = NULL;
		return -3;
	}
	
	
/*	for(i=0;i<6;i++)
	{
		printk("newNode->data.M_saddr[i] = %c\n",newNode->data.M_saddr[i]);
	}
	for(i=0;i<6;i++)
	{
		printk("newNode->data.M_daddr[i] = %c\n",newNode->data.M_daddr[i]);
	}
	printk("newNode->data.IP_saddr   = %d\n",newNode->data.IP_saddr);
	printk("newNode->data.IP_daddr   = %d\n",newNode->data.IP_daddr);
	printk("newNode->data.D_Port     = %d\n",newNode->data.D_Port);
	printk("newNode->data.BannedFlag = %d\n",newNode->data.BannedFlag);
*/	
	
	//����Ԫ�ص���β
	if( g_rule_head == NULL )
	{
		newNode->next = NULL;
		//write_lock(&g_rule_lock);
		g_rule_head = g_rule_tail = newNode;
		//write_unlock(&g_rule_lock);
	}
	else {
			//write_lock(&g_rule_lock);
			g_rule_tail->next = newNode;
			newNode->next = NULL;
			g_rule_tail = newNode;
			//write_unlock(&g_rule_lock);
		 }
	
	g_ruleNum++;
	#if 1
	struct session_status *current_session=NULL;
	//current_session = kmalloc( sizeof(struct session_status), GFP_KERNEL );
	current_session = malloc( sizeof(struct session_status) );
	if (current_session== NULL)
	{
		printf("can not allocate memory.\n");
		return -2;
	}
	memset(current_session,0,sizeof(struct session_status));
	memcpy(current_session->session_value,newNode->data,sizeof(struct PolicyInfo));
	if(g_session_head==NULL)
	{
		current_session->next=NULL;
		//write_lock(&g_rule_lock);
		g_session_head = current_session;
		//write_unlock(&g_rule_lock);
	} else {
		//write_lock(&g_rule_lock);
		g_rule_tail->next = current_session;
		current_session->next = NULL;
		g_rule_tail = current_session;
		//write_unlock(&g_rule_lock);
	}
	#endif	
	return 0;
}

//////////////////////////////////////////////////////////////////////////////////////
//ɾ������///////////////////////////////////////////////////////////////
int del_rule(char* buf, int buflen)
{
	unsigned int * num = (unsigned int*)buf;
	struct RuleNode* myNode = g_rule_head;
	struct RuleNode* myNode2 = NULL;
	int i = 0;
	//��μ��
	if( (buf==NULL) || (buflen<sizeof(unsigned int)) )
	{ printf("parametet error.\n"); return -1; }
	if( (*num<1) || (*num>g_ruleNum) )
	{
		printf("delete error.\n");
		return -1;
	}
//	if(g_rule_head==NULL)return 0;
	if(*num==1)//����һ����Ҫɾ���Ĳ���
	{ 
		myNode = g_rule_head;
		//write_lock(&g_rule_lock);
		g_rule_head = g_rule_head->next;
		if(myNode->next==NULL)
			g_rule_tail = g_rule_head;
		//write_unlock(&g_rule_lock);
		del_session_node(myNode);
		free(myNode);
		myNode = NULL;
	}
	else
	{
		myNode = g_rule_head;
		
		for(i=0;i<(*num-2);i++)
		{
			myNode = myNode->next;
		}
		//write_lock(&g_rule_lock);
		
		myNode2 = myNode->next;
		myNode->next = myNode2->next;
		if(myNode->next==NULL)
			g_rule_tail = myNode;
		//write_unlock(&g_rule_lock);
		del_session_node(myNode2);
		free(myNode2); 
		myNode2 = NULL;
	}
	
	g_ruleNum--;
	return 0;
}

//////////////////////////////////////////////////////////////////////////////////////
//������в���///////////////////////////////////////////////////////////////
int clear_rule()
{
	struct RuleNode* myNode = NULL;
	//write_lock(&g_rule_lock);
	
	while(g_rule_head!=NULL)
	{
		myNode = g_rule_head;
		g_rule_head = g_rule_head->next;
		free(myNode);
//		g_ruleNum--;
		myNode = NULL;
//		printk("cleared rule\n.");
	}
	g_rule_head = NULL;
	g_rule_tail = NULL;
	
	g_ruleNum = 0;
	//write_unlock(&g_rule_lock);
	
	return 0;
}






////////////////////////////////////////////////////////////////////////////////////////////
//asmlinkage int sys_rule( char* buf, int buflen, char* access )
int rule( char* buf, int buflen, char* access )
{
	int ret = -1;
	if( access==NULL )
	{
		printf("parameter error.\n");
		return -1000;
	}
	switch(access[0])
	{
		case 'a':	ret = add_rule(buf, buflen);	break;
		case 'd':	ret = del_rule(buf, buflen);	break;
		case 'c':	ret = clear_rule();		break;
	        case 'p':	ret = print_chain();            break;	
		default:	ret = -1001;
	}
	return ret;
}


////////////////////////////////////////////////////////////////////////////////////////////





