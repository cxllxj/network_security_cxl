
#ifndef _MAC_CHAIN_
#define _MAC_CHAIN_

struct enable_addr* g_mac_head = NULL;
//struct enable_addr* g_mac_tail = NULL;


///////////////////////////////////////////////////////////////////////////
struct enable_addr
{
        unsigned char mac_addr[6];
        struct enable_addr *next;
};
///////////////////////////////////////////////////////////////////////////
rwlock_t g_auth_lock = RW_LOCK_UNLOCKED;
int add_mac(char* buf, int buflen)
{
	struct enable_addr* newMac = NULL;
	//��μ��
	if( (buf==NULL) || (buflen<6) )
	{
		printk("k: parameter error.\n");
		return -1001;
	}
	//�����ڴ�
	newMac = kmalloc( sizeof(struct enable_addr), GFP_KERNEL );
	if (newMac == NULL)
	{
		printk("k: can not allocate memory.\n");
		return -1002;
	}
	//��������
	if (   copy_from_user( (char*)(newMac->mac_addr), buf, 6 )   )
	{
		kfree(newMac);
		newMac = NULL;
		return -1003;
	}
	//���ӵ���ͷ
	write_lock(&g_auth_lock);
	newMac->next = g_mac_head;
	g_mac_head   = newMac;
	write_unlock(&g_auth_lock);
	return 0;
}
int del_mac(char* buf, int buflen)
{

	struct enable_addr temp ;
	struct enable_addr* a = NULL;
	struct enable_addr* b = NULL;
	//��μ��
	if( (buf==NULL) || (buflen<6) )
	{
		printk("k: parameter error.\n");
		return -1001;
	}
	
	if( g_mac_head==NULL )return 0;
	
	//��������
	if (   copy_from_user( (char*)(temp.mac_addr), buf, 6 )   )
	{
		return -1004;
	}
	
	//ɾ��������
	//��һ��Ԫ��Ϊ��Ҫɾ�������ݵ����
	while(  !memcmp( g_mac_head->mac_addr,temp.mac_addr,6) )
	{
		a = g_mac_head;
		write_lock(&g_auth_lock);
		g_mac_head = g_mac_head->next;
		write_unlock(&g_auth_lock);
		kfree(a);
		a = NULL;
		if( g_mac_head==NULL )
			return 0;
	}
	
	//�������
	a = g_mac_head->next;
	b = g_mac_head;
	write_lock(&g_auth_lock);
	while(a!=NULL)
	{
		if( !memcmp( a->mac_addr, temp.mac_addr, 6 ) )
		{
			b->next = a->next;
			kfree(a);
			a = NULL;
			a = b;
		}
		b = a;
		a = a->next;
	}
	write_unlock(&g_auth_lock);
	return 0;
}

int clear_mac()
{
	struct enable_addr* temp = NULL;
	write_lock(&g_auth_lock);
	while( g_mac_head )
	{
		temp = g_mac_head;
		g_mac_head = g_mac_head->next;
		kfree(temp);
		temp = NULL;
	}
	g_mac_head = NULL;
	write_unlock(&g_auth_lock);
	
	return 0;
}



/////////////////////////////////////////////////////////////////////////////////
asmlinkage int sys_mac( char* buf, int buflen, char* access)
{
	int ret = -1;
	if( access==NULL )
	{
		printk("k: parameter error.\n");
		return -1000;
	}
	
	switch(access[0])
	{
		case 'a':	ret = add_mac(buf, buflen);	break;
		case 'd':	ret = del_mac(buf, buflen);	break;
		case 'c':	ret = clear_mac();			break;
		
		default:	ret = -1001;
	}
	return ret;
}



#endif
