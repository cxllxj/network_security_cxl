#include <stdio.h>
#include <stdlib.h>

//������Ϣ�ṹ
struct PolicyInfo
{
        unsigned char  M_saddr[6];
        unsigned char  M_daddr[6];
        int   IP_saddr;
        int   IP_daddr;
        int   D_Port;
        int   BannedFlag;
        u_int src_ip_map;
        u_int dst_ip_map;
};
//_syscall3(int,rule,char*,buf,int,buflen,char*,access)
rule(int rule,char* buf,int buflen,char* access);
int main()
{
	struct PolicyInfo *add_policy= malloc( sizeof(struct PolicyInfo));
	add_policy->M_saddr="123456781122";
	add_policy->M_daddr="876543211122";
	add_policy->IP_saddr=16777226;
	add_policy->IP_daddr=16776886;
	add_policy->D_Port=1024;
	add_policy->BannedFlag=1;
	add_policy->src_ip_map=96777226;
	add_policy->dst_ip_map=96776886;
	buflen=sizeof(struct PolicyInfo);
	buf=(char *)add_policy;
	
	rule(buf,buflen,"a");
	rule(buf,buflen,"p");
	
	add_policy->M_saddr="123456781123";
	add_policy->M_daddr="876543211123";
	add_policy->IP_saddr=16777223;
	add_policy->IP_daddr=16776883;
	add_policy->D_Port=1023;
	add_policy->BannedFlag=1;
	add_policy->src_ip_map=96777223;
	add_policy->dst_ip_map=96776883;
	buflen=sizeof(struct PolicyInfo);
	buf=(char *)add_policy;
	
	rule(buf,buflen,"a");
	rule(buf,buflen,"p");
	
	buf[0]=1;
	rule(buf,buflen,"d");
	
	
}