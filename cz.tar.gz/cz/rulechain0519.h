///////////////////////////////////////////////////////////////////////////////////////
//�ӿڶ��壺
//int add_rule(char* buf, int buflen)
//int del_rule(char* buf, int buflen)
//int clear_rule()
//
//
//
//
//
//
///////////////////////////////////////////////////////////////////////////////////////
#ifndef RULE_CHAIN_H
#define RULE_CHAIN_H

#define MAX_RULE_NUM 40  //����������
struct RuleNode* g_rule_head = NULL;
struct RuleNode* g_rule_tail = NULL;

#include <linux/locks.h>
unsigned int g_ruleNum = 0;
rwlock_t g_rule_lock = RW_LOCK_UNLOCKED;


//������Ϣ�ṹ
struct PolicyInfo
{
        unsigned char  M_saddr[6];
        unsigned char  M_daddr[6];
        int   IP_saddr;
        int   IP_daddr;
        int   D_Port;
        int   BannedFlag;
        u_int src_ip_map;
        u_int dst_ip_map;
};
//������Ϣ�����ڵ�
struct RuleNode
{
	struct PolicyInfo data;
	struct RuleNode * next;
};



//////////////////////////////////////////////////////////////////////////////////////
//���Ӳ���///////////////////////////////////////////////////////////////
int add_rule(char* buf, int buflen)
{
	struct RuleNode* newNode = NULL;
	//��μ��
	if( (buf==NULL) || (buflen!=sizeof(struct PolicyInfo)) )
	{
		printk("parameter error.\n");
		return -1;
	}
	if(g_ruleNum>MAX_RULE_NUM)
	{
		printk("too many rules,can't add rule.\n");
		return -1;
	}
	//�����ڴ�
	newNode = kmalloc( sizeof(struct RuleNode), GFP_KERNEL );
	if (newNode == NULL)
	{
		printk("can not allocate memory.\n");
		return -2;
	}
	if (   copy_from_user( (char*)(&(newNode->data)), buf, sizeof(struct PolicyInfo) )   )
	{
		kfree(newNode);
		newNode = NULL;
		return -3;
	}
	
	
/*	for(i=0;i<6;i++)
	{
		printk("newNode->data.M_saddr[i] = %c\n",newNode->data.M_saddr[i]);
	}
	for(i=0;i<6;i++)
	{
		printk("newNode->data.M_daddr[i] = %c\n",newNode->data.M_daddr[i]);
	}
	printk("newNode->data.IP_saddr   = %d\n",newNode->data.IP_saddr);
	printk("newNode->data.IP_daddr   = %d\n",newNode->data.IP_daddr);
	printk("newNode->data.D_Port     = %d\n",newNode->data.D_Port);
	printk("newNode->data.BannedFlag = %d\n",newNode->data.BannedFlag);
*/	
	
	//����Ԫ�ص���β
	if( g_rule_head == NULL )
	{
		newNode->next = NULL;
		write_lock(&g_rule_lock);
		g_rule_head = g_rule_tail = newNode;
		write_unlock(&g_rule_lock);
	}
	else {
			write_lock(&g_rule_lock);
			g_rule_tail->next = newNode;
			newNode->next = NULL;
			g_rule_tail = newNode;
			write_unlock(&g_rule_lock);
		 }
	
	g_ruleNum++;
		
	return 0;
}

//////////////////////////////////////////////////////////////////////////////////////
//ɾ������///////////////////////////////////////////////////////////////
int del_rule(char* buf, int buflen)
{
	unsigned int * num = (unsigned int*)buf;
	struct RuleNode* myNode = g_rule_head;
	struct RuleNode* myNode2 = NULL;
	int i = 0;
	//��μ��
	if( (buf==NULL) || (buflen<sizeof(unsigned int)) )
	{ printk("parametet error.\n"); return -1; }
	if( (*num<1) || (*num>g_ruleNum) )
	{
		printk("delete error.\n");
		return -1;
	}
//	if(g_rule_head==NULL)return 0;
	if(*num==1)//����һ����Ҫɾ���Ĳ���
	{ 
		myNode = g_rule_head;
		write_lock(&g_rule_lock);
		g_rule_head = g_rule_head->next;
		if(myNode->next==NULL)
			g_rule_tail = g_rule_head;
		write_unlock(&g_rule_lock);
		kfree(myNode);
		myNode = NULL;
	}
	else
	{
		myNode = g_rule_head;
		
		for(i=0;i<(*num-2);i++)
		{
			myNode = myNode->next;
		}
		write_lock(&g_rule_lock);
		
		myNode2 = myNode->next;
		myNode->next = myNode2->next;
		if(myNode->next==NULL)
			g_rule_tail = myNode;
		write_unlock(&g_rule_lock);
		kfree(myNode2); 
		myNode2 = NULL;
	}
	
	g_ruleNum--;
	return 0;
}

//////////////////////////////////////////////////////////////////////////////////////
//������в���///////////////////////////////////////////////////////////////
int clear_rule()
{
	struct RuleNode* myNode = NULL;
	write_lock(&g_rule_lock);
	
	while(g_rule_head!=NULL)
	{
		myNode = g_rule_head;
		g_rule_head = g_rule_head->next;
		kfree(myNode);
//		g_ruleNum--;
		myNode = NULL;
//		printk("cleared rule\n.");
	}
	g_rule_head = NULL;
	g_rule_tail = NULL;
	
	g_ruleNum = 0;
	write_unlock(&g_rule_lock);
	
	return 0;
}






////////////////////////////////////////////////////////////////////////////////////////////
asmlinkage int sys_rule( char* buf, int buflen, char* access )
{
	int ret = -1;
	if( access==NULL )
	{
		printk("parameter error.\n");
		return -1000;
	}
	switch(access[0])
	{
		case 'a':	ret = add_rule(buf, buflen);	break;
		case 'd':	ret = del_rule(buf, buflen);	break;
		case 'c':	ret = clear_rule();				break;
		
		default:	ret = -1001;
	}
	return ret;
}


////////////////////////////////////////////////////////////////////////////////////////////




#endif

