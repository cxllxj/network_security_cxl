/**********************************/
/* it worked as client under linux platform */
/* written by mlsx 1998-2-7                     */
/************************************/
#include <sys/timeb.h>
#include <stdio.h>

#if defined(WIN32) || defined(__WIN32__)
#include <windows.h>
#pragma comment (lib,"WS2_32.lib")

#else
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

typedef int SOCKET;
#endif

#define TCPPORT 2500
#define UDPPORT 2500
#define BUFFER_LENGTH 1024

int sequence;

SOCKET create_skt(int iptype,unsigned long ipAddr)
{
	SOCKET sd;

	struct sockaddr_in localAddr,servAddr;
	int status;
	int ret;

#if defined(WIN32) || defined(__WIN32__)
	WSADATA wsd;


	if((status=WSAStartup(MAKEWORD(2,2),&wsd))!=0)
	{
		perror("wsastartup() failed:");
		return 0;
	}
#endif //WIN32
	/* create socket */
	if((sd=socket(AF_INET,iptype,0))< 0)
	{
	  perror("socket failed :");
	  return 0;
	}

	/* bind any port number */
	memset(&localAddr,0x00,sizeof(localAddr));
	localAddr.sin_family=AF_INET;
	localAddr.sin_port=htons(0);
	localAddr.sin_addr.s_addr=htons(INADDR_ANY);

	ret = bind(sd, (struct sockaddr *) &localAddr, sizeof(localAddr));
	if(ret<0) {
//		printf("%s: cannot bind port TCP %u\n",inet_ntoa(localAddr.sin_addr.s_addr),TCPPORT);
		printf(": cannot bind port TCP %u\n",TCPPORT);
//		perror("error ");
		return 0;
	}

	/* connect to server */
	memset(&servAddr,0x00,sizeof(servAddr));
	servAddr.sin_family=AF_INET;
	servAddr.sin_port=htons(TCPPORT);
	servAddr.sin_addr.s_addr=ipAddr;

	ret = connect(sd, (struct sockaddr *) &servAddr, sizeof(servAddr));
	if(ret<0) {
		printf("\nCan't connect with %s(Port:%d) !",inet_ntoa(*((struct in_addr*)&ipAddr)),TCPPORT);
		return 0;
	}
	printf("connect ret=%d\n",ret);

	sequence=0;
	return sd;
}


int send_data(SOCKET sclient,unsigned int sendsize,char context)
{
	int i,k;
	int total_length=0;
	char data[BUFFER_LENGTH+100];
	unsigned int	totalSize=0,lowsize=0;
	char text[]="012345678_abcdefghi_gklmnopqr_stuvwxyz%_";
//	memset(data,context,BUFFER_LENGTH);

	while(1){//sendsize>totalSize){
//		memcpy(data,&sequence,sizeof(int));
	//	for(k=0;k<37;k++) memcpy(data+4+k*40,text,40);
		memset(data,context+(sequence%26),BUFFER_LENGTH);
		data[BUFFER_LENGTH-2]=0x0d;	
		data[BUFFER_LENGTH-1]=0x0A;
	//	usleep(1);
		i = send(sclient,data,BUFFER_LENGTH,0);
		if(i<0){
			printf("send data error!error=%d,complete %dB data\n",i,totalSize);

			return totalSize;
		}
		if(i==BUFFER_LENGTH) sequence++;
	//int errno;
		printf(",%d",totalSize);//*((int*)data) );
		totalSize += i;
	}

	return totalSize;
		
}

struct test_content{
	unsigned int  totalsize;
	char	testchar;
};


int main(int argc,char *argv[])
{
	unsigned long SrvAddr;
	unsigned int datasize,iptype;
	SOCKET	sd;
	struct test_content  mytest;
	struct timeb tp_begin,tp_end;
	int		ret,total,speed_sec;
	unsigned short desport=0;


	if(argc<4)
	{
		printf("usage:\n");
  
		printf("client_dos  TCP(UDP) xxx.xxx.xxx.xxx(server IP) bufsize\n");
		exit(1);
	}
	SrvAddr = inet_addr(argv[2]);
	datasize = atoi(argv[3]);

	if(strcmp(argv[1],"TCP")==0)
		iptype = SOCK_STREAM;
	else if(strcmp(argv[1],"UDP")==0)
		iptype = SOCK_DGRAM;
	else
		printf("Please input UDP or TCP!\n");

		//create socket
		sd = create_skt( iptype,SrvAddr);
		if(sd==0){
			//fprintf("Can't Socket error!\n");
//			return 0;
		}

	if(desport > TCPPORT+10) return 0;

	//send total size to server
	mytest.totalsize = htonl(datasize);
	mytest.testchar ='b';
	ret = send(sd,(char*)&mytest,sizeof(mytest),0);
	if(ret<0){
		printf("send data error!error=%d",ret);
		return 0;
	}
	printf("send test: %d, size=%d,ret=%d\n",htonl(mytest.totalsize),sizeof(mytest),ret);
	//start time
	ftime(&tp_begin);

	//testing
	total = send_data(sd,datasize*1000,'a');

	//end time
	ftime(&tp_end);

	speed_sec=(tp_end.time-tp_begin.time)*1000+(tp_end.millitm-tp_begin.millitm);
	speed_sec = (speed_sec>0)?speed_sec:1;

	printf("===========%s Testing===========\n",argv[2]);
	printf("Transfer %dkB data, speed %d msec \n",total/1000,speed_sec);
	printf("The transfer rate is %d K bit/sec.\n",total/speed_sec*8);

	return 0;

}
