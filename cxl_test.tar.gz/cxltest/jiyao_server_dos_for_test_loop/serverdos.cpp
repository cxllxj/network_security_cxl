/**********************************/
/* it worked as server under windows platform */
/* written by mlsx 1998-2-7                     */
/************************************/
#include <sys/timeb.h>
#include <stdio.h>

#if defined(WIN32) || defined(__WIN32__)
#include <windows.h>
#pragma comment (lib,"WS2_32.lib")

#else
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

typedef int SOCKET;

#endif	//WIN32

int seq;

#define TCPPORT 2500
#define UDPPORT 2500
//#define HOST_IP_ADDR "127.0.0.1"
#define BUFFER_LENGTH 16384

#define MAX_UDP_FRAME 1460*2
struct test_content{
	unsigned int  totalsize;
	char	testchar;
};

struct timeb g_tp_begin;

int xmit_rate(unsigned int rx_byte)
{
	
	struct timeb	tp_end;
	int		spend_sec=0;;
	int		speed=0;

	ftime(&tp_end); 
	spend_sec = (tp_end.time-g_tp_begin.time)*1000
			   +(tp_end.millitm-g_tp_begin.millitm);

	spend_sec = (spend_sec>0)?spend_sec:1;

	//caculate the transmission speed x K bit/Sec.
	speed = rx_byte/spend_sec*8;

	printf("\n   =======Testing Result========compliled on %s \n",__DATE__);
	printf("   Transfer %dK Byte Data, and spend %d millisecond.\n",rx_byte/1000,spend_sec);
	printf("   The transfer rate is %d K bit/sec.\n",speed);

	return speed;
}

SOCKET create_skt(int iptype)
{
	SOCKET s;
//	struct sockaddr_in client;
	struct sockaddr_in servAddr;
//	int namelen,pklen;
	int status;
	int ret;

#if defined(WIN32) || defined(__WIN32__)
	WSADATA wsd;


	if((status=WSAStartup(MAKEWORD(2,2),&wsd))!=0)
	{
		perror("wsastartup() failed:");
		return 0;
	}
#endif //WIN32
	/* create socket */
	if((s=socket(AF_INET,iptype,0))< 0)
	{
	  perror("socket failed :");
	  return 0;
	}

	/* bind server port */
	memset(&servAddr,0x00,sizeof(servAddr));
	servAddr.sin_family=AF_INET;
	servAddr.sin_port=htons(TCPPORT);
	servAddr.sin_addr.s_addr=htons(INADDR_ANY);

	ret = bind(s,(struct sockaddr *)&servAddr,sizeof(servAddr) );
	if(ret<0)
	{
	  perror("bind() failed:");
	  return 0;
	}

	printf("Socket has been created!socket=%d, PORT:%d\n",s,htons(servAddr.sin_port));

	if(iptype==SOCK_DGRAM){
		//UDP
		return s;
	}

	//TCP protocol
	if(listen(s,4)!=0)
	{
		perror("listen()failed :");
		return 0;
	}
	

	return s;
}

int tcp_main(int param,SOCKET s)
{
	char buf[BUFFER_LENGTH];
	SOCKET ns;
	struct sockaddr_in client;

	int namelen,pklen;
	int ret;
	int bufsize,remainSize;
	struct test_content  test_size;
int i;char ch='a';
	unsigned long total=0;
FILE *fp=NULL;

//	while(1)
	{
		namelen=sizeof(client);
		if((ns=accept(s,(struct sockaddr*)&client,&namelen))==-1)
		{
			perror("accept()failed:");
			return (-1);
		}
		printf("accept successful!\n");

		//receice parameter of test
		ret = recv(ns,(char*)&test_size,sizeof(test_size),0);

		if(ret < (int)sizeof(test_size) ){
			printf("receice TCP info Data Error!ret=%d\n",ret);
			return 0;
		}
		else
			printf("receive test: %d,ret=%d,size=%d",htonl(test_size.totalsize),ret,sizeof(test_size));

//		printf("recv size=%d,ret=%d\n",test_size.totalsize,ret);
		bufsize = htonl(test_size.totalsize)*1000 ;
		printf("We'll receive %d Byte TCP Data from %s\n",bufsize,inet_ntoa(client.sin_addr));
		remainSize=bufsize;
		//record begin time
		ftime(&g_tp_begin);
//fp=fopen("recv.txt","w");
//fclose(fp);
//		while(1){//total<bufsize){ 
		while(total<bufsize){	
			if(remainSize>BUFFER_LENGTH)
				ret =recv(ns,buf,BUFFER_LENGTH,0);
			else
				ret =recv(ns,buf,remainSize,0);


			if (ret == SOCKET_ERROR)
			{
				printf("recvfrom() failed; \n");
				break;
			}
			else if (ret == 0)
				break;

	/*		for(;i<1000 && i<ret;i++){
				if(buf[i]!=ch  ){
					printf("Received Data is error!tatol=%d,i=%d\n",total,i);
					printf("Recive Data: %s\n",
						break;}
			}*/
/*			fp=fopen("recv.txt","a");
			fwrite(buf,ret,1,fp);
			fclose(fp);*/
			remainSize=remainSize-ret;
			total+=ret;

			printf("%d ",total);
//			if( total/(bufsize/100) % 5 == 0)
//				printf("Recv %%%d Data  (%dB)!\n",total*100/(bufsize/1),total);
		}

	}


	xmit_rate(total);
	return 0;
}




int udp_main(int param,SOCKET s)
{
	char buf[MAX_UDP_FRAME+200];
	unsigned int total_length=0;
	struct sockaddr_in sender;
	int server_len=sizeof(struct sockaddr_in);
//	int pklen;
//	int status;
	int bufsize,remainSize;
	struct test_content  test_size;

	int seq=-1;

//	while(1)
	{
		
		int i;


		i = recvfrom(s,(char*)&test_size,sizeof(test_size),0,(struct sockaddr *)&sender,&server_len);
		if(i<sizeof(test_size) ){
			printf("receice info Data Error,ret=%d",i);
			return 0;
		}
		
		bufsize = htonl(test_size.totalsize)*1000 ;
		printf("We'll receive %dK Byte UDP Data from %s!\n",bufsize/1000,inet_ntoa(sender.sin_addr));

		remainSize=bufsize;	
		//record begin time
		ftime(&g_tp_begin);
		  
		while(total_length < bufsize) { 
			seq++;
			if(remainSize>MAX_UDP_FRAME)
				i=recvfrom(s,buf,MAX_UDP_FRAME,0,(struct sockaddr *)&sender,&server_len);
			else
				i=recvfrom(s,buf,remainSize,0,(struct sockaddr *)&sender,&server_len);
			if (i == SOCKET_ERROR)
			{
				printf("recvfrom() failed; \n");
				break;
			}
			else if (i == 0)
				break;
			
//			if(buf[0]!=test_size.testchar )
//				printf("Received Data(0x%x) is error!\n",buf[0]);
			remainSize=remainSize-i;
			total_length+=i;


//			if(seq!=*((int*)buf)) {
//				printf("Lost  UDP Datagrams(No.%d-No.%d)\n",seq,*((int*)buf)-1);
//				seq = *((int*)buf);
//			}			
//			printf("%d(%d)-",*((int*)buf),total_length );
			printf("%d ",total_length);
//			if( total_length/(bufsize/100) % 5 == 0)
//				printf("Recv %%%d Data  (%dB)!\n",total_length/(bufsize/100),total_length);

		}

	}
	xmit_rate(total_length);
//	printf("server ended successfully\n");
	return 0;
}


//int receive(SOCKET ns,char *buf,int bufsize);
//int tcp_main(int param);
//int udp_main(int param);
int main(int argc,char *argv[])
{
	SOCKET sd;
	if(argc<2)
	{
		printf("usage:\n");
  
		printf("server_dos  UDP(TCP) \n");
		exit(1);
	}
	int param;
//	param=atoi(argv[2]);
	
	printf("%s ",argv[1]);
	if(strcmp(argv[1],"TCP")==0){
		//TCP
		sd = create_skt(SOCK_STREAM);
		if(sd==0)
			return 0;
		tcp_main(param,sd);
	}else if(strcmp(argv[1],"UDP")==0){
		//UDP
		sd = create_skt(SOCK_DGRAM);
		if(sd==0)
			return 0;
		udp_main(param,sd);
	}else
		//error
		printf("Please input TCP or UDP!\n");

/*	ftime(&tp_end); 
	end_time=tp_end.time*1000+tp_end.millitm;
	time_used=end_time-begin_time;

	if(time_used==0)
		printf("Use time to complete data transfer< 1ms.\n");
	else
	{
		printf("Use %d msec to complete data transfer.\n",time_used);
		printf("The transfer rate is %d K bit/sec.\n",(bufsize*8)/time_used);
	}
*/
	closesocket(sd);
	return 0;

}

