/* netfilter hooks example
 * (C) 1999 by Salvatore Sanfilippo <antirez@invece.org>
 * This code comes under GPL version 2
 * see http://www.opensource.org/licenses/gpl-license.html
 * for more information.
 *
 * Compile with: gcc -O -c -Wall nfexample.c
 * (note that -O is needed)
 * Insert this module using `insmod nfexample'
 */

//#define __KERNEL__
//#define MODULE


#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/mm.h>
#include <asm/uaccess.h>
#include <linux/string.h>

#include <linux/socket.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/icmp.h>

#include <linux/netfilter.h>
#include <linux/netfilter_ipv4.h>

#include <linux/proc_fs.h>

#include <linux/interrupt.h>
#include <linux/spinlock.h>

//#define IP_integer 16820416     //refered to 192.168.0.1
//#define Port_network 53764      //refered to host format 1234(port)

#define PROC_BUFFER 4096
struct nf_hook_ops input_filter;
struct nf_hook_ops output_filter;
struct nf_hook_ops pre_routing_filter;
static rwlock_t last_lock = RW_LOCK_UNLOCKED;
static int counter_input_dropped = 0;
static int counter_input_processed = 0;
static int counter_output_dropped = 0;
static int counter_output_processed = 0;
static char *last_packet_data = NULL;
unsigned long ip_integer=16820416;         //refered to 192.168.0.1
unsigned short port_integer=53764;         //refered to host format 1234

/* input_handler is called when a packet hits specified hook point */
unsigned int input_handler(	unsigned int hooknum,
				struct sk_buff **skb,
				const struct net_device *in,
				const struct net_device *out)
{
	struct iphdr *ip;
	struct tcphdr *tcp;
	struct ethhdr *eth_struct;
	int packet_size;

	/* inc processed counter */
	counter_input_processed++;

	
	ip  = (*skb)->nh.iph;
	tcp = (struct tcphdr*)((__u32 *)ip+ip->ihl);
	/* TCP filtering */
	if (ip->protocol != 6)
		goto drop;

	if(ip->saddr!=ip_integer) 
		goto drop;
	if(ip->daddr!=ip_integer)
		goto drop;

//	tcp = (struct tcphdr*)((__u32 *)ip+ip->ihl);


	if((tcp->source !=port_integer) && (tcp->dest!=port_integer))
	  	goto drop;
/*	
	unsigned char a[14];
	int i;
	eth_struct=(*skb)->mac.ethernet;
        memcpy(a,eth_struct,14);
	printk("eth_struct in input_handler is");
	for(i=0;i<14;i++)
		printk("%02x",a[i]);
	printk("\n");
*/	
accepted:
        printk("input handler accept!\n");	
	return NF_ACCEPT;

drop:
/*	counter_input_dropped++;
	printk("counter_input_dropped=%d.\n",counter_input_dropped);
	printk("counter_input_processed=%d.\n",counter_input_processed);
	printk("tcp->dest=%d.\n",tcp->dest);
	printk("tcp->source=%d.\n",tcp->source);
	printk("ip->saddr=%d.\n",ip->saddr);
	printk("ip->daddr=%d.\n",ip->daddr);
*/
	return NF_DROP;
}


/* output_handler is called when a packet hits specified hook point */
unsigned int output_handler(	unsigned int hooknum,
				struct sk_buff **skb,
				const struct net_device *in,
				const struct net_device *out)
{
	struct iphdr *ip;
	struct tcphdr *tcp;
	struct ethhdr *eth_struct;

	/* inc processed counter */
	counter_output_processed++;

	/* IP filtering */
	ip  = (*skb)->nh.iph;
	/* TCP filtering */
	if (ip->protocol != 6)
		goto drop;
/*	
	unsigned char a[14];
	int i;
	eth_struct=(*skb)->mac.ethernet;
	memcpy(a,eth_struct,14);
	printk("eth_struct in output_handler is");
	for(i=0;i<14;i++)
		printk("%02x",a[i]);
	printk("\n");
*/			
accepted:
	printk("output handler accept!\n");
	return NF_ACCEPT;

drop:
/*
	counter_output_dropped++;
	printk("Output droped %d times!\n",counter_output_dropped);
*/
	return NF_DROP;
}


unsigned int pre_routing_handler(	unsigned int hooknum,
				struct sk_buff **skb,
				const struct net_device *in,
				const struct net_device *out)
{
	struct ethhdr *eth_struct;
	unsigned char a[14];
	int i;
	
	eth_struct=(*skb)->mac.ethernet;
        memcpy(a,eth_struct,14);
	
	if(a[0]=(unsigned char)0xff)
		goto accepted;  //do not display broadcast data packet
	printk("eth_struct in pre_routing is");
	for(i=0;i<14;i++)
		printk("%02x",a[i]);
	printk("\n");
accepted:	
	return NF_ACCEPT;
	
}

int init_module(void)
{
	int result;

	/* input hook */
	input_filter.list.next = NULL;
	input_filter.list.prev = NULL;
	input_filter.hook = input_handler;
	/*chen xiaolong delete
	input_filter.flush = NULL; * still unused *
	chen xiaolong delete*/
	input_filter.pf = PF_INET; /* IPv4 */
	input_filter.hooknum = NF_IP_LOCAL_IN;

	/* output hook */
	output_filter.list.next = NULL;
	output_filter.list.prev = NULL;
	output_filter.hook = output_handler;
	/*chen xiaolong delete
	output_filter.flush = NULL; * still unused *
	chen xiaolong delete*/
	output_filter.pf = PF_INET; /* IPv4 */
	output_filter.hooknum = NF_IP_LOCAL_OUT;
	
	pre_routing_filter.hook=pre_routing_handler;
	pre_routing_filter.pf=PF_INET;
	pre_routing_filter.hooknum=NF_IP_PRE_ROUTING;
	pre_routing_filter.priority=NF_IP_PRI_FIRST;


	/* hooks registration */
	result = nf_register_hook(&input_filter);
	if (result) goto hook_failed;

	result = nf_register_hook(&output_filter);
	if (result) goto hook_failed;

	result=nf_register_hook(&pre_routing_filter);
	if(result) goto hook_failed;

	/* OK */
	printk(KERN_INFO "demo netfilter module loaded\n");
	return 0;


hook_failed:
	printk(KERN_INFO "nfdemo: error registering hook (%d)", result);
	return result; /* error registering hooks */
}

void cleanup_module(void)
{
	/* unregister hooks */
	nf_unregister_hook(&input_filter);
	nf_unregister_hook(&output_filter);
	nf_unregister_hook(&pre_routing_filter);

	printk(KERN_INFO "demo netfilter module removed\n");
}




