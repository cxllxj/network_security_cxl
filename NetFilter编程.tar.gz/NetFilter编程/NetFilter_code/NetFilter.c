/* netfilter hooks example
 * (C) 1999 by Salvatore Sanfilippo <antirez@invece.org>
 * This code comes under GPL version 2
 * see http://www.opensource.org/licenses/gpl-license.html
 * for more information.
 *
 * Compile with: gcc -O -c -Wall nfexample.c
 * (note that -O is needed)
 * Insert this module using `insmod nfexample'
 */

//#define __KERNEL__
//#define MODULE


#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/mm.h>
#include <asm/uaccess.h>
#include <linux/string.h>

#include <linux/socket.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/icmp.h>

#include <linux/netfilter.h>
#include <linux/netfilter_ipv4.h>

#include <linux/proc_fs.h>

#include <linux/interrupt.h>
#include <linux/spinlock.h>



#define PROC_BUFFER 4096
struct nf_hook_ops input_filter;
struct nf_hook_ops output_filter;
static rwlock_t last_lock = RW_LOCK_UNLOCKED;
static int counter_input_dropped = 0;
static int counter_input_processed = 0;
static int counter_output_dropped = 0;
static int counter_output_processed = 0;
static char *last_packet_data = NULL;

/* input_handler is called when a packet hits specified hook point */
unsigned int input_handler(	unsigned int hooknum,
				struct sk_buff **skb,
				const struct net_device *in,
				const struct net_device *out)
{
	struct iphdr *ip;
	struct tcphdr *tcp;
	int packet_size;

	/* inc processed counter */
	counter_input_processed++;

	/* IP filtering */
	/* as you can see the function receives a pointer to the
	 * struct sk_buff pointer, so it's possible to replace the
	 * sk_buff with another one. This can be used to rebuild
	 * from scratch the packet (the example don't use this) */
	ip  = (*skb)->nh.iph;

	/* save the packet -- for /proc/nfdemo/last */
#if 0
	write_lock_bh(&last_lock);
	if (last_packet_data != NULL)
		kfree(last_packet_data);

	packet_size = ntohs(ip->tot_len);

	last_packet_data = kmalloc(packet_size, GFP_KERNEL);
	if (last_packet_data)
		memcpy(last_packet_data, ip, packet_size);
	write_unlock_bh(&last_lock);
#endif
	/* drop IP packets with options */
	if (ip->ihl != 5)
		goto drop;

	/* TCP filtering */
	if (ip->protocol != 6)
		goto accepted;

	tcp = (struct tcphdr*)((__u32 *)ip+ip->ihl);

	/* TCP flags sanity check */

	/* drops Xmas || Ymax */
        /* chen xiaolong delete  
	if (tcp->res2 != 0)
		goto drop;
	chen xiaolong delete*/	

	/* drops SYN without ACK but with others flags set */
	if ((tcp->syn && !tcp->ack)
		&& (tcp->fin || tcp->rst || tcp->psh || tcp->urg))
		goto drop;

	/* drops SYN/ACK with RST and/or FIN set */
	if ((tcp->syn && tcp->ack) && (tcp->fin || tcp->rst))
		goto drop;

	/* drops TCP packets with no-sense flags (or without flags set) */
	if (!tcp->fin && !tcp->syn && !tcp->rst && !tcp->ack)
		goto drop;

accepted:
	return NF_ACCEPT;

drop:
	counter_input_dropped++;
	return NF_DROP;
}


/* output_handler is called when a packet hits specified hook point */
unsigned int output_handler(	unsigned int hooknum,
				struct sk_buff **skb,
				const struct net_device *in,
				const struct net_device *out)
{
	struct iphdr *ip;
	struct tcphdr *tcp;
	struct icmphdr *icmp;

	/* inc processed counter */
	counter_output_processed++;

	/* IP filtering */
	ip  = (*skb)->nh.iph;

	/* TCP filtering */
	if (ip->protocol != 6)
		goto icmp_init;

	tcp = (struct tcphdr*)((__u32 *)ip+ip->ihl);

icmp_init:
	/* ICMP filtering */
	if (ip->protocol != 1)
		goto accepted;

	icmp = (struct icmphdr*)((__u32 *)ip+ip->ihl);

	if (icmp->type == 0) /* icmp echo request */
		goto drop;

accepted:
	return NF_ACCEPT;

drop:
	counter_output_dropped++;
	printk("Output droped %d times!\n",counter_output_dropped);
	return NF_DROP;
}

int init_module(void)
{
	int result;

	/* input hook */
	input_filter.list.next = NULL;
	input_filter.list.prev = NULL;
	input_filter.hook = input_handler;
	/*chen xiaolong delete
	input_filter.flush = NULL; * still unused *
	chen xiaolong delete*/
	input_filter.pf = PF_INET; /* IPv4 */
	input_filter.hooknum = NF_IP_LOCAL_IN;

	/* output hook */
	output_filter.list.next = NULL;
	output_filter.list.prev = NULL;
	output_filter.hook = output_handler;
	/*chen xiaolong delete
	output_filter.flush = NULL; * still unused *
	chen xiaolong delete*/
	output_filter.pf = PF_INET; /* IPv4 */
	output_filter.hooknum = NF_IP_LOCAL_OUT;





	/* hooks registration */
	result = nf_register_hook(&input_filter);
	if (result) goto hook_failed;

	result = nf_register_hook(&output_filter);
	if (result) goto hook_failed;

	/* OK */
	printk(KERN_INFO "demo netfilter module loaded\n");
	return 0;


hook_failed:
	printk(KERN_INFO "nfdemo: error registering hook (%d)", result);
	return result; /* error registering hooks */
}

void cleanup_module(void)
{
	/* unregister hooks */
	nf_unregister_hook(&input_filter);
	nf_unregister_hook(&output_filter);


	printk(KERN_INFO "demo netfilter module removed\n");
}




