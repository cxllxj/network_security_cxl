/* driver/char/dpram.c 
 * 
 * This file is for dual port ram in hhcn's mpc8245_dual_port_ram board.
 * Pls create some device file in diretory /dev whose major is 208.
 * 
 * Any problem pls contact SunaresChen@hotmail.com or support@hhcn.com
 * v1.3 driver
 * ֻ�������ں�̬��������ʱ�ȶ���
 * �Է����ж�,�ٶȽϸ�
 */

#include <linux/fs.h>
#include <linux/iobuf.h>
#include <linux/major.h>
#include <linux/blkdev.h>
#include <linux/capability.h>
#include <linux/smp_lock.h>
#include <asm/uaccess.h>
#include <asm/io.h>
#include <linux/vmalloc.h>
#include <linux/slab.h>
#include <linux/wait.h>
#include <linux/interrupt.h>
#include <linux/dpram.h>
#include <linux/delay.h>
#include <asm/errno.h>

#define DPRAM_DEBUG 1
unsigned long startt=0;
static int debug_on = 0;

#define dprintk if (debug_on>1) printk
#define jprintk if (debug_on) printk

#define DPRAM_MAJOR 208
#define MAX_RXSECTOR	250
#define MAX_TXSECTOR	100  
/* max dpram(include rx and tx) 16384
 * isr and icr 8 byte
 * ring_len 2040
 * ring_head 4 byte
 * (4+2040)*8 + 8 = 16360
 * the ring align 4 byte
 */
#define RINGNUM		4
#define RINGLEN		4092
				int sndtims=0;
				
//#define MARK_SIZE	4

struct cache_sector {
	unsigned char* head;
	unsigned char* tail;
	unsigned char* free;
	unsigned char* fill;
	unsigned short data_len; 
	unsigned short flag;
	struct cache_sector *next;
};

struct dpram_cache {
	struct cache_sector *free;
	struct cache_sector *fill;
	struct cache_sector *vfill;
};

struct dpram_recdata {
	void (*recv_func)(const unsigned char*, int,void *);
	unsigned char *buff;
	int	size;
	void 	*parameter;
	};
	
struct back_ramflag{
	__u8 	mode:1,		//0-user mode ; 1-kernel mode
		frag:1,	//1-���һƬ
		sequence:3,	//if frag==1, ����ʾ���һƬ�ĳ��ȣ����򣬱�ʾ�����Ƭ���ڶ��е�λ�ã��ǵڼ�Ƭ��
		queue:3;

};

struct dpram_device {
	/* dpram info */
	unsigned long dpram_phy_addr;
	unsigned char *dpram_vma_addr;
	unsigned char *dpram_rx_port;
	unsigned char *dpram_tx_port;
	unsigned volatile long *dpram_isr;
	unsigned volatile long *dpram_icr;
	unsigned long icr;
	unsigned long isr;
	unsigned long irq;
	unsigned long dpram_len;
	unsigned long dpram_rx_len;
	unsigned long dpram_tx_len;

	unsigned char rx_count;
	unsigned char tx_count;

	/* read and write control info */
	
	struct timer_list dpram_timer;
	unsigned char tx_flag;
	unsigned char rx_flag;

	struct dpram_cache* rx_cache;
	struct dpram_cache* rx2_cache; //UserMode
	struct dpram_cache* tx_cache;

	unsigned char rx_lock;
	unsigned char tx_lock;

	char	mode;
	
	unsigned short event;
	
	struct dpram_recdata  recvparmt;

};

#define HALF_MODE	1
#define DUP_MODE	2

#ifdef CONFIG_DPRAM_R
#define RX_SECTOR_LEN	4096//DPRAM_RX_LEN	
#define TX_SECTOR_LEN	8//DPRAM_TX_LEN
#else 
#define RX_SECTOR_LEN	8
#define TX_SECTOR_LEN	4096
#endif

//#define MAX_RXSECTOR	RXDATA_SECTOR
//#define MAX_TXSECTOR	TXDATA_SECTOR

#define DPRAM_READ	0x01
#define DPRAM_SEND	0x02
#define DPRAM_BUSY	0x04

#define CACHE_RD	0x01
#define CACHE_WR	0x02

#define HEAD_SIZE	4


#define EVENT_NULL	0
#define EVENT_SEND	1
#define EVENT_REV	2

#define RX_FULL		0x01
#define RX_NONFULL	0x02
#define TX_STOP		0x03
#define TX_START	0x04
#define TX_NORMAL	0x05
#define TX_TIMEOUT	0x06

unsigned char *recvleft = NULL;
static struct dpram_device dpram;

DECLARE_WAIT_QUEUE_HEAD(dpram_rx_wait);
DECLARE_WAIT_QUEUE_HEAD(dpram_tx_wait);


static void dpram_interrupt(int irq, void *dev_id, struct pt_regs * regs);
ssize_t	dpram_read(struct file *, char *, size_t, loff_t *);
ssize_t	dpram_write(struct file *, const char *, size_t, loff_t *);
int	dpram_open(struct inode *, struct file *);
int	dpram_release(struct inode *, struct file *);
int 	dpram_ioctl(struct inode *, struct file *, unsigned int, unsigned long);
static void dpram_rx_packet(struct dpram_device *dev);
static int dpram_tx_packet(struct dpram_device *dev, int flags);
static void dpram_tx_timeout(void);
static inline void do_interrupt_empty(unsigned long unused);

static inline void do_recv_bh3(unsigned long unused);//(struct dpram_recdata *recdata);
int dpram_kernel_write(const unsigned char *buff, size_t size, unsigned char ramflag);
static struct file_operations dpram_fops = {
	read:		dpram_read,
	write:		dpram_write,
	open:		dpram_open,
	release:	dpram_release,
	ioctl:		dpram_ioctl,
};

DECLARE_TASKLET(dpram_tasklet1,do_recv_bh3,0);

DECLARE_TASKLET(dpram_taskempty,do_interrupt_empty,0);
//#define ALIGN(x) (((x) + sizeof(unsigned long)-1) & -sizeof(unsigned long))

#define ALIGN(val,align)        (((val) + ((align) - 1)) & ~((align) - 1))

static struct cache_sector* sector_init(int len)
{
	struct cache_sector* sector;
	unsigned long align = 4;
	unsigned long addr;
	sector = (struct cache_sector*)kmalloc(sizeof(struct cache_sector),GFP_KERNEL);
	if (sector == NULL) {
		printk("alloc cache sector failed\n");
		return NULL;
	}
	addr = (unsigned long)kmalloc(len+align,GFP_KERNEL);

	
	addr = ALIGN(addr,align);
	if (addr % align)
		printk("head is not align\n");
	sector->head = (unsigned char*)addr;//(unsigned char*)(ALIGN(addr,align));//(((addr) + ((align) - 1)) & ~((align) - 1));
			//(unsigned char*)(ALIGN(addr,align));
	sector->tail = sector->head + len;
	sector->free = sector->head;
	sector->fill = sector->head;
	sector->data_len = 0;
	sector->flag = CACHE_WR;
	return sector;

}

static void cache_init(struct dpram_cache** cache, int len, int num)
{
	struct dpram_cache* tmp;
	struct cache_sector* head, *tail;	
	tmp = (struct dpram_cache*)kmalloc(sizeof(struct dpram_cache),GFP_KERNEL);
	if (tmp == NULL) {
		printk("alloc dpram cache failed\n");
		return;
	}
	head = sector_init(len);
	if (head == NULL) {
		kfree(tmp);
		return;
	}
	num--;
	tail = head;
	while(num--) {
		tail->next = sector_init(len);
		tail = tail->next;
	}
	tail->next = head;
	(*cache) = tmp;
	(*cache)->free = head;
	(*cache)->fill = head;
	(*cache)->vfill = (*cache)->fill;

	return;
}

static inline int free_rxcache_ready(struct dpram_cache* cache, int len)
{
	if (cache->free->flag & CACHE_WR)
		return 1;
	return 0;
}

static inline int cache_get_free_rxcache(struct dpram_cache* cache, unsigned char** buff, int len)
{
	(*buff) = cache->free->head;

	return ((len < RX_SECTOR_LEN) ? len : RX_SECTOR_LEN);
}

static inline void fill_rxcache(struct dpram_cache* cache, int len)
{
	struct cache_sector * free = cache->free;

	free->data_len = len;
	free->flag = CACHE_RD;
	cache->free = free->next;

	return;
}
static inline int cache_get_fill_rxcache(struct dpram_cache* cache, unsigned char** buff, int len)
{
	unsigned long flags;
	struct cache_sector * fill;

	save_and_cli(flags);

	fill = cache->fill;

	if (!(fill->flag & CACHE_RD)) {
		restore_flags(flags);
		return 0;
	}

	if (fill->data_len < len)
		len = fill->data_len;
	(*buff) = fill->fill;

	restore_flags(flags);

	return len;	

}
static inline int free_rxcache(struct dpram_cache* cache,int len)
{
	unsigned long flags;
	struct cache_sector *fill;

	save_and_cli(flags);

	fill = cache->fill;

	if (len > fill->data_len) {
		printk("free rxcache len > data_len\n");
		return -1;
	}

	if (len < fill->data_len) {
		fill->data_len -= len;
		fill->fill += len;
		restore_flags(flags);
		return 0;
	}

	fill->flag = CACHE_WR;
	fill->fill = fill->head;
	fill->data_len = 0;
	cache->fill = fill->next;

	restore_flags(flags);
	return 1;
}

static inline int cache_get_free_txcache(struct dpram_cache* cache, unsigned char** buff, int len)
{
	unsigned long flags;
	struct cache_sector *free;

	save_and_cli(flags);
	
	free = cache->free;

	if (!(free->flag & CACHE_WR)) {
		restore_flags(flags);
		return 0;
	}
	(*buff) = free->head;

	restore_flags(flags);

	return TX_SECTOR_LEN;

}
static inline int cache_get_vfill_txcache(struct dpram_cache* cache, unsigned char** buff, int len)
{
	struct cache_sector *vfill = cache->vfill;

	if (!(vfill->flag & CACHE_RD))
		return 0;
	(*buff) = vfill->head;

	return vfill->data_len;
}
static inline void vfree_txcache_restore(struct dpram_cache* cache)
{
	cache->vfill = cache->fill;
	return;
}
static inline void vfree_txcache(struct dpram_cache* cache)
{
	cache->vfill = cache->vfill->next;
	return;
}
static inline int free_txcache(struct dpram_cache* cache)
{
	struct cache_sector* fill = cache->fill;
	if (fill == cache->vfill)
		return 0;
	if (fill->next->next == cache->vfill)
		printk("fill next next be vfill, lost one packet\n");
	while (fill != cache->vfill) {
		fill->data_len = 0;
		fill->flag = CACHE_WR;
		fill = fill->next;
	}

	cache->fill = cache->vfill;
	return 1;
}
static inline void fill_txcache(struct dpram_cache* cache, int len)
{
	struct cache_sector * free;

	free = cache->free;
	free->data_len = len;
	free->flag = CACHE_RD;
	cache->free = free->next;

	return;
		
}
static inline void get_packet(unsigned char* buff, unsigned long* pkg_port, int data_len)
{
	memcpy((unsigned long*)(buff), pkg_port, data_len );
}
static inline void send_packet(unsigned char* buff, unsigned long* pkg_port, int len)
{
	memcpy(pkg_port, (unsigned long*)(buff), ALIGN(len,4) );
	
}

static int __init dpram_init(void)
{
	int ret;
	struct dpram_device *dev = &dpram;

	dprintk("dpram init\n");

	ret = register_chrdev(DPRAM_MAJOR, "dpram", &dpram_fops);
	if (ret < 0) {
		printk("Register dpram dev failed\n");
		return 0;
	}
	
	dev->dpram_phy_addr = DPRAM_PHY_ADDR;
	dev->dpram_len = DPRAM_LEN;
	dev->irq = DPRAM_IRQ;


	printk("Register dpram driver 1.3 successfully! --AresChen (www.ydan.com)\n");

	dev->dpram_vma_addr = ioremap(dev->dpram_phy_addr,dev->dpram_len);
	if (dev->dpram_vma_addr == NULL) {
		dprintk("Remap dpram space failed\n");
		return -1;
	}
	
	dev->dpram_isr = (unsigned long*)(dev->dpram_vma_addr + DPRAM_ISR);
	dev->dpram_icr = (unsigned long*)(dev->dpram_vma_addr + DPRAM_ICR);
	dev->dpram_rx_port = dev->dpram_vma_addr + DPRAM_R_PORT;
	dev->dpram_tx_port = dev->dpram_vma_addr + DPRAM_W_PORT;
	dev->dpram_rx_len = DPRAM_R_LEN;
	dev->dpram_tx_len = DPRAM_W_LEN;
	dev->rx_count = 0;
	dev->tx_count = 1;

	dev->event = EVENT_NULL;
	dev->isr = 0;
	dev->icr = 0;

	*(dev->dpram_isr) = 0;

	ret = *(dev->dpram_isr); //read isr register to clear interrupt !
	
	if (ret & 0x80000000)
		dev->mode = DUP_MODE;
	else
		dev->mode = HALF_MODE;

	init_timer(&(dev->dpram_timer));
	dev->dpram_timer.function = dpram_tx_timeout;
	dev->dpram_timer.data = 0;
	
	ret = request_irq(dev->irq,&dpram_interrupt,SA_SHIRQ,"dpram",dev);
	if (ret)
		return ret;

	cache_init(&(dev->rx_cache),RX_SECTOR_LEN,MAX_RXSECTOR);
	cache_init(&(dev->rx2_cache),RX_SECTOR_LEN,MAX_RXSECTOR);
	cache_init(&(dev->tx_cache),TX_SECTOR_LEN,MAX_TXSECTOR);
	dev->tx_flag = TX_STOP;
	dev->rx_flag = RX_NONFULL;

	//
	recvleft = (unsigned char*)kmalloc(1024,GFP_KERNEL);
	if(recvleft==NULL)
		return -1;
	memset(recvleft,0x00,1024);
	return 0;
}

__initcall(dpram_init);

/* 
 * Open/close code for raw IO.
 */

int dpram_open(struct inode *inode, struct file *filp)
{
	int minor;

	minor = MINOR(inode->i_rdev);

	if (minor != 0)
		return -1;
	return 0;
}
//__ioremap
int dpram_release(struct inode *inode, struct file *filp)
{
	int minor;
	
	minor = MINOR(inode->i_rdev);
	if (minor != 0)
		return 0;
	return 0;
}

static void dpram_interrupt(int irq, void *dev_id, struct pt_regs * regs)
{
	struct dpram_device *dev = dev_id;
	unsigned volatile long status;
	
	if (!dev) {
		printk("dpram_interrupt without device arg\n");
		return;
	}

	status = *(dev->dpram_isr);
	asm("nop");
	while(status != *(dev->dpram_isr)) {
		status = *(dev->dpram_isr);
		asm("nop");
	}

	dev->isr = status;


	dev->icr = 0;

	if (status & 0x80000000) {
		dev->mode = DUP_MODE;
	} else  {
		dev->mode = HALF_MODE;
#ifdef CONFIG_DPRAM_R
		dpram_rx_packet(dev);
#elif defined(CONFIG_DPRAM_L)
		if (free_txcache(dev->tx_cache)) {
			dev->tx_count++;
			dpram_tx_packet(dev, TX_NORMAL);
			wake_up_interruptible(&dpram_tx_wait);
		}
#endif
		if (dev->icr) 
			*(dev->dpram_icr) = dev->icr;

		return;
	}

	status &= 0x7fffffff;

	if (!(status & (DPRAM_BUSY | DPRAM_READ | DPRAM_SEND))) {
		dprintk("No interrupt happend,status %0x\n",status);
		sndtims++;
		return;
	}


	if (status == (DPRAM_READ | DPRAM_SEND))
		dprintk("read and send arrive\n");
		
	if (status & DPRAM_READ) {
		dpram_rx_packet(dev);
	}
/*#ifdef CONFIG_DPRAM_L
	if (status & DPRAM_SEND) {

		if (free_txcache(dev->tx_cache)) {
			dev->tx_count++;
		// transmit one packet successfully, remove it. and transmit next one.
			dpram_tx_packet(dev, TX_NORMAL);
			wake_up_interruptible(&dpram_tx_wait);
		}
	}
#elif defined(CONFIG_DPRAM_R)*/
	if (status & DPRAM_SEND) {

		if (free_txcache(dev->tx_cache)) {
			sndtims = 0;
			dev->tx_count++;
			
		/* transmit one packet successfully, remove it. and transmit next one.*/	
			if(!dpram_tx_packet(dev, TX_NORMAL) ){
				jprintk(" NoData!");
				dev->tx_flag = TX_STOP;
				del_timer(&(dev->dpram_timer));
			}
	
			wake_up_interruptible(&dpram_tx_wait);

		}
	}else{
//		sndtims++;

		dev->tx_flag = TX_START;
		dpram_tx_packet(dev, TX_NORMAL);

	}
//#endif

#ifdef CONFIG_DPRAM_R
	if (dev->icr){
		*(dev->dpram_icr) = dev->icr;
	}else
		tasklet_schedule(&dpram_taskempty);

#elif defined(CONFIG_DPRAM_L)

	dev->icr |= DPRAM_BUSY;
	*(dev->dpram_icr) = dev->icr;
#endif

	return;

}

static void dpram_rx_packet(struct dpram_device *dev)
{

	unsigned char* 	data_port;
	unsigned long 	packet_len;
	unsigned char 	packet_num;
	unsigned char* 	cache;
	unsigned char	ramflag=0;
	struct dpram_cache*	recv_cache=NULL;

#ifdef CONFIG_DPRAM_L
	data_port = dev->dpram_rx_port;
	packet_len = 8;
	packet_num = ((dev->isr >> 16) & 0xff);
	

#elif defined(CONFIG_DPRAM_R)
	unsigned long* head  ;
	
	data_port = dev->dpram_rx_port + HEAD_SIZE;
	head = (unsigned long*) dev->dpram_rx_port;
	packet_len = *head & 0xffff;
	packet_num = (*head  >> 16);
	
#endif	
	if (packet_num == dev->rx_count) {
		dprintk(" rcv dup packet %x, rx %x\n",packet_num,dev->rx_count);
		dev->icr |= DPRAM_SEND;
		printk("D");
		return;
	}
	

	if (packet_len > RX_SECTOR_LEN) {
		dprintk("Packet size erro, packet len %d bigger than sector\n",packet_len);
		return;
	}

	dprintk("Rx_Packet, len=%d, num=%d\n",packet_len,packet_num);
	
	ramflag = (dev->isr>>8)&0xff;
	
	if(ramflag){
		//kernel Mode
		recv_cache = dev->rx_cache;
	}else{
		//User Mode
		recv_cache = dev->rx2_cache;
	}
		
	if (!free_rxcache_ready(recv_cache, packet_len)) {
		
		if(!ramflag)//user mode
			wake_up_interruptible(&dpram_rx_wait);
			
//	tasklet_schedule(&dpram_tasklet1);
		dev->rx_flag = RX_FULL;
		printk("(RxFull)");
		return;
	}

	dev->rx_flag = RX_NONFULL;


	cache_get_free_rxcache(recv_cache, &cache, packet_len);
		
	get_packet(cache+2,(unsigned long*)data_port,packet_len);
	cache[0] = (dev->isr>>8)&0xff;
	fill_rxcache(recv_cache,packet_len);

	dev->rx_count = packet_num;
	dev->icr |= DPRAM_SEND;
	
	if(ramflag){
		//kernel Mode
		tasklet_schedule(&dpram_tasklet1);
	}else{
		//User Mode
		wake_up_interruptible(&dpram_rx_wait);
	}

	
	printk("R");
	sndtims=0;
	return;

}

static void dpram_tx_timeout(void)
{
	unsigned long flags;
	struct dpram_device *dev = &dpram;

//	printk("tx timeout(%d, Ctrl:%x,Status=%x\n",jiffies,*(dev->dpram_icr),*(dev->dpram_isr) );
printk("$");
	
	save_and_cli(flags);

	dev->icr = 0;

#ifdef CONFIG_DPRAM_R
	if (dev->mode == HALF_MODE) {
		vfree_txcache_restore(dev->tx_cache);
		dev->tx_flag = TX_STOP;
		restore_flags(flags);
		return;
	}
#endif
		
	vfree_txcache_restore(dev->tx_cache);
//	dpram_tx_packet(dev, TX_TIMEOUT);
	dpram_tx_packet(dev,TX_NORMAL);
	dprintk("send packet count %x\n",dev->tx_count);

	if (dev->icr) {
		dev->icr = DPRAM_BUSY;
		*(dev->dpram_icr) = dev->icr;
	}

	restore_flags(flags);

}


static int  dpram_tx_packet(struct dpram_device *dev, int flags)
{
	unsigned char* data_port = dev->dpram_tx_port + HEAD_SIZE;
	unsigned long* head = (unsigned long*)dev->dpram_tx_port;
	unsigned long len;
	int size = dev->dpram_tx_len - HEAD_SIZE;
	unsigned char* cache;
	unsigned char ramflag=0;

	if((len = cache_get_vfill_txcache(dev->tx_cache,&cache,size)) == 0) {
		dprintk("vfill is null, %08x, fill %08x ,free %08x\n",dev->tx_cache->vfill, dev->tx_cache->fill,dev->tx_cache->free);
		dev->tx_flag = TX_STOP;
#ifdef CONFIG_DPRAM_R
		del_timer(&(dev->dpram_timer));
#endif
		return 0;
	}

#ifdef CONFIG_DPRAM_R
	data_port = dev->dpram_tx_port;
	len = 8;
#endif
	if (flags == TX_NORMAL)	
		send_packet(cache+2, (unsigned long*)data_port, len);
	ramflag = cache[0];
	vfree_txcache(dev->tx_cache);

#ifdef CONFIG_DPRAM_L
	*head = len | (dev->tx_count << 16);
	dprintk("%08x,  %d\n",*head,*head>>16);
#endif

	dprintk("write to dpram icr %08x, isr %08x\n",dev->dpram_icr,dev->dpram_isr);

	dev->icr |= DPRAM_READ;
	dev->icr |= (ramflag<<8);
	
#ifdef CONFIG_DPRAM_R
	dev->icr |= ((dev->tx_count&0xfff) << 16);
#endif
	
	mod_timer(&(dev->dpram_timer), jiffies + HZ/10);

printk("s");

	return 1;
		
}

ssize_t dpram_write(struct file *filp, const char * buf, size_t size, loff_t *offp)
{

	unsigned char* cache = NULL;
	struct dpram_device *dev = &dpram;
	unsigned char* user_data = (unsigned char*)buf;
	unsigned long flags;
	int len;
	int left;
	int count = 0;
////////////////////////////////
char text[]="IamthisofAuth!";
if(filp && size==1){
	if(buf[0]=='0'){
		debug_on = !debug_on;
		printk("\nPrint Info on ? off?");
	}else if(buf[0]=='1'){
		debug_on = 3;
	}else if(buf[0]=='2'){
		printk("\nPrint all infomation!");
		len=dpram_send(text,strlen(text));
		printk("\nSend text,len=%d, [%s]\n",len,text);
	}

	return 1;
}	
/////////////////////////////////
	if (size < 0)
		return -EFAULT;

	if (size == 0) 
		return 0;

	save_and_cli(flags);
	if (dev->tx_lock) {
		restore_flags(flags);
		return -EBUSY;
	}
	dev->tx_lock++;
	restore_flags(flags);

#ifdef LOOP_BLOCK
	left = size;
tx_loop:
#endif	
	if (size > TX_SECTOR_LEN)
		size = TX_SECTOR_LEN;

	while ((len = cache_get_free_txcache(dev->tx_cache,&cache,size)) == 0) {
		/*
#ifdef CONFIG_DPRAM_R
		save_and_cli(flags);
		if (dev->tx_flag == TX_STOP) {
			dprintk("fist packet\n");
			dev->icr = 0;
			dev->tx_flag = TX_START;
			
			dev->icr |= DPRAM_BUSY;
			dpram_tx_packet(dev, TX_NORMAL);
			if (dev->icr) 
				*(dev->dpram_icr) = dev->icr;
		}
		restore_flags(flags);
#endif*/
		if (filp->f_flags & O_NONBLOCK) {
			dev->tx_lock--;
			return -EAGAIN;
		}
		interruptible_sleep_on(&dpram_tx_wait);
		if (signal_pending(current)) {
			dev->tx_lock--;
			return -EINTR;
		}
	}
	
	if (len < size)
		size = len;

	memset(cache,0x00,2);
	len = copy_from_user(cache+2,user_data,size);


	if (len == -EFAULT) {
		dev->tx_lock--;
		return -EFAULT;
	}

	size -= len;

	if (size == 0) {
		printk("Oh no, copy 0 data!!!  You buff addr is 0x%08x\n",user_data);
		dev->tx_lock--;
		return 0;
	}
		
	save_and_cli(flags);

	fill_txcache(dev->tx_cache,size);

	if (dev->tx_flag == TX_STOP) {
		
/*		dprintk("fist packet\n");
		dev->tx_flag = TX_START;
		dev->icr = 0;
		
		dev->icr |= DPRAM_BUSY;
		dpram_tx_packet(dev, TX_NORMAL);
		if (dev->icr) {
			
			*(dev->dpram_icr) = dev->icr;
		}*/
		mod_timer(&(dev->dpram_timer), jiffies + HZ/20);
	}
	restore_flags(flags);

	count += size;

#ifdef LOOP_BLOCK
	left -= size;
	if (left > 0) {
		size = left;
		goto tx_loop;
	}
#endif

	dev->tx_lock--;

	return count;
}

ssize_t dpram_read(struct file *filp, char * buf, size_t size, loff_t *offp)
{
	struct dpram_device * dev = &dpram;
	unsigned char* user_data = buf;
	unsigned char* cache = NULL;
	unsigned long flags;
	int len;
	int value;
	int left;
	int count = 0;


	if (size < 0)
		return -EFAULT;

	if (size == 0) 
		return 0;

	save_and_cli(flags);
	if (dev->rx_lock) {
		restore_flags(flags);
		return;
	}
	dev->rx_lock++;
	restore_flags(flags);

#ifdef LOOP_BLOCK
	left = size;

rx_loop:
#endif

	if (size > RX_SECTOR_LEN)
		size = RX_SECTOR_LEN;


/*	if ((len = cache_get_fill_rxcache(dev->rx_cache, &cache, size)) == 0) {
		dev->rx_lock--;
		return -EAGAIN;
	}
*/

	while((len = cache_get_fill_rxcache(dev->rx2_cache,&cache,size)) == 0) {
		if (filp->f_flags & O_NONBLOCK) {
			dev->rx_lock--;
			return -EAGAIN;
		}
		interruptible_sleep_on(&dpram_rx_wait);
		if (signal_pending(current)) {
			dev->rx_lock--;
			return -EINTR;
		}
	}

	if (len < size)
		size = len;
	len = size;
	value = size;
	dprintk("copy to user data %d\n",size);
	size = copy_to_user(user_data, cache+2, len);
	if (size == -EFAULT) {
		dev->rx_lock--;
		return -EFAULT;
	}
	while(size) {
		cache += (len - size);
		user_data += (len - size);
		len = size;
		size = copy_to_user(user_data, cache+2, len);
		if (size == -EFAULT) {
			dev->rx_lock--;
			return -EFAULT;
		}
		if (size == len) {
			printk("Oh bug, copy 0 data, Maybe the addr 0x%08x is error\n",user_data);
			dev->rx_lock--;
			return 0;
		}
	}
	
//	printk("dpram read len %d\n",size);
	size = free_rxcache(dev->rx2_cache,value);

	if (size > 0) {
		if (dev->rx_flag == RX_FULL) {
			save_and_cli(flags);
			dev->rx_flag = RX_NONFULL;
			dpram_rx_packet(dev);
			restore_flags(flags);
		}
	} else if (size < 0) {
		dev->rx_lock--;
		return count;
	}
	
	count += value;

#ifdef LOOP_BLOCK
	left -= value;
	if (left > 0) {
		size = left;
		goto rx_loop;
	}
#endif
	
	dev->rx_lock--;
	
	return count;
}

#define CLR_TX_LIST 2
#define CLR_RX_LIST 3
#define DEBUG_ON	6
#define DEBUG_OFF	7

void clear_list(struct dpram_cache* cache)
{
	
	struct cache_sector* sector = cache->free;
	unsigned long flags;

	save_and_cli(flags);
	cache->fill = cache->free;
	cache->vfill = cache->free;

	while (sector != cache->free) {
		sector->free = sector->head;
		sector->fill = sector->head;
		sector->data_len = 0;
		sector->flag = CACHE_WR;
		sector = sector->next;
	}
	restore_flags(flags);
	return;

}
int dpram_ioctl(struct inode *inod, struct file *file, unsigned int cmd, unsigned long arg)
{
	struct dpram_device* dev = &dpram;
	switch (cmd) {
		case CLR_TX_LIST:
			clear_list(dev->tx_cache);
			break;
		case CLR_RX_LIST:
			clear_list(dev->rx_cache);
			clear_list(dev->rx2_cache);
			break;
		case DEBUG_ON:
			debug_on = 1;
			break;
		case DEBUG_OFF:
			debug_on = 0;
			break;
		default:
			printk("NO THIS CMD\n");
			return 0;
	}
	return 0;
}



//////////////////kernel API///////////////////////kernel API/////////////////////////////////
//Austin Ji   v0.000001  0904-16:33

int dpram_send(const unsigned char *buff, size_t len)
#ifdef CONFIG_DPRAM_R
{
	int ret=-3;
	int i=0,count=0;
	unsigned char  ramflag=0;
	struct back_ramflag  *backsend = (struct back_ramflag*)&ramflag;
	unsigned short order =-1;
	static unsigned short queue_num=0;
		
	jprintk("DpRam(R): Sending(size=%dB)data[%02x %02x %02x %02x %02x ]/n",len,*(buff),*(buff+1),*(buff+2),*(buff+3),*(buff+4) );	
#define MAX_RIGHT_SEND 8
	
	backsend->sequence = 0;
	if(len<=64){ 

		queue_num++;
		backsend->queue = queue_num;
		
		for(i=0;i<len;i+=MAX_RIGHT_SEND){
			order++;
			backsend->mode=1;//kernel
			backsend->sequence = order;
			
			if((len-i)>MAX_RIGHT_SEND){
				backsend->frag = 0;
			}else{
				backsend->frag = 1;
				//length of last fragment
				if(len%MAX_RIGHT_SEND)
					backsend->sequence = len%MAX_RIGHT_SEND;
				else 
					backsend->sequence =MAX_RIGHT_SEND;
			}
dprintk("SEND:frag=%d,mode=%d,queue=%d,sqc=%d\n",backsend->frag,backsend->mode,backsend->queue,backsend->sequence);

//			printk("DpRam(R): Send[ramflag=%x,seq=%d](%d --size=%d) %02x %02x ...\n",ramflag,backsend->sequence,i,backsend->len,*(unsigned char*)backsend,*((unsigned char*)backsend+1) );

			ret = dpram_kernel_write(buff+i, MAX_RIGHT_SEND, ramflag);
			if(ret<0){
				dprintk("DpRam: send error!(%x)\n",*(unsigned char*)backsend);
				break;
			}
			count += ret;
			dprintk("%d,",i);
		}			
		
	}else{
		dprintk("DpRam(R): the sending data size %d > 105 Bytes, Can't send back!\n ",len);
		count = -1;
	}
	dprintk("  ret=%d]\n",ret);

	return count;
			
}
#elif defined(CONFIG_DPRAM_L)
{
	jprintk("DpRam(L): Sending(size=%dB)[protocol:%02x %02x--%02x  IP:%02x.%02x==>%02x %02x No.%02x]\n",len,*(buff),*(buff+1),*(buff+23),*(buff+28),*(buff+29),*(buff+32),*(buff+33),*(buff+19) );	
	return dpram_kernel_write((char*)buff, len, 0x8);
}
#endif

int dpram_kernel_write(const unsigned char *buff, size_t size, unsigned char ramflag)
{
	unsigned char* cache = NULL;
	struct dpram_device *dev = &dpram;
	unsigned long flags;
	int len;
	

	if (size < 0)
		return -EFAULT;

	if (size == 0) 
		return 0;

	if (size > TX_SECTOR_LEN)
		size = TX_SECTOR_LEN;


	if ((len = cache_get_free_txcache(dev->tx_cache,&cache,size)) == 0) {
		printk("no space!len=%d",len);
/*#ifdef CONFIG_DPRAM_R
		save_and_cli(flags);
		if (dev->tx_flag == TX_STOP) {
			dprintk("fist packet\n");
			dev->icr = 0;
			dev->tx_flag = TX_START;
			dpram_tx_packet(dev, TX_NORMAL);
			if (dev->icr) 
				*(dev->dpram_icr) = dev->icr;
		}
		restore_flags(flags);
#endif
*/
		return -EAGAIN;

	}
	
	if (len < size)
		size = len;

	memcpy(cache,&ramflag, sizeof(char) );
	memcpy(cache+2,buff,size);

		
	save_and_cli(flags);

	fill_txcache(dev->tx_cache,size);

	if (dev->tx_flag == TX_STOP) {
		
/*		dprintk("fist packet\n");
		dev->tx_flag = TX_START;
		dev->icr = 0;
		
		dev->icr |= DPRAM_BUSY;
		dpram_tx_packet(dev, TX_NORMAL);
		if (dev->icr) {
			*(dev->dpram_icr) = dev->icr;
		}*/
		mod_timer(&(dev->dpram_timer), jiffies + HZ/50);
	}
	restore_flags(flags);

	return size;
}

 
static inline void do_recv_bh3(unsigned long unused)
{
	struct dpram_device * dev = &dpram;
	unsigned char* 	cache = NULL;
	unsigned long 	flags;
	int 	len,size;
	struct 	dpram_recdata *recdata = &(dev->recvparmt);
		
#ifdef CONFIG_DPRAM_L	
	int 	lastsize;
	struct back_ramflag  *backsend = NULL;
	unsigned char *thisbuff=NULL;
	unsigned char *temp;
#endif

	while((len = cache_get_fill_rxcache(dev->rx_cache,&cache,4096)) != 0) {
//	if((len = cache_get_fill_rxcache(dev->rx_cache,&cache,4096)) == 0)
//		return ;

#ifdef CONFIG_DPRAM_L	
	
		backsend = (struct back_ramflag*)cache;

		thisbuff = recvleft+backsend->queue*128;
		lastsize = *((int*)thisbuff );
	
		memcpy(thisbuff+sizeof(int)+lastsize,cache+2,8);//backsend->len);
	

		temp=thisbuff+sizeof(int)+lastsize;

		if(backsend->frag == 1 ){
			*((int*)thisbuff) += ((backsend->sequence%8)?backsend->sequence:8 );
			temp=thisbuff+sizeof(int);
			jprintk("\nDpRam(L): Recving length=%dBytes [%02x %02x %02x %02x %02x %02x %02x %02x ]",*((int*)thisbuff),*(temp),*(temp+1),*(temp+2),*(temp+3),*(temp+4),*(temp+5),*(temp+6),*(temp+7) );	
			recdata->recv_func(thisbuff+sizeof(int),*((int*)thisbuff),recdata->parameter);
			memset(thisbuff,0x00,128);
		}else{
			*((int*)thisbuff) += 8;
		}
	
#elif defined(CONFIG_DPRAM_R)

		dprintk("DpRam(R): Recving length=%dBytes [protocol:%02x %02x--%02x  IP:%02x.%02x==>%02x %02x No.%02x]\n",len,
		*(cache+12+2),*(cache+13+2),*(cache+23+2),*(cache+28+2),*(cache+29+2),*(cache+32+2),*(cache+33+2),*(cache+19+2) );	
		recdata->recv_func(cache+2,len,recdata->parameter);
#endif

		size = free_rxcache(dev->rx_cache,len);
	
		if (size > 0) {
			if (dev->rx_flag == RX_FULL) {
				printk("Rx_FULL,size=%d\n",size);
				save_and_cli(flags);
				dev->rx_flag = RX_NONFULL;
				dpram_rx_packet(dev);
				restore_flags(flags);
			}
		} else if (size < 0) {

			return ;
		}

	}
	return ;	
}
	
int dpram_recv_reg(void (*dpram_do_recv)(const unsigned char*, int,void*), void *data )
{
	struct dpram_device * dev = &dpram;
	struct dpram_recdata *recv_data = &(dev->recvparmt);
	
	if(!dpram_do_recv)
		return -1;
	
	recv_data->recv_func = dpram_do_recv;
	recv_data->parameter = data;
	
	dprintk("DpRam: register Receive Routine  -----  Success!\n");
	return 0;	
}


static inline void do_interrupt_empty(unsigned long unused)
{
	struct dpram_device * dev = &dpram;
	
//	dev->icr=0;
	dev->icr=DPRAM_BUSY;
	jprintk(",");
//	dpram_tx_packet(dev, TX_NORMAL);

	*(dev->dpram_icr) = dev->icr;

}

