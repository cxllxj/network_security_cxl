/******************************************************************
** File: fd.c
** Copyright (c) 2002 �Ϻ���������
** ������:  ��ҫ
** ����:   Mar 1,2004
** �޸���:
** �� ��:
** �� ��:   �����봦��ģ��,������֡���й�����ӳ�䣬��ά��Session����
**
** �� ��:  V0.1
***************************************************************/


#include <asm/uaccess.h>
#include <asm/system.h>
#include <asm/bitops.h>
#include <linux/config.h>
#include <linux/types.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/string.h>
#include <linux/mm.h>

#include <linux/errno.h>

#include <linux/netdevice.h>

#include <linux/notifier.h>
#include <linux/skbuff.h>
#include <linux/brlock.h>
#include <net/sock.h>
#include <linux/rtnetlink.h>
#include <linux/proc_fs.h>
#include <linux/stat.h>

#include <linux/divert.h>
#include <net/dst.h>
#include <net/pkt_sched.h>
#include <net/profile.h>
#include <net/checksum.h>

#include <linux/kmod.h>
#include <linux/module.h>
#include <linux/time.h>
#include <linux/insulate.h>
#include <linux/dpram.h>

struct sesn_info *g_session_head;
struct sesn_info *g_session_tail;
struct rulelist *g_rule_head;
struct rulelist *g_rule_tail ;
rwlock_t gap_sesn_lock = RW_LOCK_UNLOCKED;	


//����TCP�˿ڡ�IP��ַ��MAC��ת��
int mapping(	struct sk_buff *skb,
		 struct sesn_info *curnt)
/*Fuction: ͨ����鵱ǰ�Ự�����е�ӳ����Ϣ��������֡�е�MAC, IP, port����һϵ�е�ת��ӳ��
  Parameters:
	mac_frame:	[INOUT]�ڴ��������֡��ӳ������Ӧ������ת��
	session_list:	[IN]�Ѵ��ڵĻỰ�б������ݵ�ӳ�������Դ�ڴ�
  Return Value:
	return 0 if success, or return negative
*/
{
	struct ethhdr  	*eth_hdr = skb->mac.ethernet;
	struct iphdr	*ip_hdr = (struct iphdr*)skb->data;
	struct tcphdr  	*tcp_hdr = (struct tcphdr*)(skb->data+20);
	int 	rtn=-1;
	//struct rulelist* next_rule = NULL;
	u_short tcpsize=0;
//	u_short direction;
	
	//this packet must be TCP
	if( (skb->protocol != 0x0800)
	  &&(ip_hdr->protocol != 0x06) )
		return -1;

#ifdef CONFIG_DPRAM_L
		//
		memcpy(eth_hdr->h_dest,curnt->data.outmac,6);
		//ԴMAC�滻Ϊ��������豸�����˵�MAC
//		memcpy(eth_hdr->ether_shost,g_session_head->session_value.data.outmac,6);		

		ip_hdr->daddr = htonl(curnt->data.outip );

		ip_hdr->saddr = htonl(curnt->data.map_inip );


#elif defined(CONFIG_DPRAM_R)
		//
		memcpy(eth_hdr->h_dest,curnt->data.inmac,6);
		//ԴMAC�滻Ϊ��������豸�����˵�MAC
//		memcpy(eth_hdr->ether_shost,g_session_head->session_value.data.inmac,6);		

		ip_hdr->daddr = htonl(curnt->data.inip);

		ip_hdr->saddr = htonl(curnt->data.map_outip );
		
#endif
	rtn = 0;
//	kdPrint(("Mapping:ip(%x-->%x)\n",ip_hdr->saddr,ip_hdr->daddr));
	//IP check sum
	ip_hdr->check = 0;
	ip_hdr->check = tcp_in_cksum( (u_char*)ip_hdr, 20 ,0);
	
	//TCP UDP check sum
	if(ip_hdr->protocol==0x06 ||ip_hdr->protocol==0x17 ){
		tcpsize = htons(ip_hdr->tot_len)-20;
		tcp_hdr->check = 0;
		tcp_hdr->check = tcp_in_cksum( (u_char*)(&ip_hdr->saddr), tcpsize+8 ,ip_hdr->protocol);
	}
	
	if(curnt->TCP_status==WTCP_CLOSED){
		
		//LOG, Delete Current session 
//		send_log("On Session Filter",LOG_AUTH,LOG_INFO,OP_DELETE,(int)direction,crnt_session);

		
#ifdef DEBUG
		kdPrint(("\n      --------free-------<%x>--\n",crnt_session));
		struct sesn_info* temp;
		temp = (struct sesn_info*)g_session_head;
		while(temp){
			session_print(temp);
			temp=(struct sesn_info *)(temp->session_value.next);
		}
#endif //DEBUG				
		//�ѱ��ر�,ɾ���˻Ự�ڵ�
		free_session(curnt);
		curnt = NULL;

	}
	return rtn;
}

int compare_rule(struct sk_buff *skb,  const struct policyinfo rulecont)
//Fuction: ����յ�������֡�Ƿ�����˵�������
//Parameters:
//	direction: 	[IN]����������Ĵ��䷽�����������⣬������������
//	mac_frame:	[IN]���������֡��
//	rule_node:	[IN]����ṹָ��
//Return Value:
//	return 0 if same as this rule_node , or return negative
{
	struct ethhdr  	*eth_hdr = skb->mac.ethernet;
	struct iphdr	*ip_hdr = (struct iphdr*)skb->data;
	struct tcphdr  	*tcp_hdr = (struct tcphdr*)(skb->data+20);

	//compare with destination IP addr, source ip addr, dest mac, src mac
	//  dest port, IP protocol.
#ifdef CONFIG_DPRAM_L

		if(htonl(ip_hdr->daddr) != rulecont.map_outip )
			return -31;
			
		if(htonl(ip_hdr->saddr) != rulecont.inip)
			return -32;
		//protocol ,such as TCP,UDP
		if( ip_hdr->protocol != rulecont.protocol)
			return -37;
		//destination port
		if( (rulecont.protocol==0x06 ||rulecont.protocol==0x17) 
		   && (rulecont.outport != tcp_hdr->dest) )
		   	return -35;
		   				
		//MAC
		if( memcmp(eth_hdr->h_source,rulecont.inmac,ETH_ALEN) )
			return -33;
		

#elif defined(CONFIG_DPRAM_R)

		if(htonl(ip_hdr->daddr) != rulecont.map_inip )
			return -31;

		if(htonl(ip_hdr->saddr) != rulecont.outip )
			return -32;
		//protocol ,such as TCP,UDP
		if( ip_hdr->protocol != rulecont.protocol)
			return -37;
		//destination port of TCP or UDP
		if( (rulecont.protocol==0x06 ||rulecont.protocol==0x17)
		   && (rulecont.outport != tcp_hdr->source) )
		   	return -35;		
		//mac
		if( memcmp(eth_hdr->h_source,rulecont.outmac,ETH_ALEN) )
			return -33;
		
#endif
	return 0;
}
int compare_arp(struct sk_buff *skb, const struct rulelist *rule)
//Fuction: ����յ�������֡�Ƿ�����˵�������
//Parameters:
//	direction: 	[IN]����������Ĵ��䷽�����������⣬������������
//	mac_frame:	[IN]���������֡��
//	rule_node:	[IN]����ṹָ��
//Return Value:
//	return 0 if same as this rule_node , or return negative
{
	struct ethhdr  	*eth_hdr = skb->mac.ethernet;
	struct arphdr	*arp = (struct arphdr*)skb->data;
	u_int	dip = *(u_int*)(skb->data+24);
	u_int	sip = *(u_int*)(skb->data+14);
	
	if(skb->protocol!=0x0806 )
		return -37;
	//it must be request of arp
	if(ntohs(arp->ar_op)!=0x0001)
		return -38;
#ifdef CONFIG_DPRAM_L
	//inside  left
//printk("dip=%x,(%x),sip=%x(%x)\n",dip,rule->data.map_outip,sip,data.inip);
	if(htonl(dip) != rule->data.map_outip )
		return -31;
		
	if(htonl(sip) != rule->data.inip)
		return -32;

	//MAC
	if( memcmp(eth_hdr->h_source,rule->data.inmac,ETH_ALEN) )
		return -33;
		

#elif defined(CONFIG_DPRAM_R)
	//outside right

	if(htonl(dip) != rule->data.map_inip )
		return -31;

	if(htonl(sip) != rule->data.outip )
		return -32;
		
	if( memcmp(eth_hdr->h_source,rule->data.outmac,ETH_ALEN) )
		return -33;
			


#endif
	return 0;
}
int compare_port(struct sk_buff *skb, struct sesn_info *session_node)
//Function: �Ƚ϶˿ںţ�����δ���˿�ӳ�䣩
{
	struct tcphdr  *tcp_hdr = (struct tcphdr*)(skb->data+20);
	int rtn = 0;
	
	//then compare with ports
#ifdef CONFIG_DPRAM_L

		if( session_node->data.inport != htons(tcp_hdr->source) )
			return -35;
		if(session_node->data.outport != htons(tcp_hdr->dest) )
			return -36;
			
#elif defined(CONFIG_DPRAM_R)
		if( session_node->data.inport == htons(tcp_hdr->dest) )
			return -35;
		if(session_node->data.outport == htons(tcp_hdr->source) )
			return -36;
#endif

	return rtn;
}



//


////////////////////////////////////////////////////////
u_short tcp_in_cksum( u_char* pStartingByte, int nByteCount ,u_char protlcode)
//Function: ����IP,TCP,UDP��У���
//Parameters:
//	pStartingByte:	[IN]����IPУ���ʱ��ΪIP�ײ��ĵ�ַ������TCP��UDP�ײ�У���ʱ��
//			                ΪIP�ײ���ԴIP��ַ����ʼָ��
//	nByteCount��	  [IN]IP�ײ����ȣ�UDP���ȼ�8��TCP���ȼ�8
//	protlcode��	    [IN]IP��Ϊ0��TCPΪ6��UDPΪ17
//Return Value
//	return check sum
{
	u_int sum = 0;
	u_short *addr = (u_short * )pStartingByte;
	u_short  add_protcl = (protlcode<<8)&0xff00;
	u_short	tcplength = nByteCount-8;
//	u_short ped=0;

	//peoTCP_Header
	if(protlcode==6 || protlcode==17)
	{
		//TCP UDP fute header
		sum += add_protcl + htons(tcplength);
	}
	//
	// Add 16-bit Words
	//
	while (nByteCount > 1)
	{
  		//
		// This Is The Inner Loop
		//
		sum += *(addr++);
		nByteCount -= 2;
	}


	//
	// Add leftover byte, if any
	//
	if (nByteCount > 0)
#if BYTE_ORDER == BIG_ENDIAN
		sum += (*(u_char* )addr) << 8;
#else
		sum += *(u_char* )addr;
#endif


	//
	// Fold 32-bit sum to 16-bit
	//
	while (sum >> 16)
		sum = (sum & 0xffff) + (sum >> 16);

	//
	// Return one's compliment of final sum.
	//
	return (u_short) ~sum;
}

int filter_by_session(struct sk_buff *skb)
{
//	struct iphdr	*ip_hdr = (struct iphdr*)skb->data;
//	struct tcphdr  	*tcp_hdr = (struct tcphdr*)(skb->data+20);
	
	//ARP frame
	if( skb->protocol==0x0806) {
		arpd_filter(skb);
		return -1;
	}
	
	//this packet must be IP
	if(skb->protocol!=0x0800)
		return -1;
#ifdef CONFIG_DPRAM_L
	return session_filter_in(skb);
#elif defined(CONFIG_DPRAM_R)
	return session_filter_out(skb);
#endif

}


//���ݹ����ļ�����
int session_filter_in(struct sk_buff *skb)
//Fuction: �����˼���յ�������֡�Ƿ�����ͨ������SYN��־��TCPͨ������������飬�����ͨ���Ự���������
//Parameters:
//	mac_frame:	[IN]���������֡��
//Return Value:
//	return 0 if peromise , or return negative
//global: g_rule_head  g_session_head
{
//	struct ethhdr  	*eth_hdr = skb->mac.ethernet;
	struct iphdr	*ip_hdr = (struct iphdr*)skb->data;
	struct tcphdr  	*tcp_hdr = (struct tcphdr*)(skb->data+20);
	int 	rtn=-1;
	struct rulelist*  next_rule = NULL;
	struct sesn_info *crnt_session=NULL;
	
//	struct rulelist*  next_session=NULL;
	static int m=0;
	
	
	//ARP frame
	if( skb->protocol==0x0806) {
		arpd_filter(skb);
		return -1;
	}

	//this packet must be IP
	if(skb->protocol!=0x0800)
		return -40;

	if(ip_hdr->protocol != 0x06){
		//not TCP, compare with the rule
		next_rule = g_rule_head;
		while(next_rule){
			rtn = compare_rule(skb,next_rule->data);
			if(rtn==0)
				break;
			next_rule = next_rule->next;
		}

		return rtn;
	}
	
	if(tcp_hdr->syn){

		//��֤�������ӣ�������������������ʱ��������֡
		if( tcp_hdr->ack)
		  	return -41;

		//����SYN��־�ıȽϹ�������
		//compare with the rule
		next_rule = g_rule_head;
		while(next_rule){
			rtn = compare_rule(skb,next_rule->data);
			if(rtn==0)
				break;
			next_rule = next_rule->next;
		}
		if(rtn<0)
			return rtn;

		//����Ƿ��Ѿ�����
		crnt_session = find_session(skb);

		//���ڻỰ�����Ҳ��������½�һ��
		if(crnt_session==NULL ){

			crnt_session = create_session(skb, next_rule);

			if(NULL==crnt_session){
//				printk("Can't create new session(for Rule:%x ) without enough memory!\n",crnt_session );
				return -1;
			}
		}//

		//ˢ�»Ự�������
		do_gettimeofday(&crnt_session->start_time);
		do_gettimeofday(&crnt_session->reach_time);
		crnt_session->frame_num++;
		crnt_session->timeout = 0;
//		crnt_session->TCP_status = WTCP_START_SYN;
		status_change(skb,crnt_session);
//		crnt_session->retrans_num = 0;

		//LOG, Create new session 
//		send_log("On Session Filter",LOG_AUTH,LOG_INFO,OP_UPDATE,(int)FROM_IN_TO_OUT,crnt_session);
		
	}else{
		//����һ���������鵱ǰ�ĻỰ��
		crnt_session = find_session( skb);
		if(crnt_session==NULL)//�Ҳ���
			return -1;
		rtn=0;
#ifdef DEBUG_a
kdPrint(("outside)"));
if(tcp_hdr->th_flags&TH_ACK)kdPrint(("ACK-"));
if(tcp_hdr->th_flags&TH_FIN)kdPrint(("FIN-"));
if(tcp_hdr->th_flags&TH_SYN)kdPrint(("SYN-"));
if(tcp_hdr->th_flags&TH_PUSH)kdPrint(("PUSH-"));
#endif //DEBUG

		//LOG, Update Current Session  Recorder
		
		m++;
//		if(m%10==0)
//			send_log("On Session Filter",LOG_AUTH,LOG_NOTICE,OP_UPDATE,(int)FROM_IN_TO_OUT,crnt_session);


		//���µ�ǰ�Ự��ĳЩ����
		crnt_session->frame_num++;
		crnt_session->timeout = 0;
		do_gettimeofday(&crnt_session->reach_time);
	
		//��ǰ�Ự״̬
		status_change(skb,crnt_session );

	}
	if(rtn==0)
		mapping( skb, crnt_session);
	return rtn;
}


//���ݹ����ļ�����
int session_filter_out(	struct sk_buff *skb,u_char *ramdata)
//		struct rulelist *filter_rule,
//		const struct sesn_info *active_session)
//Fuction: �����˵Ĺ��˼��.����յ�������֡�Ƿ�����ͨ������SYN��־��TCPͨ������������飬�����ͨ���Ự���������
//Parameters:
//	direction: 	[IN]����������Ĵ��䷽�����������⣬������������
//	mac_frame:	[IN]���������֡��
//	filter_rule:	[IN]��������
//	active_session��[IN]��ǰ������ĻỰ����
//Return Value:
//	return 0 if peromise , or return negative
//global: g_rule_head  g_session_head
{
	struct ethhdr  	*eth_hdr = skb->mac.ethernet;
	struct iphdr	*ip_hdr = (struct iphdr*)skb->data;
	struct tcphdr  	*tcp_hdr = (struct tcphdr*)(skb->data+20);
	int 	rtn=-1;
//	struct rulelist*  next_rule = NULL,*sesn_node=NULL;
	struct sesn_info *crnt_session=NULL;
	
//	struct rulelist*  next_session=NULL;
		static int m=0;
		
	//ARP frame
	if( skb->protocol==0x0806) {
		arpd_filter(skb);
		return -1;
	}
	//this packet must be TCP
	if(  (skb->protocol!=0x0800)
	  ||(ip_hdr->protocol != 0x06) )
		return -1;
	
	if(tcp_hdr->syn && (!tcp_hdr->ack) ){
		//��֤�������ӣ�������������������ʱ��������֡
		return -1;
	}
	
	//����һ���������鵱ǰ�ĻỰ��
	crnt_session = find_session(skb );
	if(crnt_session==NULL)//�Ҳ���
		return -1;
	rtn=0;
#ifdef DEBUG
kdPrint(("(inside)"));
if(tcp_hdr->th_flags&TH_ACK)kdPrint(("ACK-"));
if(tcp_hdr->th_flags&TH_FIN)kdPrint(("FIN-"));
if(tcp_hdr->th_flags&TH_SYN)kdPrint(("SYN-"));
if(tcp_hdr->th_flags&TH_PUSH)kdPrint(("PUSH-"));
#endif //DEBUG

	//LOG, Update Current Session  Recorder

	m++;
//	if(m%10==0)
//		send_log("On Session Filter",LOG_AUTH,LOG_NOTICE,OP_UPDATE,(int)FROM_OUT_TO_IN,crnt_session);


	
	//��ǰ�Ự״̬
	status_change(skb, crnt_session);

	rtn = tcp2eight(skb, ramdata, crnt_session);
	return rtn;
}



///////////////////////////////////////////////////////////////
int status_change(struct sk_buff *skb, 
		  struct sesn_info *crnt_sesn )
//Function: ����flagˢ�µ�ǰ�Ự����״̬
//Parameters:
//	direction: 	[in]��ǰ����֡�Ĵ��䷽��
//	crnt_sesn:	[inout]��ǰ�Ự���ָ��
//	flag:		[in]��ǰTCP����֡�ı�־λ
//Return Value
//	return 0 if peromise , or return negative
{
	struct iphdr	*ip_hdr = skb->h.ipiph;
	struct tcphdr  	*atcp = (struct tcphdr*)(skb->h.raw+20);
	
	if(crnt_sesn==NULL)
		return -1;
		
	
	crnt_sesn->snd_ack = atcp->ack_seq;
	crnt_sesn->snd_una = atcp->seq;
	crnt_sesn->snd_nxt = crnt_sesn->snd_una + ip_hdr->tot_len - atcp->doff*4-20;
	crnt_sesn->snd_wnd = atcp->window;
	
	/*	
	}else if((crnt_sesn->src_ip == sendip->saddr)&&(crnt_sesn->dst_ip == sendip->daddr) ){
		crnt_sesn->snd_ack = sendtcp->seq;
//		crnt_sesn->snd_una = recvtcp->ack_seq;
		crnt_sesn->snd_nxt = sendip->tot_len - sendtcp->doff*4-20;
		crnt_sesn->snd_wnd = sendtcp->window;
		
	}*/
	
	//ˢ�»Ự�������
	do_gettimeofday(&crnt_sesn->start_time);
	do_gettimeofday(&crnt_sesn->reach_time);
	crnt_sesn->frame_num++;
	crnt_sesn->timeout = 0;
//	crnt_session->TCP_status = WTCP_START_SYN;

	
/*	//ͳ����һ���������ش���������
	if((atcp->psh)
	   && (crnt_sesn->TCP_status==WTCP_ESTABLISHED)) {
		if((crnt_sesn->retrans_num>>16)==direction)
			crnt_sesn->retrans_num++;
		else
			crnt_sesn->retrans_num = (direction<<16)|0x01;
		
		return 0;
	}
	*/
	//Create new TCP connection
	if(atcp->syn && (!atcp->ack) ){
		crnt_sesn->TCP_status = WTCP_START_SYN;
		return 0;
	}
	
	//Reset 
	if(atcp->rst){
		crnt_sesn->TCP_status = WTCP_CLOSED;
		return 0;
	}
	
	switch(crnt_sesn->TCP_status)
	{
	case WTCP_START_SYN:	
		if(atcp->ack)//����������ʱ
			crnt_sesn->TCP_status = WTCP_ESTABLISHED;
		break;
		
	case WTCP_ESTABLISHED:	
//		if(atcp->ack)
//			crnt_sesn->retrans_num = 0;
		if(atcp->fin)//�յ��Ͽ�ʱ�ĵ�һ��FIN
			crnt_sesn->TCP_status = WTCP_HALF_FIN;
		break;
	
	case WTCP_HALF_FIN:	//��Ͽ�
		if(atcp->ack) 
			crnt_sesn->TCP_status = WTCP_HALF_FIN_ACK;
		break;
	
	case WTCP_HALF_FIN_ACK:	//�յ��Ͽ�ʱ�ĵڶ���FIN
		if(atcp->fin)
			crnt_sesn->TCP_status = WTCP_COMPLETE_FIN;
		break;
		
	case WTCP_COMPLETE_FIN:	
		if(atcp->ack) 
			crnt_sesn->TCP_status = WTCP_CLOSED;//����ȫ�Ͽ�
		break;
		
//	default :

	}
	
	return 0;
}


//#ifdef CONFIG_DPRAM_R
int tcp2eight(struct sk_buff* skb,u_char *ramdata, struct sesn_info *curnt )
//function: ������������TCPӦ����ת��8�ֽ�
{

	struct iphdr	*recvip = (struct iphdr*)skb->data;
	struct tcphdr  	*recvtcp = (struct tcphdr*)(skb->data+20);
	
	unsigned char* 	trans_ramdata=NULL;
	struct ram_conv	*my8bytes = NULL;
	int	tcpsize=0,ret;
	u_char *optcmd;
	int optlen;
	
	if(ramdata==NULL)
		return -1;
		
	if(recvip->protocol != 0x06)//UDP
		return -3;
	
	my8bytes = (struct ram_conv*)ramdata;
	memset(&my8bytes,0x00,16);
	my8bytes->ack = recvtcp->ack;
	my8bytes->psh = recvtcp->psh;
	my8bytes->rst = recvtcp->rst;
	my8bytes->syn = recvtcp->syn;
	my8bytes->fin = recvtcp->fin;
	
	my8bytes->sess_id = curnt->index;
	my8bytes->sequence = (htonl(recvtcp->seq)&0xff);
	my8bytes->ack_num = (htonl(recvtcp->ack_seq)&0xffff);
	my8bytes->window = htons(recvtcp->window);
	
	tcpsize = recvtcp->doff*4;
	
	if(recvtcp->syn){
		memcpy(ramdata+8,&(recvtcp->ack_seq),4);
		optcmd = skb->data;
		while(optlen < tcpsize-20){
			
			switch( optcmd[0] ){
			case 0x01:
				optcmd++;
				break;
			case 0x02:
				//Maximum Segment size
				optlen += optcmd[1];
				memcpy(ramdata+12, optcmd+2, 2);
				break;
			default :
				optlen += optcmd[1];
				break;
			}
		}
				
			
	}
	if( tcpsize > 20){
		//��ʱ�Ȳ���
		memcpy(trans_ramdata,&my8bytes,sizeof(struct ram_conv));
		memcpy(trans_ramdata+8,recvtcp,tcpsize-20);
		
	}
	
	return ret;	
	
}
//#endif

#ifdef CONFIG_DPRAM_L


int eight2tcp(const unsigned char *ram_buff, int ram_size,
		struct sk_buff *skb)
{
	struct iphdr	*recvip = NULL;
	struct tcphdr 	*recvtcp = NULL;
	struct ram_conv  *ram_sesn = (struct ram_conv*)ram_buff;
	unsigned short 	iplen=0;
	struct sesn_info  *mysessn = NULL;
	
	//look for dependence session
	mysessn = g_session_head->next;
	while(mysessn){
			if(mysessn->index == ram_sesn->sess_id)
				break;
			mysessn = mysessn->next;
	}
	
	if( !mysessn)
		return -1;
		
	memset(skb->data, 0x00, 60);
	//make mac header
	memcpy(skb->data,mysessn->data.inmac,6);
	memcpy(skb->data+6,mysessn->data.outmac,6);
	*(skb->data+12) = 0x08;
	*(skb->data+13) = 0x00;
	
	
	recvip = (struct iphdr	*)(skb->data+skb->dev->hard_header_len);
	//make IP header
	recvip->version = 4;
	recvip->ihl = 5;
	recvip->tos = 0x00;
	iplen = 20+20;
	recvip->tot_len = htons(iplen);
	

	recvip->id = mysessn->index;
	recvip->frag_off = htons((__u16)0x4000);
	recvip->ttl = 0x80;
	recvip->protocol = 0x06;
	recvip->check = 0;
	recvip->saddr = mysessn->data.outip;
	recvip->daddr = mysessn->data.inip;
	//ip check sum
	recvip->check = tcp_in_cksum( (u_char*)recvip, 20,0);
	
	
	recvtcp = (struct tcphdr *)((u_char*)recvip+20);
	//make TCP header
	recvtcp->source = mysessn->data.outport;
	recvtcp->dest = mysessn->data.inport;
	//sequence of Ack_TCP
	if( (mysessn->snd_ack&0xff) >= ram_sesn->sequence)
		recvtcp->seq = (mysessn->snd_ack&0xffffff00)|ram_sesn->sequence;
	else
		recvtcp->seq = ((mysessn->snd_ack&0xffffff00)+0x100)|ram_sesn->sequence;
	//acknowledge number of Ack_TCP
	if( (mysessn->snd_una&0xffff)>=ram_sesn->ack_num)
		recvtcp->ack_seq = (mysessn->snd_una&0xffff0000)|ram_sesn->ack_num;
	else
		recvtcp->ack_seq = ((mysessn->snd_una&0xffff0000)+0x10000)|ram_sesn->ack_num;
	
	//tcp header size
	recvtcp->doff = (iplen-20)/4;
	recvtcp->res1 = 0;
	recvtcp->ack = ram_sesn->ack;
	recvtcp->psh = ram_sesn->psh;
	recvtcp->rst = ram_sesn->rst;
	recvtcp->syn = ram_sesn->syn;
	recvtcp->fin = ram_sesn->fin;
	
	recvtcp->window = ram_sesn->window;
	recvtcp->check = 0;
	recvtcp->urg_ptr = 0;
	
	if(recvtcp->syn && ram_size>8){
		u_char * tcpopt = (u_char *)recvtcp +20;		
		skb_put(skb,2);
		memcpy( &(recvtcp->ack_seq), ram_buff+8, 4);
		//MSS
		tcpopt[0] = 0x02;
		tcpopt[1] = 0x04;
		tcpopt[2] = ram_buff[12];
		tcpopt[3] = ram_buff[13];
		tcpopt[4] = 0x01;
		tcpopt[5] = 0x01;
		tcpopt[6] = 0x04;
		tcpopt[7] = 0x02;
		
		iplen = 20+20+8;
		recvip->tot_len = htons(iplen);
		recvtcp->doff = (iplen-20)/4;
		
	}

	//tcp check sum
	recvtcp->check = tcp_in_cksum( skb->data+26, iplen-20,6);
	
	//update
	mysessn->snd_una = recvtcp->ack_seq;
	status_change(skb, mysessn);
	return 0;	
	
}


#endif 

void arpd_filter(struct sk_buff *skb)
{
	int rtn=-1;
	struct net_device *dev = skb->dev;
	u_int	sip,dip;
	struct rulelist* next_rule;
	u_char targetmac[ETH_ALEN];
	
	next_rule = g_rule_head->next;
	while(next_rule){
			rtn = compare_arp(skb,next_rule);
			if(rtn==0)
				break;
			next_rule = next_rule->next;
		}
	if(rtn!=0){
		printk("Drop this ARP(%d)\n",rtn);
		return ;
	}
	dip = *(u_int*)(skb->data+24);
	sip = *(u_int*)(skb->data+14);
	memcpy(targetmac,skb->mac.ethernet->h_source,ETH_ALEN);

printk("Send ARP reply!\n");
	arp_send(ARPOP_REPLY,ETH_P_ARP,sip,
		dev,dip, targetmac,dev->dev_addr,targetmac);
	/*arp_send(int type, int ptype, u32 dest_ip, 
	      struct net_device *dev, u32 src_ip, 
	      unsigned char *dest_hw, unsigned char *src_hw,
	      unsigned char *target_hw)*/
		
}

void ipadd_print(char *msg, u_int ipaddr)   
{
	printk("%s",msg);
	printk(" %d.%d.%d.%d ",ipaddr>>24,(ipaddr&0xff0000)>>16,(ipaddr&0xff00)>>8,(ipaddr&0xff));
}
void packet_print(struct sk_buff *skb)
{
	struct ethhdr  	*eth_hdr = skb->mac.ethernet;
	struct iphdr	*ip_hdr = (struct iphdr*)skb->data;
//	struct tcphdr  	*tcp_hdr = (struct tcphdr*)(skb->data+20);
	u_int	dip = *(u_int*)(skb->data+24);
	u_int	sip = *(u_int*)(skb->data+14);
//	int		i=0;
//	u_short len;


	printk("%s",skb->dev->name);
	switch(skb->protocol )
	{
	case 0x0800:
		if(ip_hdr->protocol == 0x06)
			printk("<IP-TCP>len:%dbytes ID:0x%x ",skb->len,ip_hdr->id);
		else if(ip_hdr->protocol == 0x11)
			printk("<IP-UDP>len:%d ID:0x%x ",skb->len,ip_hdr->id);
		else
			printk("<IP-Other>len:%d ID:0x%x ",skb->len,ip_hdr->id);

		ipadd_print(" IP:",ntohl(ip_hdr->saddr) );
		ipadd_print("==>",ntohl(ip_hdr->daddr) );

/*		for(i=0;i<54;i++){
			if(i%16 == 0) printf("\n");
			if(data[i]<0x10) printf("0");				                        printf("%x ",data[i]);
		}*/
		printk("\n");
		break;
		
	case 0x0806:
		ipadd_print("ARP:  ",sip );
		ipadd_print("==>",dip );
		printk("\n");
		break;
		
	default:

		break;
	}

	return ;
	
}

/*
  =============================DpRAM Funtion==========================
 */
#ifdef CONFIG_DPRAM_R
void	dpramif_recv(const unsigned char* ramdata, int pkt_len,void* mybuff)
{
	struct net_device * fowddev = NULL;
	struct sk_buff *skb = NULL;
	
	if(pkt_len==0)
		return ;
	fowddev = dev_get_by_name("eth1");
	if(fowddev == NULL)
		return ;
		
	skb = dev_alloc_skb(pkt_len+16);

	/*
	 *	Start of frame
	 */
	 

	if (skb == NULL){
		printk(KERN_INFO "DpRam: Memory squeeze, dropping packet.\n");

	}
	else{
	
    		skb_reserve(skb,2);	/* Force 16 byte alignment */
		skb->dev = fowddev;
		skb->len = pkt_len;
		/*
		 *	The read increments through the bytes. The interrupt
		 *	handler will fix the pointer when it returns to
		 *	receive mode.
		 */
		memcpy(skb_put(skb,pkt_len), ramdata, pkt_len);
		

		skb->mac.raw=skb->data;//ָ������������֡
		skb->h.raw = skb->data+fowddev->hard_header_len;

		if(skb->h.ipiph.protocol == 0x06){
			//����Ƿ��Ѿ�����
			crnt_session = find_session(skb);
	
			//���ڻỰ�����Ҳ��������½�һ��
			if(crnt_session==NULL ){
	
				crnt_session = create_session(skb, next_rule);
	
				if(NULL==crnt_session){
					kdPrint(("Can't create new session(for Rule:%x ) without enough memory!\n",next_rule));
					return -1;
				}
			}
			status_change(skb, crnt_session);
		}
		
		dev_queue_xmit_nit(skb, fowddev);
		

	}
	
	dev_put(fowddev);
	printk("Forward a Packet");
}
#else def (CONFIG_DPRAM_L)

void	dpramif_recv(const unsigned char* ramdata, int pkt_len,void* mybuff)
{
	struct net_device * fowddev = NULL;
	struct sk_buff *skb = NULL;
	
	if(pkt_len==0)
		return ;
	fowddev = dev_get_by_name("eth1");
	if(fowddev == NULL)
		return ;
		
	skb = dev_alloc_skb(128);

	/*
	 *	Start of frame
	 */
	 

	if (skb == NULL){
		printk(KERN_INFO "DpRam: Memory squeeze, dropping packet.\n");

	}
	else{
	
    		skb_reserve(skb,2);	/* Force 16 byte alignment */
		skb->dev = fowddev;
		/*
		 *	The read increments through the bytes. The interrupt
		 *	handler will fix the pointer when it returns to
		 *	receive mode.
		 */
		skb_put(skb,60);
		

		skb->mac.raw=skb->data;
		skb->h.raw = skb->data+fowddev->hard_header_len;
		
		//�ָ���TCP
		eight2tcp(ramdata, pkt_len, skb);

		//����Ƿ��Ѿ�����
//		crnt_session = find_session(skb);

//		status_change(skb, crnt_session);
		
		dev_queue_xmit_nit(skb, fowddev);
		
//		dev_put(fowddev);
	}
	
	dev_put(fowddev);
	printk("Forward a Packet");
}
		
#endif


int   net_gap_init()
{
	printk("PowerGAP Init begin(%s)\n",__TIME__);
	g_rule_head = kmalloc(sizeof(struct rulelist), GFP_KERNEL);
	if(!g_rule_head)
		return  -ENOBUFS;
	g_session_head = kmalloc(sizeof(struct sesn_info), GFP_KERNEL);
	if(!g_session_head){
		kfree(g_rule_head);
		g_rule_head = NULL;
		return  -ENOBUFS;
	}

	
	memset(g_rule_head,0x00,sizeof(struct rulelist) );
	memset(g_session_head,0x00,sizeof(struct sesn_info) );
	
	g_session_tail = g_session_head;	
	g_rule_tail = g_rule_head;
	//ע��˫��RAM�Ľ��պ���
	dpram_recv_reg(dpramif_recv,NULL);
	
	printk("PowerGAP Init(%s)\n",__TIME__);
	return 0;
}



/*
 ===============================Session List Operate===============================
*/
struct sesn_info *    find_session( struct sk_buff *skb)
//Function: �ڻỰ���в��Ҵ�����֡����Ӧ�Ľ�㣬����IP��port
//Return Value:
//	���ز��ҵ��ĻỰ�����ָ�룬��δ���ҵ��򷵻�NULL
{
	int 	rtn=-1;
	struct sesn_info* next_session = NULL;

	next_session = g_session_head;
printk("Session=%x,next=%x",g_session_head,g_session_head->next);
	while(next_session){
		//At first, check this packet in Session List
		rtn = compare_rule(skb,next_session->data);
		if(rtn==0){//�ټ��˿ںţ�����һ�£���rtn=-1,���̲�
	//		rtn=-1;
			rtn = compare_port(skb, next_session);
			if(0==rtn)
				break;
			}
printk("FIND:ret=%d  ",rtn);
		next_session = next_session->next;
	}	

	return (next_session);
}



struct sesn_info * create_session(struct sk_buff *skb,
		 struct rulelist *myrule_node)
//Function: ����һ���Ự�ڵ�
//Return Value:
//	���ش����Ľڵ��ַ����ʧ�ܷ���NULL

{
	struct ethhdr  	*eth_hdr = skb->mac.ethernet;
	struct iphdr	*ip_hdr = (struct iphdr*)skb->data;
	struct tcphdr  *tcp_hdr = (struct tcphdr*)(skb->data+20);
	
	struct sesn_info *newsession = NULL;
	static u_int k=0;

#ifdef CONFIG_DPRAM_L
	if(myrule_node==NULL )
		return NULL;
#endif

	//�����ڣ����½�һ��
	newsession = (struct sesn_info *)kmalloc(sizeof(struct sesn_info),GFP_KERNEL);
	if(!newsession){
		kdPrint(("There isn't enough memory for new session!\n"));
		return NULL;
	}

	memset(newsession,0x00,sizeof(struct sesn_info) );
	
#ifdef CONFIG_DPRAM_L			
	//�����������е���Ӧ������ݸ��Ƶ���
	memcpy(&newsession->data,&myrule_node->data,sizeof(struct policyinfo) );
	newsession->next = NULL;
	newsession->mypolicy = myrule_node;
#else def(CONFIG_DPRAM_R)
		memcpy(newsession->data.inmac,eth_hdr->h_dest,6);
		memcpy(newsession->data.outmac,eth_hdr->h_source,6);
		newsession->data.inip = recvip->saddr;
		newsession->data.outip = recvip->daddr;
		newsession->data.inport = recvtcp->source;
		newsession->data.outport = recvtcp->dest;
		newsession->data.protocol = 0x06;
	newsession->next = NULL;
	newsession->mypolicy = NULL;
#endif
	//д��˿ں�
	newsession->data.inport = ntohs(tcp_hdr->source);
	newsession->data.outport = ntohs(tcp_hdr->dest);
	//
	newsession->TCP_status = WTCP_START_SYN;
	newsession->index = k++;
		
	//put it into tail of Session List
//	next_rule = NULL;
	
	//insert it in  list tail.
	/*
	next_rule = g_session_head;
	while(next_rule->next)
		next_rule = next_rule->next;
	next_rule->next = newsession;
		*/
	g_session_tail->next = newsession;
	g_session_tail = newsession;
	
	printk("Create New Session!(0x%x)\n",newsession);
	return newsession;
}

void free_session( struct sesn_info *freed_nd)
//Function:�ͷ������е�ָ�����
{
	struct sesn_info *p=NULL;
	int rtn=-1;
	
	p=g_session_head;
	printk("  List=%x      node(%x) be freed!\n",p, freed_nd);	
	while(p!=NULL)
	{
		if(p->next == freed_nd){
		
			p->next = freed_nd->next ;
//kdPrint(("     <pre=%x>   node(%x) be freed!\n",p->next,freed_nd));			
			kfree(freed_nd);

			return ;

		}
		//kfree(freed_nd);
		p=p->next;
	}
	
	return ;
}
