#ifndef _CAPTURE_H
#define _CAPTURE_H
#include "macro.h"
#include <features.h> 
#include <ctype.h> 
#include <getopt.h> 
#include <sys/socket.h> 
#include <sys/ioctl.h> 
#include <asm/sockios.h> 
#include <net/if.h> 
#include <netinet/in.h> 
#include <libnet.h>

#define data_packet_len 1514 
class CCapture
{
	public :
		CCapture();
		int OpenNetworkType(unsigned short netid =3 , int flag = 1);//1Ϊ������ʽ
		void CloseNetworkLink();
		int GetSock();
		int ReadFromNetwork(char* device,char *data, int len) ;
		int	SendData(char* buf, int buf_len, const char* devname);
	private :
		int m_recv_sock;
};

#endif
