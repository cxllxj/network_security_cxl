#include "./capture.h"
#include "macro.h"
#include <features.h> 
#include <ctype.h> 
#include <getopt.h> 
#include <sys/socket.h> 
#include <sys/ioctl.h> 
#include <asm/sockios.h> 
#include <net/if.h> 
#include <netinet/in.h> 
#include <libnet.h>

CCapture::CCapture()
{
	m_recv_sock = 0;
	
}


/* 
* Obtain a file handle on a raw ethernet type. In actual fact 
* you can also request the dummy types for AX.25 or 802.3 also 
* 
* -1 indicates an error 
* 0 indicates success
* 
* WARNING: It is ok to listen to a service the system is using (eg arp) 
* but don try and run a user mode stack on the same service or all 
* hell will break loose. 
*/ 
//��������ɻ���ģʽ,���socket��m_recv_sock
int CCapture::OpenNetworkType(unsigned short netid , int flag) 
{ 
	struct   ifreq ifr ;
	m_recv_sock = socket(AF_INET, SOCK_PACKET, htons(0x0003)); 
	if (m_recv_sock < 0)
	{ 
		return -1;
	}
	/*
	if(flag != 1) 
	{
		fcntl(m_recv_sock, F_SETFL, O_NDELAY); 
	}
	*/
	
	
    

   

    strcpy( ifr.ifr_name, "eth0") ;
    if( ioctl(m_recv_sock, SIOCGIFFLAGS, &ifr) < 0 )  /* get flags */
    {
        close(m_recv_sock) ;
        DEBUG_PUT( "Can't get flags\r\n" ) ;
        return -1;
    }

    ifr.ifr_flags |= IFF_PROMISC ;    /* set promiscuous mode */

    if( ioctl(m_recv_sock, SIOCSIFFLAGS, &ifr) < 0 )
    {
        close(m_recv_sock);
        DEBUG_PUT( "Can't set flags\r\n" );
        return -1;
    }
    return m_recv_sock; 
} 

/* 
* Close a file handle to a raw packet type. 
*/ 
void CCapture::CloseNetworkLink() 
{ 
	close(m_recv_sock); 
}

/*
* Get m_sock.
*/
int CCapture::GetSock()
{
	return m_recv_sock;
}

/* 
* Read a packet from the network. The device parameter will 
* be filled in by this routine (make it 32 bytes or more). 
* If you wish to work with one interface only you must filter 
* yourself. Remember to make your buffer big enough for your 
* data. Oversized packets will be truncated. 
* 
* Return: 
* -1 Error 
* otherwise Size of packet received. 
*/ 
//�ڴ򿪵�socket��m_recv_sock�л�ȡһ֡(data����),����ֵdevice
int CCapture::ReadFromNetwork(char *device, char *data, int len) 
{ 
	struct sockaddr sa; 
	int sz = sizeof(sa); 
	int error;
	if(m_recv_sock <= 0)
		return -1;
	if(m_recv_sock > 0)
	{ 
		error = recvfrom(m_recv_sock, data, len, 0, &sa,(socklen_t *)&sz); 
		if (error == -1) 
		return -1; 
		strcpy(device, sa.sa_data);
	} 
	return error; /* Actually size of received packet */ 
}
//����libnet������̫����(devname)����һ֡(buf����)
int	CCapture::SendData(char* buf, int buf_len, const char* devname)
{
    
    libnet_t *l;
    int c;
   
    char device[32] = {0};
    char errbuf[LIBNET_ERRBUF_SIZE];
    if(!devname){
    	strcpy(device,"eth0");
    	}
    else
    	strcpy(device,devname);
    l = libnet_init(
            LIBNET_LINK ,                            /* injection type */
            device,                                 /* network interface */
            errbuf);                                /* errbuf */
	if (l == NULL)
    {
        fprintf(stderr, "libnet_init() failed: %s", errbuf);
        exit(EXIT_FAILURE);
    }
	c = libnet_write_link(l,(u_char*)buf,buf_len);
	 if (c == -1)
    {
        fprintf(stderr, "Write error: %s\n", libnet_geterror(l));
        goto bad;
    }
    else
    {
        fprintf(stdout, "Write %d byte packet; check the wire.\n", c);
    }
    libnet_destroy(l);
    return (EXIT_SUCCESS);
bad:
    libnet_destroy(l);
    return (EXIT_FAILURE);
}
