struct svrconf
{
	u_char MAC[6];
	long   IP;
	int PORT;
};

asmlinkage int sys_svrconf( u_char* mac, long inetaddr, int port )
{
	struct svrconf *psvrconf=NULL;
	psvrconf=(struct svrconf *)kmalloc( sizeof(struct svrconf *), GFP_KERNEL );
	copy_from_user(psvrconf->MAC,mac,6);
	psvrconf->IP=inetaddr;
	psvrconf->PORT=port;
	
	return 0;
}

