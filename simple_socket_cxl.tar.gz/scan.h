#ifndef __SCAN_H__
#define __SCAN_H__

    #include "macro.h"

    struct getinf
    {
        unsigned char  M_saddr[6];
        unsigned char  M_daddr[6];
        unsigned int   IP_saddr;
        unsigned int   IP_daddr;
        unsigned short S_Port;
        unsigned short D_Port;
        int            IpType;
        int            EthType;
    };
    
    struct frame
    {
    	
    	unsigned char frametype;
    	unsigned char asip[4];
        unsigned char adip[4];

        unsigned char ether_dhost[6];   /* destination eth addr */
        unsigned char ether_shost[6];   /* source ether addr    */
        unsigned short  ether_type;

        /*IP hearder*/
        unsigned char ihl_version;
        unsigned char ihl;
        unsigned char version;
        unsigned char tos;
        unsigned short tot_len;
        unsigned short id;
        unsigned short frag_off;
        unsigned char ttl;
        unsigned char protocol;
        unsigned short check;
        unsigned long sip;
        unsigned long dip;

    	/*TCP hearder*/
        unsigned short th_sport;       /* source port */
        unsigned short th_dport;       /* destination port */
        unsigned long  th_seq;           /* sequence number */
        unsigned long  th_ack;           /* acknowledgement number */

    	/*UDP hearder*/
        unsigned short udp_sport;
        unsigned short udp_dport;
        unsigned short udp_len;
        unsigned short udp_check;

    	/*ICMP hearder*/
        unsigned char  icmp_type;   /* message type */
        unsigned char  icmp_code;   /* type sub-code */
        unsigned short icmp_checksum;

    	/*ARP hearder*/
        unsigned int   ar_hrd;      /* Format of hardware address.  */
        unsigned int   ar_pro;      /* Format of protocol address.  */
        unsigned char  ar_hln;      /* Length of hardware address.  */
        unsigned char  ar_pln;      /* Length of protocol address.  */
        unsigned int   ar_op;       /* ARP opcode (command).  */

        unsigned char  __ar_sha[6]; /* Sender hardware address.  */
        unsigned char  __ar_sip[4]; /* Sender IP address.  */
        unsigned char  __ar_tha[6]; /* Target hardware address.  */
        unsigned char  __ar_tip[4]; /* Target IP address.  */
        unsigned char  padding[18]; /* Padding */	
    };
    
int Decode(unsigned char *Buf, int BufLen, struct getinf *PEtherInf);

#endif
