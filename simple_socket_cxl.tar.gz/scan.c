#include "scan.h"
#include "macro.h"
#include <stdio.h>
#include <stdlib.h>
#include <stack.h>
#include <sys/socket.h> 
#include <sys/ioctl.h> 
#include <asm/sockios.h> 
#include <net/if.h> 
#include <netinet/in.h> 



int Decode(unsigned char *Buf, int BufLen, struct getinf *PEtherInf)
{
	
    int      dlen;
    	
    unsigned char asip[4];
    unsigned char adip[4];

    unsigned char ether_dhost[6];   /* destination eth addr */
    unsigned char ether_shost[6];   /* source ether addr    */
    unsigned short  ether_type;

    /*IP hearder*/
    unsigned char ihl_version;
    unsigned char ihl;
    unsigned char version;
    unsigned char tos;
    unsigned short tot_len;
    unsigned short id;
    unsigned short frag_off;
    unsigned char ttl;
    unsigned char protocol;
    unsigned short check;
    unsigned long sip;
    unsigned long dip;

    /*TCP hearder*/
    unsigned short th_sport;        /* source port */
    unsigned short th_dport;        /* destination port */
    unsigned long  th_seq;          /* sequence number */
    unsigned long  th_ack;          /* acknowledgement number */

    /*UDP hearder*/
    unsigned short udp_sport;
    unsigned short udp_dport;
    unsigned short udp_len;
    unsigned short udp_check;

    /*ICMP hearder*/
    unsigned char  icmp_type;   /* message type */
    unsigned char  icmp_code;   /* type sub-code */
    unsigned short icmp_checksum;

    /*ARP hearder*/
    unsigned int   ar_hrd;      /* Format of hardware address.  */
    unsigned int   ar_pro;      /* Format of protocol address.  */
    unsigned char  ar_hln;      /* Length of hardware address.  */
    unsigned char  ar_pln;      /* Length of protocol address.  */
    unsigned int   ar_op;       /* ARP opcode (command).  */

    unsigned char  __ar_sha[6]; /* Sender hardware address.  */
    unsigned char  __ar_sip[4]; /* Sender IP address.  */
    unsigned char  __ar_tha[6]; /* Target hardware address.  */
    unsigned char  __ar_tip[4]; /* Target IP address.  */
    unsigned char  padding[18]; /* Padding */

    char           buffer[1500];
    unsigned char  my[2048];
	struct getinf  *w;
    struct frame   frames;
    int Result;
    
	memset(&frames,0,sizeof(struct frame));
	w = (struct getinf *)malloc(sizeof(struct getinf));
    memset(w,0,sizeof(struct getinf));
    memset(my,0,2048);
	memcpy(my,Buf,BufLen);
   
   	
   	dlen = 0 ;

    memcpy(ether_dhost,my,6*sizeof(unsigned char));
    memcpy(ether_shost,my+6,6*sizeof(unsigned char));
    memcpy(&ether_type,my+12,sizeof(unsigned short));

    w->EthType=ntohs(ether_type);
    memcpy(w->M_saddr,ether_shost,6*sizeof(unsigned char));
    memcpy(w->M_daddr,ether_dhost,6*sizeof(unsigned char));

    memcpy(frames.ether_dhost,ether_dhost,6);
    memcpy(frames.ether_shost,ether_shost,6);

     
    frames.ether_type=ether_type;

	switch(ntohs(ether_type))
	{
		case 0x800:        /*IP PROTOCOL*/
        	Result = NETWORK_PORT_IP;
        	memcpy(&ihl_version,my+ETHER_HEADER_SIZE,sizeof(unsigned char));
        	memcpy(&tos,my+ETHER_HEADER_SIZE+1,sizeof(unsigned char));
        	memcpy(&tot_len,my+ETHER_HEADER_SIZE+2,sizeof(unsigned short));
        	memcpy(&id,my+ETHER_HEADER_SIZE+4,sizeof(unsigned short));
        	memcpy(&frag_off,my+ETHER_HEADER_SIZE+6,sizeof(unsigned short));
        	memcpy(&ttl,my+ETHER_HEADER_SIZE+8,sizeof(unsigned char));
        	memcpy(&protocol,my+ETHER_HEADER_SIZE+9,sizeof(unsigned char));
        	memcpy(&check,my+ETHER_HEADER_SIZE+10,sizeof(unsigned short));
        	memcpy(&sip,my+ETHER_HEADER_SIZE+12,4*sizeof(unsigned char));
        	memcpy(&dip,my+ETHER_HEADER_SIZE+16,4*sizeof(unsigned char));


        	memcpy(asip,my+ETHER_HEADER_SIZE+12,4*sizeof(unsigned char));
        	memcpy(adip,my+ETHER_HEADER_SIZE+16,4*sizeof(unsigned char));

	       frames.ihl_version=ihl_version;
    	   frames.tos=tos;
           frames.tot_len=tot_len;
           frames.id=id;
           frames.frag_off=frag_off;
           frames.ttl=ttl;
		   frames.protocol=protocol;
		   frames.check=check;
		   memcpy(&frames.sip,&sip,4);
		   memcpy(&frames.dip,&dip,4);
			
		   memcpy(frames.asip,asip,4);
		   memcpy(frames.adip,adip,4);

           version=(ihl_version >>4)&0x0f;
           ihl=ihl_version&0x0f;

           frames.version=version;
           frames.ihl=ihl;

           w->IP_saddr=(sip);
           w->IP_daddr=(dip);
           w->IpType=protocol;

           switch(protocol)
           {
                case 6:      /*TCP PROTOCOL*/
                        memcpy(&th_sport,my+ETHER_HEADER_SIZE+IP_HEADER_SIZE,sizeof(unsigned short));
                        memcpy(&th_dport,my+ETHER_HEADER_SIZE+IP_HEADER_SIZE+2,sizeof(unsigned short));
                        memcpy(&th_seq,my+ETHER_HEADER_SIZE+IP_HEADER_SIZE+4,sizeof(unsigned long));
                        memcpy(&th_ack,my+ETHER_HEADER_SIZE+IP_HEADER_SIZE+8,sizeof(unsigned long));

                        frames.th_sport=th_sport;
                        frames.th_dport=th_dport;
                        frames.th_seq=th_seq;
                        frames.th_ack=th_ack;



                        w->S_Port=ntohs(th_sport);
                        w->D_Port=ntohs(th_dport);
                        break;

                case 17:     /*UDP PROTOCOL*/
                        memcpy(&udp_sport,my+ETHER_HEADER_SIZE+IP_HEADER_SIZE,sizeof(unsigned short));
                        memcpy(&udp_dport,my+ETHER_HEADER_SIZE+IP_HEADER_SIZE+2,sizeof(unsigned short));
                        memcpy(&udp_len,my+ETHER_HEADER_SIZE+IP_HEADER_SIZE+4,sizeof(unsigned short));
                        memcpy(&udp_check,my+ETHER_HEADER_SIZE+IP_HEADER_SIZE+6,sizeof(unsigned short));

                        frames.udp_sport=udp_sport;
                        frames.udp_dport=udp_dport;
                        frames.udp_len=udp_len;
                        frames.udp_check=udp_check;

                        w->S_Port=ntohs(udp_sport);
                        w->D_Port=ntohs(udp_dport);

                        break;

                case 1:      /*ICMP PROTOCOL*/
                        memcpy(&icmp_type,my+ETHER_HEADER_SIZE+IP_HEADER_SIZE,sizeof(unsigned char));
                        memcpy(&icmp_code,my+ETHER_HEADER_SIZE+IP_HEADER_SIZE+1,sizeof(unsigned char));
                        memcpy(&icmp_checksum,my+ETHER_HEADER_SIZE+IP_HEADER_SIZE+2,sizeof(unsigned short));

                        frames.icmp_type=icmp_type;
                        frames.icmp_code=icmp_code;
                        frames.icmp_checksum=icmp_checksum;
                        break;

                default:     /*Unknown PROTOCOL*/
                        break;
            }
            break;

        case 0x806:        /*ARP PROTOCOL*/
                Result = NETWORK_PORT_ARP;
                memcpy(&ar_hrd,my+ETHER_HEADER_SIZE,sizeof(unsigned short));
                memcpy(&ar_pro,my+ETHER_HEADER_SIZE+2,sizeof(unsigned short));
                memcpy(&ar_hln,my+ETHER_HEADER_SIZE+4,sizeof(unsigned char));
                memcpy(&ar_pln,my+ETHER_HEADER_SIZE+5,sizeof(unsigned char));
                memcpy(&ar_op,my+ETHER_HEADER_SIZE+6,sizeof(unsigned short));

                memcpy(__ar_sha,my+ETHER_HEADER_SIZE+8,6*sizeof(unsigned char));
                memcpy(__ar_sip,my+ETHER_HEADER_SIZE+14,4*sizeof(unsigned char));
                memcpy(__ar_tha,my+ETHER_HEADER_SIZE+18,6*sizeof(unsigned char));
                memcpy(__ar_tip,my+ETHER_HEADER_SIZE+24,4*sizeof(unsigned char));
                memcpy(padding,my+ETHER_HEADER_SIZE+28,18*sizeof(unsigned char));

                frames.ar_hrd=ar_hrd;
                frames.ar_pro=ar_pro;
                frames.ar_hln=ar_hln;
                frames.ar_pln=ar_pln;
                frames.ar_op=ar_op;

                memcpy(frames.__ar_sha,__ar_sha,6);
                memcpy(frames.__ar_sip,__ar_sip,4);
                memcpy(frames.__ar_tha,__ar_tha,6);
                memcpy(frames.__ar_tip,__ar_tip,4);
                memcpy(frames.padding,padding,18);
            break;
        case 0x8035:       /*RARP PROTOCOL*/
			Result = NETWORK_PORT_RARP;
            break;
        default:           /*Unknown PROTOCOL*/
        	Result = ntohs(ether_type);
        	//DEBUG_PUT2("eth_type is :0x%x\r\n",ntohs(ether_type));
        	//printf("------------------------------------------------------------------------------\r\n");
            break;
    }
    
    memcpy(PEtherInf,w,sizeof(struct getinf));
    free(w);
    return(Result);
}

