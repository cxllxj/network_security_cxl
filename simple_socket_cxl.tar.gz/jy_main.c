/******************************************************************
** �ļ���: main.c
** Copyright (c) 2002 ά����˾����������
** ������:  ���@
** ����:   2002/10/18
** �޸���:
** �� ��:
** �� ��:   ��ȫ�������� ���ԣ�201������ 203������
**
** �� ��:  V1.0
***************************************************************/

#include "capture.h"
#include  "reply_arp.h"
#include  "dbg_print.h"


#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

#include <sys/time.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/un.h>

u_char	mymac[6];
u_char  othermac[6];
 struct filter_table  outer_net[8];
 struct filter_table  inter_net[8];

 int	bIsInside;

int	convert_ip(int is_inside,u_char *data, int packet_len);
int	transfer_ip(char *other_net,u_char *data, int packet_len);
u_short in_cksum( u_char* pStartingByte, int nByteCount ,u_char protlcode,u_short tcpsize);
int	search_file();

int main(int argc ,char *argv[])
{
	int   ComFd = 0;
	int   CapFd = 0;
	int   MaxFd = 0;
	int   Ret = 0;
	int   RetLen = 0;
	fd_set FdSet;
    	char devicename_rec[32],othernet[32]; 
	unsigned char data[data_packet_len]={0}; 
	int netid=0x03,i=0,count_rec=0,j=0; 
	CCapture cap;
	int Result = 0;
	struct arp_frame  *recvarp = NULL;
	int cmd[16];
	
	printf("*****************************\n");
	printf("* Logic insulated Equipment *\n");
	printf("*****************************\n");
	
	//�趨�ڣ��⣩����
	memset(devicename_rec,0x00,32);
	memset(othernet,0x00,32);
	printf(" This is the Inside-Net?(Y/N)");
	scanf("%s",&cmd);
	if(cmd[0]=='y' || cmd[0]=='Y'){
		bIsInside=1;
		strcpy(devicename_rec,"eth0");
		strcpy(othernet,"eth1");

	}else{
		bIsInside=0;
		strcpy(devicename_rec,"eth1");
		strcpy(othernet,"eth0");
	}
	get_mac_addr(devicename_rec, mymac);
	get_mac_addr(othernet,othermac);
	
	Ret=search_file();
	if(Ret<0)
		return 0;
	
	//��ץ���˿�
	
	if ((CapFd = cap.OpenNetworkType(devicename_rec,0))< 0) 
	{ 
		kdPrint(("Can not open net_dectype %d \n",netid)); 
		return -1; 
	}
	else
	{
		kdPrint(("Can open net_dectype %d \n",CapFd)); 
	} 
	
    
    
   	
   			
	for(;;)
	{
   		FD_ZERO(&FdSet);
   		FD_SET(CapFd, &FdSet);
   		   		
		
		MaxFd = CapFd + 1;
//		kdPrint(("max listen %d\n",MaxFd));
		
		Ret = select(MaxFd + 1, &FdSet, NULL, NULL, NULL);
		if(Ret <= 0){
			kdPrint((" ----------------select : %s --------------\n",strerror(errno) ));
		    	
			break;
		}
		    
	    
	    
	    //ץ��
	    
		if(FD_ISSET(CapFd, &FdSet))
		{
			if ((Ret = cap.ReadFromNetwork(devicename_rec,(char*)data,data_packet_len))>0)
			{ 
	//			kdPrint((" ----------------read : %s --------------\n",data,data_packet_len));
#ifdef DEBUG	
				//packet_print((u_char*)data, data_packet_len);
				
#endif
				recvarp = (struct arp_frame*)data;
				if(recvarp->ether_type == htons(0x0806) ){
					printf(">>>>dev=%s rev ARP (is inside=%d) ",devicename_rec,bIsInside);
					Ret = arp_reply(devicename_rec,data,data_packet_len);
					if(Ret==0) 
						packet_print((u_char*)data, data_packet_len);
				}else if(recvarp->ether_type == 0x0008){
					//��ӳ��
					Ret=convert_ip(bIsInside,data,data_packet_len);
					//����һ������ת��
					if(!Ret){
						packet_print((u_char*)data, data_packet_len);
						transfer_ip(othernet,data,data_packet_len);
					}
				}
					
					
			} 
		}
	    
	}
	//������������Ӧ�������
	return 0;
}

int	convert_ip(int is_inside,u_char *data, int packet_len)
//Function:���ݲ����ļ��еĹ�����MAC��IP��ַ��ת������˵ӳ�䣩
{
	struct ipv4_hdr *iphdr=(struct ipv4_hdr*)(data+14);
	struct tcp_hdr  *tcphdr=(struct tcp_hdr*)(data+34);
	u_int  tcphdr_size = tcphdr->th_off *4+8;
	u_short tcpsize = htons(iphdr->ip_len)-20;
	int i;
	
	//�滻ԴMAC
	memcpy(data+6,othermac,6);
	if(is_inside){//������
		//��Ŀ��IP,��ת��
		for( i=0;i<8;i++)
			if(htonl(iphdr->ip_dst)==outer_net[i].cvt) break;
		if(i>=8)  return (-1);
		//�滻Ŀ��IP��MAC
		iphdr->ip_dst = htonl(outer_net[i].ip);	
		memcpy(data,outer_net[i].mac,6);
		
		for( i=0;i<8;i++)
			if(htonl(iphdr->ip_src)==inter_net[i].ip) break;
		if(i>=8)  return (-1);
		
		iphdr->ip_src = htonl(inter_net[i].cvt);

	}else{//������
		for( i=0;i<8;i++)
			if(htonl(iphdr->ip_dst)==inter_net[i].cvt) break;
		if(i>=8)  return (-1);
		//�滻Ŀ��IP��MAC
		iphdr->ip_dst = htonl(inter_net[i].ip);	
		memcpy(data,inter_net[i].mac,6);
			
		for( i=0;i<8;i++)
			if(htonl(iphdr->ip_src)==outer_net[i].ip) break;
		if(i>=8)  return (-1);
		iphdr->ip_src = htonl(outer_net[i].cvt);	
	}
	//����У���
	iphdr->ip_sum=0;
	iphdr->ip_sum = in_cksum(data+14,20,0,tcpsize);
	
	if(iphdr->ip_p==0x06){
		//TCP check sum
		tcphdr->th_sum = 0;
		tcphdr->th_sum = in_cksum(data+26,tcphdr_size,iphdr->ip_p,tcpsize);
	}

	
	return 0;		
	
}


int	transfer_ip(char *other_net,u_char *data, int packet_len)
//Function:���޸���ϵ�����֡����һ������ת����ȥ
{
	char errbuf[512];
	int	ret = -1;
	int 	i=0;
	int 	length=0;
	libnet_t *l=NULL;
	struct ipv4_hdr *iphdr=(struct ipv4_hdr*)(data+14);
	
	//packet length
	length = htons(iphdr->ip_len)+14;
	
	//send the ARP packet back 
	l = libnet_init(
            	LIBNET_LINK ,                            // injection type
            	other_net,                              // network interface 
            	errbuf);                                // errbuf 
	if (l == NULL)
	{
		kdPrint(( "libnet_init() failed: %s", errbuf));
		return (-1);
	}
	ret = libnet_write_link(l,data,length);
	if (ret == -1)
	{
		kdPrint(("DEV(%s)Write error: %s\n", other_net,libnet_geterror(l) ));
	}
	else
	{
        	kdPrint(("IP:DEV(%s),Write %d byte packet; check the wire.\n", other_net,length));

	}
	
	libnet_destroy(l);
	return (ret);
}

/////////////////////////////////////////////////////////////////////////////
//// in_cksum
//
// Purpose
// Standard Internet Protocol checksum routine.
//
// Parameters
//
// Return Value
//
// Remarks
// ICMP, IGMP, UDP and TCP all use the same checksum algorithm
//  protlcode: UDP--0x11  IP--0x00   TCP--0x06
//

u_short in_cksum( u_char* pStartingByte, int nByteCount ,u_char protlcode, u_short tcpsize)
//Function: ����IP,TCP,UDP��У���
//Parameters:
//	pStartingByte:	[IN]����IPУ���ʱ��ΪIP�ײ��ĵ�ַ������TCP��UDP�ײ�У���ʱ��
//			ΪIP�ײ���ԴIP��ַ����ʼָ��
//	nByteCount��	[IN]IP�ײ����ȣ�UDP���ȼ�8��TCP�ײ����ȼ�8
//	protlcode��	[IN]IP��Ϊ0��TCPΪ6��UDPΪ17
//	tcpsize��	[IN]TCPΪ����֡����MAC�����ȼ�34
{
   u_int sum = 0;
   u_short *addr = (u_short * )pStartingByte;
   u_short  add_protcl = (protlcode<<8)&0xff00;

   //
   // Add 16-bit Words
   //
   while (nByteCount > 1)
   {
      //
      // This Is The Inner Loop
      //
      sum += *(addr++);
      nByteCount -= 2;
   }

	if(protlcode==6 || protlcode==17){
	//TCP UDP fute header
	sum += add_protcl + htons(tcpsize);
	}
	
   //
   // Add leftover byte, if any
   //
   if (nByteCount > 0)
#if BIG_ENDIAN
      sum += (*(u_char* )addr) << 8;
#else
      sum += *(u_char* )addr;
#endif

   //
   // Fold 32-bit sum to 16-bit
   //
   while (sum >> 16)
      sum = (sum & 0xffff) + (sum >> 16);

   //
   // Return one's compliment of final sum.
   //
   return (u_short) ~sum;
}
int string_to_mac(char *data,u_char *mac)
{
	int i=0;
	char j;
	for(int k=0;data[i]>=' ';i++){
		if(data[i]>='0'&& data[i]<='9')
			j=data[i]-'0';
		else if(data[i]>='a'&& data[i]<='f')
			j=data[i]-'a'+10;
		else if(data[i]>='A'&& data[i]<='F')
			j=data[i]-'A'+10;
		else  
			continue;
		
		if(k%2 == 1)
			mac[k/2]=(mac[k/2]<<4) | (j&0x0f);
		else
			mac[k/2]=j&0x0f;
		k++;
	}
	return 0;
}

u_int string_to_ip(char *ipstr)	
//Function: ���硰192.168.0.25"�ַ���ת��Ϊunsigned int �ͣ���0xC0A80019
{
	int i=0;
	u_int ipaddr=0,ip=0;
//	printf(" \n ipstring: %s\n",ipstr);
	for(i=0;ipstr[i]>=' '&& ipstr[i]<='9';i++){
		if(ipstr[i]>='0')
			ip = ip*10+(ipstr[i]-'0');
		if(ipstr[i]=='.'){	
			ipaddr = (ipaddr<<8)+ip;

			printf("ip=%d,ipaddr=%x\n",ip,ipaddr);
			ip=0;			
		}
	}
	ipaddr = (ipaddr<<8)+ip;
	
	return ipaddr;
}

int	search_file()
//Function: ��ȡ�����ļ��е�����
{
	FILE *fp=NULL;
	int position=0;
	char  context[1024];
	u_int	ip=0,ipaddr=0,k=0;
	int 	pos_in=-1,pos_out=-1;
	char info[16]={0};
	int j=0;
	
	memset(context,0,1024);
	fp = fopen("policy.ini","rb");
	if(fp==NULL){
		printf("Can't open the file policy.ini\n");
		return -1;
	}
	fread(context,1024,1,fp);


	for(int i=0;i<1024;i++){

		if(context[i]==':'){
			memset(info,0x00,16);
			
			for(j=i;context[j]>=0x20 && j>=0;j--) ;
			j++;			


			for(k=0;context[j]>=' ' && context[j]!=':' ;j++)
				if(context[j]>='A' && context[j]<='z'){
					info[k]=context[j];
					k++;
				}

			if(!strcmp(info,"inmac") )
				string_to_mac(context+i+1,inter_net[pos_in].mac);	
			if(!strcmp(info,"in")){
				pos_in++;				
	//			printf("--in ip--");
				inter_net[pos_in].ip=string_to_ip(context+i+1);	
			}
			if(!strcmp(info,"incvt") )
				inter_net[pos_in].cvt=string_to_ip(context+i+1);


			if(!strcmp(info,"outmac") )
				string_to_mac(context+i+1,outer_net[pos_out].mac);	
			if(!strcmp(info,"out")){
				pos_out++;				
				outer_net[pos_out].ip=string_to_ip(context+i+1);	
			}
			if(!strcmp(info,"outcvt"))
				outer_net[pos_out].cvt=string_to_ip(context+i+1);
			
		}
		
	}
	fclose(fp);
	
	for(k=0;k<8;k++)
		printf("OUT::i=%d, ip=%x, cvt=%x, mac=%2x-%2x-%2x-%2x-%2x-%2x  \n",k,outer_net[k].ip,outer_net[k].cvt,
			outer_net[k].mac[0],outer_net[k].mac[1],outer_net[k].mac[2],outer_net[k].mac[3],outer_net[k].mac[4],outer_net[k].mac[5]);
	for(k=0;k<8;k++)
		printf("INSIDE::i=%d, ip=%x, cvt=%x, mac=%2x-%2x-%2x-%2x-%2x-%2x  \n",k,inter_net[k].ip,inter_net[k].cvt,
			inter_net[k].mac[0],inter_net[k].mac[1],inter_net[k].mac[2],inter_net[k].mac[3],inter_net[k].mac[4],inter_net[k].mac[5]);
			
	return 0;

}
